"""Совместимость с прежним расположением access-хелперов."""

from .core.access import *  # noqa: F401,F403
