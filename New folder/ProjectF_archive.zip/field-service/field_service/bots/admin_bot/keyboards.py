"""Совместимость с прежним API клавиатур админ-бота."""

from .ui.keyboards import *  # noqa: F401,F403
