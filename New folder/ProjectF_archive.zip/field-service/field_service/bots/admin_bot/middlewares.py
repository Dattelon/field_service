"""Совместимость с прежним расположением middleware админ-бота."""

from .core.middlewares import *  # noqa: F401,F403
