"Shared catalog data for Field Service domain."
