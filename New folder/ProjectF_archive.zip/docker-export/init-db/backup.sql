--
-- PostgreSQL database dump
--

\restrict u2wF30U9mJiBTgGZTdmEyuVCAPxxK2Y9fRhGIwoQmv9SwghrS5dz0dbfrAkN4zK

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.streets DROP CONSTRAINT IF EXISTS fk_streets__district_id__districts;
ALTER TABLE IF EXISTS ONLY public.streets DROP CONSTRAINT IF EXISTS fk_streets__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.staff_cities DROP CONSTRAINT IF EXISTS fk_staff_cities__staff_user_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.staff_cities DROP CONSTRAINT IF EXISTS fk_staff_cities__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.staff_access_codes DROP CONSTRAINT IF EXISTS fk_staff_access_codes__used_by_staff_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.staff_access_codes DROP CONSTRAINT IF EXISTS fk_staff_access_codes__issued_by_staff_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.staff_access_codes DROP CONSTRAINT IF EXISTS fk_staff_access_codes__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.staff_access_code_cities DROP CONSTRAINT IF EXISTS fk_staff_access_code_cities__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.staff_access_code_cities DROP CONSTRAINT IF EXISTS fk_staff_access_code_cities__access_code_id__staff_access_codes;
ALTER TABLE IF EXISTS ONLY public.referrals DROP CONSTRAINT IF EXISTS fk_referrals__referrer_id__masters;
ALTER TABLE IF EXISTS ONLY public.referrals DROP CONSTRAINT IF EXISTS fk_referrals__master_id__masters;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS fk_referral_rewards__referrer_id__masters;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS fk_referral_rewards__referred_master_id__masters;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS fk_referral_rewards__commission_id__commissions;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders__street_id__streets;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders__preferred_master_id__masters;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders__guarantee_source_order_id__orders;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders__district_id__districts;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders__created_by_staff_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS fk_orders__assigned_master_id__masters;
ALTER TABLE IF EXISTS ONLY public.order_status_history DROP CONSTRAINT IF EXISTS fk_order_status_history__order_id__orders;
ALTER TABLE IF EXISTS ONLY public.order_status_history DROP CONSTRAINT IF EXISTS fk_order_status_history__changed_by_staff_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.order_status_history DROP CONSTRAINT IF EXISTS fk_order_status_history__changed_by_master_id__masters;
ALTER TABLE IF EXISTS ONLY public.order_autoclose_queue DROP CONSTRAINT IF EXISTS fk_order_autoclose_queue__order_id__orders;
ALTER TABLE IF EXISTS ONLY public.offers DROP CONSTRAINT IF EXISTS fk_offers__order_id__orders;
ALTER TABLE IF EXISTS ONLY public.offers DROP CONSTRAINT IF EXISTS fk_offers__master_id__masters;
ALTER TABLE IF EXISTS ONLY public.notifications_outbox DROP CONSTRAINT IF EXISTS fk_notifications_outbox__master_id__masters;
ALTER TABLE IF EXISTS ONLY public.masters DROP CONSTRAINT IF EXISTS fk_masters__verified_by__staff_users;
ALTER TABLE IF EXISTS ONLY public.masters DROP CONSTRAINT IF EXISTS fk_masters__referred_by_master_id__masters;
ALTER TABLE IF EXISTS ONLY public.masters DROP CONSTRAINT IF EXISTS fk_masters__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.master_skills DROP CONSTRAINT IF EXISTS fk_master_skills__skill_id__skills;
ALTER TABLE IF EXISTS ONLY public.master_skills DROP CONSTRAINT IF EXISTS fk_master_skills__master_id__masters;
ALTER TABLE IF EXISTS ONLY public.master_invite_codes DROP CONSTRAINT IF EXISTS fk_master_invite_codes__used_by_master_id__masters;
ALTER TABLE IF EXISTS ONLY public.master_invite_codes DROP CONSTRAINT IF EXISTS fk_master_invite_codes__issued_by_staff_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.master_invite_codes DROP CONSTRAINT IF EXISTS fk_master_invite_codes__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.master_districts DROP CONSTRAINT IF EXISTS fk_master_districts__master_id__masters;
ALTER TABLE IF EXISTS ONLY public.master_districts DROP CONSTRAINT IF EXISTS fk_master_districts__district_id__districts;
ALTER TABLE IF EXISTS ONLY public.districts DROP CONSTRAINT IF EXISTS fk_districts__city_id__cities;
ALTER TABLE IF EXISTS ONLY public.commissions DROP CONSTRAINT IF EXISTS fk_commissions__order_id__orders;
ALTER TABLE IF EXISTS ONLY public.commissions DROP CONSTRAINT IF EXISTS fk_commissions__master_id__masters;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS fk_attachments__uploaded_by_staff_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS fk_attachments__uploaded_by_master_id__masters;
ALTER TABLE IF EXISTS ONLY public.admin_audit_log DROP CONSTRAINT IF EXISTS fk_admin_audit_log__master_id__masters;
ALTER TABLE IF EXISTS ONLY public.admin_audit_log DROP CONSTRAINT IF EXISTS fk_admin_audit_log__admin_id__staff_users;
ALTER TABLE IF EXISTS ONLY public.distribution_metrics DROP CONSTRAINT IF EXISTS distribution_metrics_order_id_fkey;
ALTER TABLE IF EXISTS ONLY public.distribution_metrics DROP CONSTRAINT IF EXISTS distribution_metrics_master_id_fkey;
ALTER TABLE IF EXISTS ONLY public.distribution_metrics DROP CONSTRAINT IF EXISTS distribution_metrics_district_id_fkey;
ALTER TABLE IF EXISTS ONLY public.distribution_metrics DROP CONSTRAINT IF EXISTS distribution_metrics_city_id_fkey;
ALTER TABLE IF EXISTS ONLY public.commission_deadline_notifications DROP CONSTRAINT IF EXISTS commission_deadline_notifications_commission_id_fkey;
DROP INDEX IF EXISTS public.uq_offers__order_master_active;
DROP INDEX IF EXISTS public.uix_offers__order_accepted_once;
DROP INDEX IF EXISTS public.ix_streets__district_id;
DROP INDEX IF EXISTS public.ix_streets__city_id;
DROP INDEX IF EXISTS public.ix_staff_users__tg_user_id;
DROP INDEX IF EXISTS public.ix_staff_code_cities__code;
DROP INDEX IF EXISTS public.ix_staff_code_cities__city;
DROP INDEX IF EXISTS public.ix_staff_cities__staff_user_id;
DROP INDEX IF EXISTS public.ix_staff_cities__city_id;
DROP INDEX IF EXISTS public.ix_staff_access_codes__code_available;
DROP INDEX IF EXISTS public.ix_referrals__referrer;
DROP INDEX IF EXISTS public.ix_referrals__master;
DROP INDEX IF EXISTS public.ix_ref_rewards__referrer_status;
DROP INDEX IF EXISTS public.ix_ref_rewards__referrer_created;
DROP INDEX IF EXISTS public.ix_ref_rewards__referred;
DROP INDEX IF EXISTS public.ix_orders__street_id;
DROP INDEX IF EXISTS public.ix_orders__status_city_timeslot_start;
DROP INDEX IF EXISTS public.ix_orders__status_city;
DROP INDEX IF EXISTS public.ix_orders__preferred_master;
DROP INDEX IF EXISTS public.ix_orders__phone;
DROP INDEX IF EXISTS public.ix_orders__guarantee_source;
DROP INDEX IF EXISTS public.ix_orders__district_id;
DROP INDEX IF EXISTS public.ix_orders__created_at;
DROP INDEX IF EXISTS public.ix_orders__city_status;
DROP INDEX IF EXISTS public.ix_orders__city_id;
DROP INDEX IF EXISTS public.ix_orders__category;
DROP INDEX IF EXISTS public.ix_orders__assigned_master;
DROP INDEX IF EXISTS public.ix_order_status_history__order_created_at;
DROP INDEX IF EXISTS public.ix_order_status_history__actor_type;
DROP INDEX IF EXISTS public.ix_order_autoclose_queue__pending;
DROP INDEX IF EXISTS public.ix_offers__order_state;
DROP INDEX IF EXISTS public.ix_offers__master_state;
DROP INDEX IF EXISTS public.ix_offers__expires_at;
DROP INDEX IF EXISTS public.ix_notifications_outbox_master;
DROP INDEX IF EXISTS public.ix_notifications_outbox_created;
DROP INDEX IF EXISTS public.ix_masters__verified_active_deleted_city;
DROP INDEX IF EXISTS public.ix_masters__tg_user_id;
DROP INDEX IF EXISTS public.ix_masters__referred_by;
DROP INDEX IF EXISTS public.ix_masters__phone;
DROP INDEX IF EXISTS public.ix_masters__onshift_verified;
DROP INDEX IF EXISTS public.ix_masters__mod_shift;
DROP INDEX IF EXISTS public.ix_masters__heartbeat;
DROP INDEX IF EXISTS public.ix_masters__city_id;
DROP INDEX IF EXISTS public.ix_master_skills__skill;
DROP INDEX IF EXISTS public.ix_master_invite_codes__code;
DROP INDEX IF EXISTS public.ix_master_invite_codes__available;
DROP INDEX IF EXISTS public.ix_master_districts__district;
DROP INDEX IF EXISTS public.ix_geocache_created_at;
DROP INDEX IF EXISTS public.ix_districts__city_id;
DROP INDEX IF EXISTS public.ix_distribution_metrics__performance;
DROP INDEX IF EXISTS public.ix_distribution_metrics__city_assigned;
DROP INDEX IF EXISTS public.ix_distribution_metrics__assigned_at_desc;
DROP INDEX IF EXISTS public.ix_commissions__status_deadline;
DROP INDEX IF EXISTS public.ix_commissions__master_status;
DROP INDEX IF EXISTS public.ix_commissions__ispaid_deadline;
DROP INDEX IF EXISTS public.ix_commission_deadline_notifications__commission;
DROP INDEX IF EXISTS public.ix_attachments__etype_eid;
DROP INDEX IF EXISTS public.ix_admin_audit_log_master_id;
DROP INDEX IF EXISTS public.ix_admin_audit_log_created_at;
DROP INDEX IF EXISTS public.ix_admin_audit_log_admin_id;
DROP INDEX IF EXISTS public.idx_distribution_metrics_order_id;
DROP INDEX IF EXISTS public.idx_distribution_metrics_master_id;
DROP INDEX IF EXISTS public.idx_distribution_metrics_district_id;
DROP INDEX IF EXISTS public.idx_distribution_metrics_city_id;
ALTER TABLE IF EXISTS ONLY public.streets DROP CONSTRAINT IF EXISTS uq_streets__city_district_name;
ALTER TABLE IF EXISTS ONLY public.staff_access_codes DROP CONSTRAINT IF EXISTS uq_staff_access_codes__code;
ALTER TABLE IF EXISTS ONLY public.skills DROP CONSTRAINT IF EXISTS uq_skills__code;
ALTER TABLE IF EXISTS ONLY public.referrals DROP CONSTRAINT IF EXISTS uq_referrals__master_id;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS uq_referral_rewards__commission_level;
ALTER TABLE IF EXISTS ONLY public.masters DROP CONSTRAINT IF EXISTS uq_masters__tg_user_id;
ALTER TABLE IF EXISTS ONLY public.masters DROP CONSTRAINT IF EXISTS uq_masters__referral_code;
ALTER TABLE IF EXISTS ONLY public.districts DROP CONSTRAINT IF EXISTS uq_districts__city_name;
ALTER TABLE IF EXISTS ONLY public.commissions DROP CONSTRAINT IF EXISTS uq_commissions__order_id;
ALTER TABLE IF EXISTS ONLY public.commission_deadline_notifications DROP CONSTRAINT IF EXISTS uq_commission_deadline_notifications__commission_hours;
ALTER TABLE IF EXISTS ONLY public.cities DROP CONSTRAINT IF EXISTS uq_cities__name;
ALTER TABLE IF EXISTS ONLY public.streets DROP CONSTRAINT IF EXISTS pk_streets;
ALTER TABLE IF EXISTS ONLY public.staff_users DROP CONSTRAINT IF EXISTS pk_staff_users;
ALTER TABLE IF EXISTS ONLY public.staff_cities DROP CONSTRAINT IF EXISTS pk_staff_cities;
ALTER TABLE IF EXISTS ONLY public.staff_access_codes DROP CONSTRAINT IF EXISTS pk_staff_access_codes;
ALTER TABLE IF EXISTS ONLY public.staff_access_code_cities DROP CONSTRAINT IF EXISTS pk_staff_access_code_cities;
ALTER TABLE IF EXISTS ONLY public.skills DROP CONSTRAINT IF EXISTS pk_skills;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS pk_settings;
ALTER TABLE IF EXISTS ONLY public.referrals DROP CONSTRAINT IF EXISTS pk_referrals;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS pk_referral_rewards;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS pk_orders;
ALTER TABLE IF EXISTS ONLY public.order_status_history DROP CONSTRAINT IF EXISTS pk_order_status_history;
ALTER TABLE IF EXISTS ONLY public.order_autoclose_queue DROP CONSTRAINT IF EXISTS pk_order_autoclose_queue;
ALTER TABLE IF EXISTS ONLY public.offers DROP CONSTRAINT IF EXISTS pk_offers;
ALTER TABLE IF EXISTS ONLY public.notifications_outbox DROP CONSTRAINT IF EXISTS pk_notifications_outbox;
ALTER TABLE IF EXISTS ONLY public.masters DROP CONSTRAINT IF EXISTS pk_masters;
ALTER TABLE IF EXISTS ONLY public.master_skills DROP CONSTRAINT IF EXISTS pk_master_skills;
ALTER TABLE IF EXISTS ONLY public.master_invite_codes DROP CONSTRAINT IF EXISTS pk_master_invite_codes;
ALTER TABLE IF EXISTS ONLY public.master_districts DROP CONSTRAINT IF EXISTS pk_master_districts;
ALTER TABLE IF EXISTS ONLY public.geocache DROP CONSTRAINT IF EXISTS pk_geocache;
ALTER TABLE IF EXISTS ONLY public.districts DROP CONSTRAINT IF EXISTS pk_districts;
ALTER TABLE IF EXISTS ONLY public.commissions DROP CONSTRAINT IF EXISTS pk_commissions;
ALTER TABLE IF EXISTS ONLY public.cities DROP CONSTRAINT IF EXISTS pk_cities;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS pk_attachments;
ALTER TABLE IF EXISTS ONLY public.admin_audit_log DROP CONSTRAINT IF EXISTS pk_admin_audit_log;
ALTER TABLE IF EXISTS ONLY public.distribution_metrics DROP CONSTRAINT IF EXISTS distribution_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.commission_deadline_notifications DROP CONSTRAINT IF EXISTS commission_deadline_notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.streets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.staff_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.staff_access_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.skills ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.referrals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.referral_rewards ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.order_status_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.offers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications_outbox ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.masters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.master_invite_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.districts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.distribution_metrics ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.commission_deadline_notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attachments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.admin_audit_log ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.streets_id_seq;
DROP TABLE IF EXISTS public.streets;
DROP SEQUENCE IF EXISTS public.staff_users_id_seq;
DROP TABLE IF EXISTS public.staff_users;
DROP TABLE IF EXISTS public.staff_cities;
DROP SEQUENCE IF EXISTS public.staff_access_codes_id_seq;
DROP TABLE IF EXISTS public.staff_access_codes;
DROP TABLE IF EXISTS public.staff_access_code_cities;
DROP SEQUENCE IF EXISTS public.skills_id_seq;
DROP TABLE IF EXISTS public.skills;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.referrals_id_seq;
DROP TABLE IF EXISTS public.referrals;
DROP SEQUENCE IF EXISTS public.referral_rewards_id_seq;
DROP TABLE IF EXISTS public.referral_rewards;
DROP SEQUENCE IF EXISTS public.orders_id_seq;
DROP TABLE IF EXISTS public.orders;
DROP SEQUENCE IF EXISTS public.order_status_history_id_seq;
DROP TABLE IF EXISTS public.order_status_history;
DROP TABLE IF EXISTS public.order_autoclose_queue;
DROP SEQUENCE IF EXISTS public.offers_id_seq;
DROP TABLE IF EXISTS public.offers;
DROP SEQUENCE IF EXISTS public.notifications_outbox_id_seq;
DROP TABLE IF EXISTS public.notifications_outbox;
DROP SEQUENCE IF EXISTS public.masters_id_seq;
DROP TABLE IF EXISTS public.masters;
DROP TABLE IF EXISTS public.master_skills;
DROP SEQUENCE IF EXISTS public.master_invite_codes_id_seq;
DROP TABLE IF EXISTS public.master_invite_codes;
DROP TABLE IF EXISTS public.master_districts;
DROP TABLE IF EXISTS public.geocache;
DROP SEQUENCE IF EXISTS public.districts_id_seq;
DROP TABLE IF EXISTS public.districts;
DROP SEQUENCE IF EXISTS public.distribution_metrics_id_seq;
DROP TABLE IF EXISTS public.distribution_metrics;
DROP SEQUENCE IF EXISTS public.commissions_id_seq;
DROP TABLE IF EXISTS public.commissions;
DROP SEQUENCE IF EXISTS public.commission_deadline_notifications_id_seq;
DROP TABLE IF EXISTS public.commission_deadline_notifications;
DROP SEQUENCE IF EXISTS public.cities_id_seq;
DROP TABLE IF EXISTS public.cities;
DROP SEQUENCE IF EXISTS public.attachments_id_seq;
DROP TABLE IF EXISTS public.attachments;
DROP TABLE IF EXISTS public.alembic_version;
DROP SEQUENCE IF EXISTS public.admin_audit_log_id_seq;
DROP TABLE IF EXISTS public.admin_audit_log;
DROP TYPE IF EXISTS public.staff_role;
DROP TYPE IF EXISTS public.shift_status;
DROP TYPE IF EXISTS public.referral_reward_status;
DROP TYPE IF EXISTS public.payout_method;
DROP TYPE IF EXISTS public.order_type;
DROP TYPE IF EXISTS public.order_status;
DROP TYPE IF EXISTS public.order_category;
DROP TYPE IF EXISTS public.offer_state;
DROP TYPE IF EXISTS public.moderation_status;
DROP TYPE IF EXISTS public.commission_status;
DROP TYPE IF EXISTS public.attachment_file_type;
DROP TYPE IF EXISTS public.attachment_entity;
DROP TYPE IF EXISTS public.actor_type;
--
-- Name: actor_type; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.actor_type AS ENUM (
    'SYSTEM',
    'ADMIN',
    'MASTER',
    'AUTO_DISTRIBUTION'
);


ALTER TYPE public.actor_type OWNER TO fs_user;

--
-- Name: attachment_entity; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.attachment_entity AS ENUM (
    'ORDER',
    'OFFER',
    'COMMISSION',
    'MASTER'
);


ALTER TYPE public.attachment_entity OWNER TO fs_user;

--
-- Name: attachment_file_type; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.attachment_file_type AS ENUM (
    'PHOTO',
    'DOCUMENT',
    'AUDIO',
    'VIDEO',
    'OTHER'
);


ALTER TYPE public.attachment_file_type OWNER TO fs_user;

--
-- Name: commission_status; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.commission_status AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE',
    'WAIT_PAY',
    'REPORTED',
    'APPROVED'
);


ALTER TYPE public.commission_status OWNER TO fs_user;

--
-- Name: moderation_status; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.moderation_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.moderation_status OWNER TO fs_user;

--
-- Name: offer_state; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.offer_state AS ENUM (
    'SENT',
    'VIEWED',
    'ACCEPTED',
    'DECLINED',
    'EXPIRED',
    'CANCELED'
);


ALTER TYPE public.offer_state OWNER TO fs_user;

--
-- Name: order_category; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.order_category AS ENUM (
    'ELECTRICS',
    'PLUMBING',
    'APPLIANCES',
    'WINDOWS',
    'HANDYMAN',
    'ROADSIDE'
);


ALTER TYPE public.order_category OWNER TO fs_user;

--
-- Name: order_status; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.order_status AS ENUM (
    'CREATED',
    'SEARCHING',
    'ASSIGNED',
    'EN_ROUTE',
    'WORKING',
    'PAYMENT',
    'CLOSED',
    'DEFERRED',
    'GUARANTEE',
    'CANCELED'
);


ALTER TYPE public.order_status OWNER TO fs_user;

--
-- Name: order_type; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.order_type AS ENUM (
    'NORMAL',
    'GUARANTEE'
);


ALTER TYPE public.order_type OWNER TO fs_user;

--
-- Name: payout_method; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.payout_method AS ENUM (
    'CARD',
    'SBP',
    'YOOMONEY',
    'BANK_ACCOUNT'
);


ALTER TYPE public.payout_method OWNER TO fs_user;

--
-- Name: referral_reward_status; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.referral_reward_status AS ENUM (
    'ACCRUED',
    'PAID',
    'CANCELED'
);


ALTER TYPE public.referral_reward_status OWNER TO fs_user;

--
-- Name: shift_status; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.shift_status AS ENUM (
    'SHIFT_OFF',
    'SHIFT_ON',
    'BREAK'
);


ALTER TYPE public.shift_status OWNER TO fs_user;

--
-- Name: staff_role; Type: TYPE; Schema: public; Owner: fs_user
--

CREATE TYPE public.staff_role AS ENUM (
    'ADMIN',
    'LOGIST',
    'CITY_ADMIN',
    'GLOBAL_ADMIN'
);


ALTER TYPE public.staff_role OWNER TO fs_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.admin_audit_log (
    id integer NOT NULL,
    admin_id integer,
    master_id integer,
    action character varying(64) NOT NULL,
    payload_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_audit_log OWNER TO fs_user;

--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.admin_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_audit_log_id_seq OWNER TO fs_user;

--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.admin_audit_log_id_seq OWNED BY public.admin_audit_log.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO fs_user;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.attachments (
    id integer NOT NULL,
    entity_type public.attachment_entity NOT NULL,
    entity_id bigint NOT NULL,
    file_type public.attachment_file_type NOT NULL,
    file_id character varying(256) NOT NULL,
    file_unique_id character varying(256),
    file_name character varying(256),
    mime_type character varying(128),
    size integer,
    caption text,
    uploaded_by_master_id integer,
    uploaded_by_staff_id integer,
    created_at timestamp with time zone DEFAULT now(),
    document_type character varying(32)
);


ALTER TABLE public.attachments OWNER TO fs_user;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attachments_id_seq OWNER TO fs_user;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: cities; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.cities (
    id integer NOT NULL,
    name character varying(120) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    timezone character varying(64),
    centroid_lat double precision,
    centroid_lon double precision
);


ALTER TABLE public.cities OWNER TO fs_user;

--
-- Name: cities_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.cities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cities_id_seq OWNER TO fs_user;

--
-- Name: cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.cities_id_seq OWNED BY public.cities.id;


--
-- Name: commission_deadline_notifications; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.commission_deadline_notifications (
    id integer NOT NULL,
    commission_id integer NOT NULL,
    hours_before smallint NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT commission_deadline_notifications_hours_before_check CHECK ((hours_before = ANY (ARRAY[1, 6, 24])))
);


ALTER TABLE public.commission_deadline_notifications OWNER TO fs_user;

--
-- Name: commission_deadline_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.commission_deadline_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commission_deadline_notifications_id_seq OWNER TO fs_user;

--
-- Name: commission_deadline_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.commission_deadline_notifications_id_seq OWNED BY public.commission_deadline_notifications.id;


--
-- Name: commissions; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.commissions (
    id integer NOT NULL,
    order_id integer NOT NULL,
    master_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    percent numeric(5,2),
    status public.commission_status NOT NULL,
    deadline_at timestamp with time zone NOT NULL,
    paid_at timestamp with time zone,
    blocked_applied boolean DEFAULT false NOT NULL,
    blocked_at timestamp with time zone,
    payment_reference character varying(120),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    rate numeric(5,2),
    paid_reported_at timestamp with time zone,
    paid_approved_at timestamp with time zone,
    paid_amount numeric(10,2),
    is_paid boolean DEFAULT false NOT NULL,
    has_checks boolean DEFAULT false NOT NULL,
    pay_to_snapshot jsonb
);


ALTER TABLE public.commissions OWNER TO fs_user;

--
-- Name: commissions_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.commissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commissions_id_seq OWNER TO fs_user;

--
-- Name: commissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.commissions_id_seq OWNED BY public.commissions.id;


--
-- Name: distribution_metrics; Type: TABLE; Schema: public; Owner: field_user
--

CREATE TABLE public.distribution_metrics (
    id integer NOT NULL,
    order_id integer NOT NULL,
    master_id integer,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    round_number smallint NOT NULL,
    candidates_count smallint NOT NULL,
    time_to_assign_seconds integer,
    preferred_master_used boolean DEFAULT false NOT NULL,
    was_escalated_to_logist boolean DEFAULT false NOT NULL,
    was_escalated_to_admin boolean DEFAULT false NOT NULL,
    city_id integer NOT NULL,
    district_id integer,
    category character varying(32),
    order_type character varying(32),
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.distribution_metrics OWNER TO field_user;

--
-- Name: distribution_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: field_user
--

CREATE SEQUENCE public.distribution_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.distribution_metrics_id_seq OWNER TO field_user;

--
-- Name: distribution_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: field_user
--

ALTER SEQUENCE public.distribution_metrics_id_seq OWNED BY public.distribution_metrics.id;


--
-- Name: districts; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.districts (
    id integer NOT NULL,
    city_id integer NOT NULL,
    name character varying(120) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    centroid_lat double precision,
    centroid_lon double precision
);


ALTER TABLE public.districts OWNER TO fs_user;

--
-- Name: districts_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.districts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.districts_id_seq OWNER TO fs_user;

--
-- Name: districts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.districts_id_seq OWNED BY public.districts.id;


--
-- Name: geocache; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.geocache (
    query character varying(255) NOT NULL,
    lat double precision,
    lon double precision,
    provider character varying(32),
    confidence integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.geocache OWNER TO fs_user;

--
-- Name: master_districts; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.master_districts (
    master_id integer NOT NULL,
    district_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.master_districts OWNER TO fs_user;

--
-- Name: master_invite_codes; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.master_invite_codes (
    id integer NOT NULL,
    code character varying(32) NOT NULL,
    city_id integer,
    issued_by_staff_id integer,
    used_by_master_id integer,
    expires_at timestamp with time zone,
    is_revoked boolean DEFAULT false NOT NULL,
    used_at timestamp with time zone,
    comment character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.master_invite_codes OWNER TO fs_user;

--
-- Name: master_invite_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.master_invite_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.master_invite_codes_id_seq OWNER TO fs_user;

--
-- Name: master_invite_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.master_invite_codes_id_seq OWNED BY public.master_invite_codes.id;


--
-- Name: master_skills; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.master_skills (
    master_id integer NOT NULL,
    skill_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.master_skills OWNER TO fs_user;

--
-- Name: masters; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.masters (
    id integer NOT NULL,
    tg_user_id bigint,
    full_name character varying(160) NOT NULL,
    phone character varying(32),
    city_id integer,
    rating double precision DEFAULT '5'::double precision NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    blocked_at timestamp with time zone,
    blocked_reason text,
    referral_code character varying(32),
    referred_by_master_id integer,
    last_heartbeat_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    version integer DEFAULT 1 NOT NULL,
    moderation_status public.moderation_status DEFAULT 'PENDING'::public.moderation_status NOT NULL,
    moderation_note text,
    shift_status public.shift_status DEFAULT 'SHIFT_OFF'::public.shift_status NOT NULL,
    break_until timestamp with time zone,
    pdn_accepted_at timestamp with time zone,
    payout_method public.payout_method,
    payout_data jsonb,
    has_vehicle boolean DEFAULT false NOT NULL,
    vehicle_plate character varying(16),
    home_latitude numeric(9,6),
    home_longitude numeric(9,6),
    max_active_orders_override smallint,
    is_on_shift boolean DEFAULT false NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    is_deleted boolean NOT NULL,
    moderation_reason text,
    verified_at timestamp with time zone,
    verified_by integer,
    telegram_username character varying(64),
    first_name character varying(80),
    last_name character varying(120),
    CONSTRAINT ck_masters__ck_masters__limit_nonneg CHECK (((max_active_orders_override IS NULL) OR (max_active_orders_override >= 0)))
);


ALTER TABLE public.masters OWNER TO fs_user;

--
-- Name: masters_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.masters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.masters_id_seq OWNER TO fs_user;

--
-- Name: masters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.masters_id_seq OWNED BY public.masters.id;


--
-- Name: notifications_outbox; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.notifications_outbox (
    id integer NOT NULL,
    master_id integer NOT NULL,
    event character varying(64) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone,
    attempt_count integer NOT NULL,
    last_error text
);


ALTER TABLE public.notifications_outbox OWNER TO fs_user;

--
-- Name: notifications_outbox_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.notifications_outbox_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_outbox_id_seq OWNER TO fs_user;

--
-- Name: notifications_outbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.notifications_outbox_id_seq OWNED BY public.notifications_outbox.id;


--
-- Name: offers; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.offers (
    id integer NOT NULL,
    order_id integer NOT NULL,
    master_id integer NOT NULL,
    round_number smallint DEFAULT '1'::smallint NOT NULL,
    state public.offer_state NOT NULL,
    sent_at timestamp with time zone DEFAULT now(),
    responded_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.offers OWNER TO fs_user;

--
-- Name: offers_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.offers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.offers_id_seq OWNER TO fs_user;

--
-- Name: offers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.offers_id_seq OWNED BY public.offers.id;


--
-- Name: order_autoclose_queue; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.order_autoclose_queue (
    order_id integer NOT NULL,
    closed_at timestamp with time zone NOT NULL,
    autoclose_at timestamp with time zone NOT NULL,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_autoclose_queue OWNER TO fs_user;

--
-- Name: order_status_history; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.order_status_history (
    id integer NOT NULL,
    order_id integer NOT NULL,
    from_status public.order_status,
    to_status public.order_status NOT NULL,
    reason text,
    changed_by_staff_id integer,
    changed_by_master_id integer,
    created_at timestamp with time zone DEFAULT now(),
    actor_type public.actor_type DEFAULT 'SYSTEM'::public.actor_type NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.order_status_history OWNER TO fs_user;

--
-- Name: order_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.order_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_status_history_id_seq OWNER TO fs_user;

--
-- Name: order_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.order_status_history_id_seq OWNED BY public.order_status_history.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    city_id integer NOT NULL,
    district_id integer,
    street_id integer,
    house character varying(32),
    apartment character varying(32),
    address_comment text,
    client_name character varying(160),
    client_phone character varying(32),
    status public.order_status DEFAULT 'CREATED'::public.order_status NOT NULL,
    preferred_master_id integer,
    assigned_master_id integer,
    created_by_staff_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    version integer DEFAULT 1 NOT NULL,
    company_payment numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    guarantee_source_order_id integer,
    order_type public.order_type DEFAULT 'NORMAL'::public.order_type NOT NULL,
    category public.order_category,
    description text,
    late_visit boolean DEFAULT false NOT NULL,
    dist_escalated_logist_at timestamp with time zone,
    dist_escalated_admin_at timestamp with time zone,
    lat numeric(9,6),
    lon numeric(9,6),
    timeslot_start_utc timestamp with time zone,
    timeslot_end_utc timestamp with time zone,
    total_sum numeric(10,2) NOT NULL,
    cancel_reason text,
    no_district boolean NOT NULL,
    type public.order_type NOT NULL,
    geocode_provider character varying(32),
    geocode_confidence integer,
    escalation_logist_notified_at timestamp with time zone,
    escalation_admin_notified_at timestamp with time zone,
    CONSTRAINT ck_orders__timeslot_range CHECK ((((timeslot_start_utc IS NULL) AND (timeslot_end_utc IS NULL)) OR (timeslot_start_utc < timeslot_end_utc)))
);


ALTER TABLE public.orders OWNER TO fs_user;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO fs_user;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: referral_rewards; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.referral_rewards (
    id integer NOT NULL,
    referrer_id integer NOT NULL,
    referred_master_id integer NOT NULL,
    commission_id integer NOT NULL,
    level smallint NOT NULL,
    percent numeric(5,2) NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public.referral_reward_status NOT NULL,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.referral_rewards OWNER TO fs_user;

--
-- Name: referral_rewards_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.referral_rewards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.referral_rewards_id_seq OWNER TO fs_user;

--
-- Name: referral_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.referral_rewards_id_seq OWNED BY public.referral_rewards.id;


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.referrals (
    id integer NOT NULL,
    master_id integer NOT NULL,
    referrer_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.referrals OWNER TO fs_user;

--
-- Name: referrals_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.referrals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.referrals_id_seq OWNER TO fs_user;

--
-- Name: referrals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.referrals_id_seq OWNED BY public.referrals.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.settings (
    key character varying(80) NOT NULL,
    value text NOT NULL,
    value_type character varying(16) DEFAULT 'STR'::character varying NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.settings OWNER TO fs_user;

--
-- Name: skills; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.skills (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(160) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.skills OWNER TO fs_user;

--
-- Name: skills_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.skills_id_seq OWNER TO fs_user;

--
-- Name: skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.skills_id_seq OWNED BY public.skills.id;


--
-- Name: staff_access_code_cities; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.staff_access_code_cities (
    access_code_id integer NOT NULL,
    city_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.staff_access_code_cities OWNER TO fs_user;

--
-- Name: staff_access_codes; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.staff_access_codes (
    id integer NOT NULL,
    code character varying(16) NOT NULL,
    role public.staff_role NOT NULL,
    city_id integer,
    created_by_staff_id integer,
    used_by_staff_id integer,
    expires_at timestamp with time zone,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    comment text,
    revoked_at timestamp with time zone
);


ALTER TABLE public.staff_access_codes OWNER TO fs_user;

--
-- Name: staff_access_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.staff_access_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_access_codes_id_seq OWNER TO fs_user;

--
-- Name: staff_access_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.staff_access_codes_id_seq OWNED BY public.staff_access_codes.id;


--
-- Name: staff_cities; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.staff_cities (
    staff_user_id integer NOT NULL,
    city_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.staff_cities OWNER TO fs_user;

--
-- Name: staff_users; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.staff_users (
    id integer NOT NULL,
    tg_user_id bigint,
    username character varying(64),
    full_name character varying(160),
    phone character varying(32),
    role public.staff_role NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    commission_requisites jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.staff_users OWNER TO fs_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.staff_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.staff_users_id_seq OWNER TO fs_user;

--
-- Name: staff_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.staff_users_id_seq OWNED BY public.staff_users.id;


--
-- Name: streets; Type: TABLE; Schema: public; Owner: fs_user
--

CREATE TABLE public.streets (
    id integer NOT NULL,
    city_id integer NOT NULL,
    district_id integer,
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    centroid_lat double precision,
    centroid_lon double precision
);


ALTER TABLE public.streets OWNER TO fs_user;

--
-- Name: streets_id_seq; Type: SEQUENCE; Schema: public; Owner: fs_user
--

CREATE SEQUENCE public.streets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.streets_id_seq OWNER TO fs_user;

--
-- Name: streets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fs_user
--

ALTER SEQUENCE public.streets_id_seq OWNED BY public.streets.id;


--
-- Name: admin_audit_log id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.admin_audit_log ALTER COLUMN id SET DEFAULT nextval('public.admin_audit_log_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: cities id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.cities ALTER COLUMN id SET DEFAULT nextval('public.cities_id_seq'::regclass);


--
-- Name: commission_deadline_notifications id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commission_deadline_notifications ALTER COLUMN id SET DEFAULT nextval('public.commission_deadline_notifications_id_seq'::regclass);


--
-- Name: commissions id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commissions ALTER COLUMN id SET DEFAULT nextval('public.commissions_id_seq'::regclass);


--
-- Name: distribution_metrics id; Type: DEFAULT; Schema: public; Owner: field_user
--

ALTER TABLE ONLY public.distribution_metrics ALTER COLUMN id SET DEFAULT nextval('public.distribution_metrics_id_seq'::regclass);


--
-- Name: districts id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.districts ALTER COLUMN id SET DEFAULT nextval('public.districts_id_seq'::regclass);


--
-- Name: master_invite_codes id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_invite_codes ALTER COLUMN id SET DEFAULT nextval('public.master_invite_codes_id_seq'::regclass);


--
-- Name: masters id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.masters ALTER COLUMN id SET DEFAULT nextval('public.masters_id_seq'::regclass);


--
-- Name: notifications_outbox id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.notifications_outbox ALTER COLUMN id SET DEFAULT nextval('public.notifications_outbox_id_seq'::regclass);


--
-- Name: offers id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.offers ALTER COLUMN id SET DEFAULT nextval('public.offers_id_seq'::regclass);


--
-- Name: order_status_history id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.order_status_history ALTER COLUMN id SET DEFAULT nextval('public.order_status_history_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: referral_rewards id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referral_rewards ALTER COLUMN id SET DEFAULT nextval('public.referral_rewards_id_seq'::regclass);


--
-- Name: referrals id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referrals ALTER COLUMN id SET DEFAULT nextval('public.referrals_id_seq'::regclass);


--
-- Name: skills id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.skills ALTER COLUMN id SET DEFAULT nextval('public.skills_id_seq'::regclass);


--
-- Name: staff_access_codes id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_codes ALTER COLUMN id SET DEFAULT nextval('public.staff_access_codes_id_seq'::regclass);


--
-- Name: staff_users id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_users ALTER COLUMN id SET DEFAULT nextval('public.staff_users_id_seq'::regclass);


--
-- Name: streets id; Type: DEFAULT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.streets ALTER COLUMN id SET DEFAULT nextval('public.streets_id_seq'::regclass);


--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.admin_audit_log (id, admin_id, master_id, action, payload_json, created_at) FROM stdin;
11	5	3434	approve_master	{}	2025-10-17 18:13:58.295666+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.alembic_version (version_num) FROM stdin;
2025_10_16_0002
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.attachments (id, entity_type, entity_id, file_type, file_id, file_unique_id, file_name, mime_type, size, caption, uploaded_by_master_id, uploaded_by_staff_id, created_at, document_type) FROM stdin;
12	MASTER	3434	DOCUMENT	BQACAgIAAxkBAAIMf2jygw6gKhSl3ha1AAEx7C3eRK-KfQACS4MAAjGXkEv6vlW2rueszzYE	\N	\N	\N	\N	\N	3434	\N	2025-10-17 17:55:45.115776+00	passport
13	MASTER	3434	PHOTO	AgACAgIAAxkBAAIMgWjygxWZHJEUaglbr5iYgKe4Zc8XAAIY-TEbMZeQS67tIC4nJ_mqAQADAgADeQADNgQ	\N	\N	\N	\N	\N	3434	\N	2025-10-17 17:55:45.115776+00	selfie
14	ORDER	306	DOCUMENT	BQACAgIAAxkBAAIMl2jyiHMWLjMxFcrhjcltp-T8gXqtAAKdgwACMZeQS_SAlcSVF3uoNgQ	\N	\N	\N	\N	\N	3434	\N	2025-10-17 18:18:27.569755+00	\N
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.cities (id, name, is_active, created_at, updated_at, timezone, centroid_lat, centroid_lon) FROM stdin;
1000001	Москва	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000002	Санкт-Петербург	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000003	Новосибирск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Novosibirsk	\N	\N
1000004	Екатеринбург	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000005	Казань	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000006	Нижний Новгород	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000007	Челябинск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000008	Красноярск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Krasnoyarsk	\N	\N
1000009	Самара	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Samara	\N	\N
1000010	Уфа	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000011	Ростов-на-Дону	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000012	Краснодар	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000013	Омск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Omsk	\N	\N
1000014	Воронеж	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000015	Пермь	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000016	Волгоград	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Volgograd	\N	\N
1000017	Саратов	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Saratov	\N	\N
1000018	Тюмень	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000019	Тольятти	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Samara	\N	\N
1000020	Ижевск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Samara	\N	\N
1000021	Барнаул	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Barnaul	\N	\N
1000022	Ульяновск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Ulyanovsk	\N	\N
1000023	Иркутск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Irkutsk	\N	\N
1000024	Хабаровск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Vladivostok	\N	\N
1000025	Владивосток	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Vladivostok	\N	\N
1000026	Ярославль	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000027	Махачкала	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000028	Томск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Tomsk	\N	\N
1000029	Оренбург	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000030	Кемерово	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Novokuznetsk	\N	\N
1000031	Новокузнецк	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Novokuznetsk	\N	\N
1000032	Рязань	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000033	Набережные Челны	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000034	Астрахань	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Astrakhan	\N	\N
1000035	Пенза	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000036	Киров	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Kirov	\N	\N
1000037	Липецк	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000038	Чебоксары	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000039	Калининград	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Kaliningrad	\N	\N
1000040	Тула	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000041	Курск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000042	Сочи	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000043	Ставрополь	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000044	Балашиха	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000045	Севастополь	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Simferopol	\N	\N
1000046	Брянск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000047	Белгород	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000048	Магнитогорск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000049	Великий Новгород	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000050	Калуга	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000051	Сургут	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000052	Владикавказ	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000053	Чита	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Chita	\N	\N
1000054	Симферополь	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Simferopol	\N	\N
1000055	Волжский	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Volgograd	\N	\N
1000056	Смоленск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000057	Саранск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000058	Курган	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000059	Орёл	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000060	Подольск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000061	Архангельск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000062	Грозный	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000063	Якутск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yakutsk	\N	\N
1000064	Тверь	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000065	Старый Оскол	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000066	Улан-Удэ	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Irkutsk	\N	\N
1000067	Нижний Тагил	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000068	Нижневартовск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000069	Псков	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000070	Йошкар-Ола	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000071	Кострома	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000072	Новороссийск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000073	Дзержинск	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000074	Таганрог	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000075	Химки	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
1000076	Березники	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Asia/Yekaterinburg	\N	\N
1000077	Энгельс	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Saratov	\N	\N
1000078	Шахты	t	2025-10-17 07:31:18.818171+00	2025-10-17 07:31:18.818171+00	Europe/Moscow	\N	\N
\.


--
-- Data for Name: commission_deadline_notifications; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.commission_deadline_notifications (id, commission_id, hours_before, sent_at) FROM stdin;
10	6	24	2025-10-17 18:21:08.155915+00
11	6	6	2025-10-17 18:21:08.155915+00
\.


--
-- Data for Name: commissions; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.commissions (id, order_id, master_id, amount, percent, status, deadline_at, paid_at, blocked_applied, blocked_at, payment_reference, created_at, updated_at, rate, paid_reported_at, paid_approved_at, paid_amount, is_paid, has_checks, pay_to_snapshot) FROM stdin;
6	306	3434	2500.00	\N	APPROVED	2025-10-17 21:18:27.600123+00	\N	f	\N	\N	2025-10-17 18:18:27.569755+00	2025-10-17 18:22:22.908827+00	0.50	\N	2025-10-17 18:22:22.923548+00	2500.00	t	f	{"comment": "Commission #306", "methods": [], "sbp_bank": null, "card_bank": null, "other_text": null, "card_holder": null, "sbp_qr_file_id": null, "sbp_phone_masked": null, "card_number_last4": null}
\.


--
-- Data for Name: distribution_metrics; Type: TABLE DATA; Schema: public; Owner: field_user
--

COPY public.distribution_metrics (id, order_id, master_id, assigned_at, round_number, candidates_count, time_to_assign_seconds, preferred_master_used, was_escalated_to_logist, was_escalated_to_admin, city_id, district_id, category, order_type, metadata_json, created_at) FROM stdin;
1	306	3434	2025-10-17 18:17:16.690638+00	1	1	79	f	f	f	1000023	3687	ELECTRICS	NORMAL	{"from_status": "SEARCHING", "accepted_via": "orders_service"}	2025-10-17 18:17:16.62674+00
\.


--
-- Data for Name: districts; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.districts (id, city_id, name, created_at, centroid_lat, centroid_lon) FROM stdin;
3461	1000003	Центральный район	2025-10-17 07:31:56.898942+00	55.0415	82.9346
3462	1000003	Железнодорожный район	2025-10-17 07:31:56.898942+00	55.0451	82.8934
3463	1000003	Заельцовский район	2025-10-17 07:31:56.898942+00	54.9884	83.0065
3464	1000003	Ленинский район	2025-10-17 07:31:56.898942+00	55.0271	82.9557
3465	1000003	Дзержинский район	2025-10-17 07:31:56.898942+00	55.053	82.8934
3466	1000003	Калининский район	2025-10-17 07:31:56.898942+00	54.8996	82.9863
3467	1000003	Кировский район	2025-10-17 07:31:56.898942+00	54.9924	83.0868
3468	1000003	Октябрьский район	2025-10-17 07:31:56.898942+00	55.0828	82.9478
3469	1000003	Первомайский район	2025-10-17 07:31:56.898942+00	54.9721	82.8934
3470	1000003	Советский район	2025-10-17 07:31:56.898942+00	55.0656	83.0198
3471	1000004	Верх-Исетский район	2025-10-17 07:31:56.898942+00	56.8176	60.581
3472	1000004	Железнодорожный район	2025-10-17 07:31:56.898942+00	56.8389	60.585
3473	1000004	Кировский район	2025-10-17 07:31:56.898942+00	56.8857	60.6458
3474	1000004	Ленинский район	2025-10-17 07:31:56.898942+00	56.8019	60.6343
3475	1000004	Октябрьский район	2025-10-17 07:31:56.898942+00	56.8697	60.6047
3476	1000004	Орджоникидзевский район	2025-10-17 07:31:56.898942+00	56.9057	60.5647
3477	1000004	Чкаловский район	2025-10-17 07:31:56.898942+00	56.7915	60.7011
3478	1000005	Авиастроительный район	2025-10-17 07:31:56.898942+00	55.8583	49.2111
3479	1000005	Вахитовский район	2025-10-17 07:31:56.898942+00	55.7887	49.1221
3480	1000005	Кировский район	2025-10-17 07:31:56.898942+00	55.8268	49.0866
3481	1000005	Московский район	2025-10-17 07:31:56.898942+00	55.7534	49.2002
3482	1000005	Ново-Савиновский район	2025-10-17 07:31:56.898942+00	55.8167	49.1333
3483	1000005	Приволжский район	2025-10-17 07:31:56.898942+00	55.7291	49.1543
3484	1000005	Советский район	2025-10-17 07:31:56.898942+00	55.7977	49.1092
3485	1000006	Автозаводский район	2025-10-17 07:31:56.898942+00	56.2545	43.8433
3486	1000006	Канавинский район	2025-10-17 07:31:56.898942+00	56.3344	43.9442
3487	1000006	Ленинский район	2025-10-17 07:31:56.898942+00	56.2861	43.9408
3488	1000006	Московский район	2025-10-17 07:31:56.898942+00	56.2935	44.007
3489	1000006	Нижегородский район	2025-10-17 07:31:56.898942+00	56.3269	44.0075
3490	1000006	Приокский район	2025-10-17 07:31:56.898942+00	56.2304	43.9171
3491	1000006	Советский район	2025-10-17 07:31:56.898942+00	56.3153	43.9973
3492	1000006	Сормовский район	2025-10-17 07:31:56.898942+00	56.3574	43.8197
3493	1000007	Центральный район	2025-10-17 07:31:56.898942+00	55.1644	61.4368
3494	1000007	Калининский район	2025-10-17 07:31:56.898942+00	55.1898	61.317
3495	1000007	Курчатовский район	2025-10-17 07:31:56.898942+00	55.1283	61.5661
3496	1000007	Ленинский район	2025-10-17 07:31:56.898942+00	55.1923	61.3854
3497	1000007	Металлургический район	2025-10-17 07:31:56.898942+00	55.149	61.2894
3498	1000007	Советский район	2025-10-17 07:31:56.898942+00	55.2095	61.3418
3499	1000007	Тракторозаводский район	2025-10-17 07:31:56.898942+00	55.1827	61.2525
3500	1000008	Центральный район	2025-10-17 07:31:56.898942+00	56.0153	92.8932
3501	1000008	Железнодорожный район	2025-10-17 07:31:56.898942+00	56.0184	92.952
3502	1000008	Кировский район	2025-10-17 07:31:56.898942+00	56.0796	92.9225
3503	1000008	Ленинский район	2025-10-17 07:31:56.898942+00	55.9976	92.7966
3504	1000008	Октябрьский район	2025-10-17 07:31:56.898942+00	56.0596	92.9696
3505	1000008	Свердловский район	2025-10-17 07:31:56.898942+00	56.0447	92.9167
3506	1000008	Советский район	2025-10-17 07:31:56.898942+00	56.084	92.8394
3507	1000009	Железнодорожный район	2025-10-17 07:31:56.898942+00	53.1977	50.1347
3508	1000009	Кировский район	2025-10-17 07:31:56.898942+00	53.2576	50.221
3509	1000009	Красноглинский район	2025-10-17 07:31:56.898942+00	53.3003	50.2569
3510	1000009	Куйбышевский район	2025-10-17 07:31:56.898942+00	53.2224	50.2788
3511	1000009	Ленинский район	2025-10-17 07:31:56.898942+00	53.1917	50.1105
3512	1000009	Октябрьский район	2025-10-17 07:31:56.898942+00	53.2221	50.1598
3513	1000009	Промышленный район	2025-10-17 07:31:56.898942+00	53.2715	50.3168
3514	1000009	Самарский район	2025-10-17 07:31:56.898942+00	53.1959	50.1034
3515	1000009	Советский район	2025-10-17 07:31:56.898942+00	53.2401	50.2011
3516	1000010	Демский район	2025-10-17 07:31:56.898942+00	54.7765	56.0435
3517	1000010	Калининский район	2025-10-17 07:31:56.898942+00	54.7351	55.9579
3518	1000010	Кировский район	2025-10-17 07:31:56.898942+00	54.7431	56.0016
3519	1000010	Ленинский район	2025-10-17 07:31:56.898942+00	54.7143	55.9465
3520	1000010	Октябрьский район	2025-10-17 07:31:56.898942+00	54.807	56.0642
3521	1000010	Орджоникидзевский район	2025-10-17 07:31:56.898942+00	54.7679	56.0885
3522	1000010	Советский район	2025-10-17 07:31:56.898942+00	54.7543	55.9872
3523	1000012	Центральный внутригородской округ	2025-10-17 07:31:56.898942+00	45.0355	38.9753
3524	1000012	Западный внутригородской округ	2025-10-17 07:31:56.898942+00	45.0598	38.9129
3525	1000012	Карасунский внутригородской округ	2025-10-17 07:31:56.898942+00	45.0186	39.0091
3526	1000012	Прикубанский внутригородской округ	2025-10-17 07:31:56.898942+00	45.0808	39.0401
3527	1000013	Центральный административный округ	2025-10-17 07:31:56.898942+00	54.9885	73.3242
3528	1000013	Кировский административный округ	2025-10-17 07:31:56.898942+00	54.9509	73.3848
3529	1000013	Ленинский административный округ	2025-10-17 07:31:56.898942+00	54.966	73.4415
3530	1000013	Октябрьский административный округ	2025-10-17 07:31:56.898942+00	54.9991	73.368
3531	1000013	Советский административный округ	2025-10-17 07:31:56.898942+00	55.0294	73.2758
3532	1000014	Центральный район	2025-10-17 07:31:56.898942+00	51.6605	39.2002
3533	1000014	Железнодорожный район	2025-10-17 07:31:56.898942+00	51.7034	39.1548
3534	1000014	Коминтерновский район	2025-10-17 07:31:56.898942+00	51.6271	39.2707
3535	1000014	Ленинский район	2025-10-17 07:31:56.898942+00	51.6904	39.1842
3536	1000014	Левобережный район	2025-10-17 07:31:56.898942+00	51.6137	39.0964
3537	1000014	Советский район	2025-10-17 07:31:56.898942+00	51.5538	39.0632
3538	1000015	Дзержинский район	2025-10-17 07:31:56.898942+00	58.0105	56.2502
3539	1000015	Индустриальный район	2025-10-17 07:31:56.898942+00	58.0455	56.3173
3540	1000015	Кировский район	2025-10-17 07:31:56.898942+00	57.9876	56.1735
3541	1000015	Ленинский район	2025-10-17 07:31:56.898942+00	58.0036	56.2294
3542	1000015	Мотовилихинский район	2025-10-17 07:31:56.898942+00	58.0304	56.2085
3543	1000015	Орджоникидзевский район	2025-10-17 07:31:56.898942+00	58.0598	56.3301
3544	1000015	Свердловский район	2025-10-17 07:31:56.898942+00	57.9933	56.3018
3545	1000016	Центральный район	2025-10-17 07:31:56.898942+00	48.708	44.5133
3546	1000016	Дзержинский район	2025-10-17 07:31:56.898942+00	48.7968	44.5828
3547	1000016	Ворошиловский район	2025-10-17 07:31:56.898942+00	48.6917	44.4801
3548	1000016	Кировский район	2025-10-17 07:31:56.898942+00	48.4707	44.5361
3549	1000016	Краснооктябрьский район	2025-10-17 07:31:56.898942+00	48.7502	44.4946
3550	1000016	Красноармейский район	2025-10-17 07:31:56.898942+00	48.5661	44.5566
3551	1000016	Советский район	2025-10-17 07:31:56.898942+00	48.6549	44.4291
3552	1000016	Тракторозаводский район	2025-10-17 07:31:56.898942+00	48.7994	44.7311
3553	1000017	Волжский район	2025-10-17 07:31:56.898942+00	51.5951	46.0357
3554	1000017	Заводской район	2025-10-17 07:31:56.898942+00	51.4977	46.1263
3555	1000017	Кировский район	2025-10-17 07:31:56.898942+00	51.5642	46.0001
3556	1000017	Ленинский район	2025-10-17 07:31:56.898942+00	51.5336	46.0343
3557	1000017	Октябрьский район	2025-10-17 07:31:56.898942+00	51.5745	45.9693
3558	1000017	Фрунзенский район	2025-10-17 07:31:56.898942+00	51.4891	46.0881
3559	1000018	Центральный административный округ	2025-10-17 07:31:56.898942+00	57.1522	65.5272
3560	1000018	Восточный административный округ	2025-10-17 07:31:56.898942+00	57.1385	65.5843
3561	1000018	Калининский административный округ	2025-10-17 07:31:56.898942+00	57.1829	65.5341
3562	1000018	Ленинский административный округ	2025-10-17 07:31:56.898942+00	57.1267	65.4563
3563	1000019	Автозаводский район	2025-10-17 07:31:56.898942+00	53.5303	49.3461
3564	1000019	Центральный район	2025-10-17 07:31:56.898942+00	53.5078	49.4201
3565	1000019	Комсомольский район	2025-10-17 07:31:56.898942+00	53.552	49.2826
3566	1000020	Индустриальный район	2025-10-17 07:31:56.898942+00	56.8664	53.2878
3567	1000020	Ленинский район	2025-10-17 07:31:56.898942+00	56.8431	53.2024
3568	1000020	Октябрьский район	2025-10-17 07:31:56.898942+00	56.8719	53.2327
3569	1000020	Первомайский район	2025-10-17 07:31:56.898942+00	56.8219	53.2542
3570	1000020	Устиновский район	2025-10-17 07:31:56.898942+00	56.8983	53.2662
3571	1000022	Железнодорожный район	2025-10-17 07:31:56.898942+00	54.3146	48.3704
3572	1000022	Заволжский район	2025-10-17 07:31:56.898942+00	54.3625	48.4074
3573	1000022	Ленинский район	2025-10-17 07:31:56.898942+00	54.3166	48.3953
3574	1000022	Засвияжский район	2025-10-17 07:31:56.898942+00	54.3474	48.3325
3575	1000021	Центральный район	2025-10-17 07:31:56.898942+00	53.3477	83.7798
3576	1000021	Железнодорожный район	2025-10-17 07:31:56.898942+00	53.3245	83.6949
3577	1000021	Индустриальный район	2025-10-17 07:31:56.898942+00	53.3918	83.7423
3578	1000021	Ленинский район	2025-10-17 07:31:56.898942+00	53.3606	83.7539
3579	1000021	Октябрьский район	2025-10-17 07:31:56.898942+00	53.3139	83.7736
3580	1000025	Ленинский район	2025-10-17 07:31:56.898942+00	43.1332	131.9113
3581	1000025	Первомайский район	2025-10-17 07:31:56.898942+00	43.2394	132.0547
3582	1000025	Первореченский район	2025-10-17 07:31:56.898942+00	43.1525	131.9448
3583	1000025	Советский район	2025-10-17 07:31:56.898942+00	43.109	131.8738
3584	1000025	Фрунзенский район	2025-10-17 07:31:56.898942+00	43.1056	131.9335
3585	1000026	Дзержинский район	2025-10-17 07:31:56.898942+00	57.6261	39.8845
3586	1000026	Заволжский район	2025-10-17 07:31:56.898942+00	57.6656	39.8045
3587	1000026	Кировский район	2025-10-17 07:31:56.898942+00	57.646	39.822
3588	1000026	Красноперекопский район	2025-10-17 07:31:56.898942+00	57.6085	39.8109
3589	1000026	Ленинский район	2025-10-17 07:31:56.898942+00	57.6298	39.8737
3590	1000026	Фрунзенский район	2025-10-17 07:31:56.898942+00	57.5965	39.9278
3591	1000024	Центральный район	2025-10-17 07:31:56.898942+00	48.4827	135.0838
3592	1000024	Железнодорожный район	2025-10-17 07:31:56.898942+00	48.5247	135.1151
3593	1000024	Индустриальный район	2025-10-17 07:31:56.898942+00	48.506	135.0598
3594	1000024	Кировский район	2025-10-17 07:31:56.898942+00	48.4406	135.1334
3595	1000029	Центральный район	2025-10-17 07:31:56.898942+00	51.7727	55.0988
3596	1000029	Дзержинский район	2025-10-17 07:31:56.898942+00	51.807	55.1647
3597	1000029	Ленинский район	2025-10-17 07:31:56.898942+00	51.7473	55.1374
3598	1000029	Промышленный район	2025-10-17 07:31:56.898942+00	51.7259	55.1643
3599	1000031	Центральный район	2025-10-17 07:31:56.898942+00	53.7557	87.1099
3600	1000031	Заводской район	2025-10-17 07:31:56.898942+00	53.7862	87.1473
3601	1000031	Кузнецкий район	2025-10-17 07:31:56.898942+00	53.719	87.1647
3602	1000031	Куйбышевский район	2025-10-17 07:31:56.898942+00	53.7355	87.0731
3603	1000031	Новоильинский район	2025-10-17 07:31:56.898942+00	53.7989	87.0871
3604	1000031	Орджоникидзевский район	2025-10-17 07:31:56.898942+00	53.8285	87.1906
3605	1000030	Центральный район	2025-10-17 07:31:56.898942+00	55.3547	86.0864
3606	1000030	Заводской район	2025-10-17 07:31:56.898942+00	55.3092	86.1239
3607	1000030	Кировский район	2025-10-17 07:31:56.898942+00	55.3355	86.0429
3608	1000030	Ленинский район	2025-10-17 07:31:56.898942+00	55.3744	86.0643
3609	1000030	Рудничный район	2025-10-17 07:31:56.898942+00	55.4028	86.1171
3610	1000032	Железнодорожный район	2025-10-17 07:31:56.898942+00	54.6269	39.7492
3611	1000032	Московский район	2025-10-17 07:31:56.898942+00	54.5965	39.6859
3612	1000032	Октябрьский район	2025-10-17 07:31:56.898942+00	54.6093	39.7186
3613	1000032	Советский район	2025-10-17 07:31:56.898942+00	54.6407	39.6916
3614	1000033	Автозаводский район	2025-10-17 07:31:56.898942+00	55.743	52.4088
3615	1000033	Центральный район	2025-10-17 07:31:56.898942+00	55.7287	52.3783
3616	1000033	Комсомольский район	2025-10-17 07:31:56.898942+00	55.7	52.3249
3617	1000034	Кировский район	2025-10-17 07:31:56.898942+00	46.3497	48.0342
3618	1000034	Ленинский район	2025-10-17 07:31:56.898942+00	46.3576	48.0594
3619	1000034	Советский район	2025-10-17 07:31:56.898942+00	46.3397	48.0213
3620	1000034	Трусовский район	2025-10-17 07:31:56.898942+00	46.3103	48.0751
3621	1000035	Железнодорожный район	2025-10-17 07:31:56.898942+00	53.2001	45.0047
3622	1000035	Ленинский район	2025-10-17 07:31:56.898942+00	53.1956	44.9953
3623	1000035	Октябрьский район	2025-10-17 07:31:56.898942+00	53.2153	45.0157
3624	1000035	Первомайский район	2025-10-17 07:31:56.898942+00	53.1753	45.0343
3625	1000036	Ленинский район	2025-10-17 07:31:56.898942+00	58.6035	49.6679
3626	1000036	Октябрьский район	2025-10-17 07:31:56.898942+00	58.5939	49.5948
3627	1000036	Первомайский район	2025-10-17 07:31:56.898942+00	58.5706	49.6384
3628	1000036	Нововятский район	2025-10-17 07:31:56.898942+00	58.6173	49.7341
3629	1000037	Левобережный округ	2025-10-17 07:31:56.898942+00	52.6031	39.5708
3630	1000037	Правобережный округ	2025-10-17 07:31:56.898942+00	52.6108	39.5997
3631	1000037	Советский округ	2025-10-17 07:31:56.898942+00	52.6227	39.6493
3632	1000037	Октябрьский округ	2025-10-17 07:31:56.898942+00	52.5843	39.6287
3633	1000038	Калининский район	2025-10-17 07:31:56.898942+00	56.1324	47.2519
3634	1000038	Ленинский район	2025-10-17 07:31:56.898942+00	56.1185	47.2854
3635	1000038	Московский район	2025-10-17 07:31:56.898942+00	56.1439	47.2087
3636	1000039	Центральный район	2025-10-17 07:31:56.898942+00	54.7104	20.4522
3637	1000039	Балтийский район	2025-10-17 07:31:56.898942+00	54.7065	20.5065
3638	1000039	Ленинградский район	2025-10-17 07:31:56.898942+00	54.7305	20.5131
3639	1000039	Московский район	2025-10-17 07:31:56.898942+00	54.6887	20.5449
3640	1000028	Кировский район	2025-10-17 07:31:56.898942+00	56.4977	84.9744
3641	1000028	Ленинский район	2025-10-17 07:31:56.898942+00	56.4584	84.9476
3642	1000028	Октябрьский район	2025-10-17 07:31:56.898942+00	56.4691	84.9912
3643	1000028	Советский район	2025-10-17 07:31:56.898942+00	56.5015	85.0061
3644	1000027	Кировский район	2025-10-17 07:31:56.898942+00	42.9849	47.5047
3645	1000027	Ленинский район	2025-10-17 07:31:56.898942+00	42.9634	47.5228
3646	1000027	Советский район	2025-10-17 07:31:56.898942+00	43.0018	47.4754
3647	1000001	Центральный административный округ	2025-10-17 07:39:14.357102+00	55.7558	37.6173
3648	1000001	Северный административный округ	2025-10-17 07:39:14.357102+00	55.85	37.52
3649	1000001	Северо-Восточный административный округ	2025-10-17 07:39:14.357102+00	55.87	37.65
3650	1000001	Восточный административный округ	2025-10-17 07:39:14.357102+00	55.75	37.8
3651	1000001	Юго-Восточный административный округ	2025-10-17 07:39:14.357102+00	55.68	37.75
3652	1000001	Южный административный округ	2025-10-17 07:39:14.357102+00	55.62	37.6
3653	1000001	Юго-Западный административный округ	2025-10-17 07:39:14.357102+00	55.65	37.52
3654	1000001	Западный административный округ	2025-10-17 07:39:14.357102+00	55.74	37.45
3655	1000001	Северо-Западный административный округ	2025-10-17 07:39:14.357102+00	55.82	37.45
3656	1000001	Зеленоградский административный округ	2025-10-17 07:39:14.357102+00	55.98	37.2
3657	1000001	Троицкий административный округ	2025-10-17 07:39:14.357102+00	55.48	37.3
3658	1000001	Новомосковский административный округ	2025-10-17 07:39:14.357102+00	55.55	37.37
3659	1000002	Адмиралтейский район	2025-10-17 07:39:14.357102+00	59.92	30.3
3660	1000002	Василеостровский район	2025-10-17 07:39:14.357102+00	59.94	30.27
3661	1000002	Выборгский район	2025-10-17 07:39:14.357102+00	60.05	30.35
3662	1000002	Калининский район	2025-10-17 07:39:14.357102+00	60.02	30.4
3663	1000002	Кировский район	2025-10-17 07:39:14.357102+00	59.87	30.26
3664	1000002	Колпинский район	2025-10-17 07:39:14.357102+00	59.75	30.59
3665	1000002	Красногвардейский район	2025-10-17 07:39:14.357102+00	59.97	30.46
3666	1000002	Красносельский район	2025-10-17 07:39:14.357102+00	59.75	30.09
3667	1000002	Кронштадтский район	2025-10-17 07:39:14.357102+00	60	29.77
3668	1000002	Курортный район	2025-10-17 07:39:14.357102+00	60.15	29.95
3669	1000002	Московский район	2025-10-17 07:39:14.357102+00	59.87	30.32
3670	1000002	Невский район	2025-10-17 07:39:14.357102+00	59.9	30.48
3671	1000002	Петроградский район	2025-10-17 07:39:14.357102+00	59.96	30.31
3672	1000002	Петродворцовый район	2025-10-17 07:39:14.357102+00	59.88	29.9
3673	1000002	Приморский район	2025-10-17 07:39:14.357102+00	60	30.25
3674	1000002	Пушкинский район	2025-10-17 07:39:14.357102+00	59.7	30.4
3675	1000002	Фрунзенский район	2025-10-17 07:39:14.357102+00	59.85	30.4
3676	1000002	Центральный район	2025-10-17 07:39:14.357102+00	59.93	30.36
3677	1000011	Ворошиловский район	2025-10-17 07:39:14.357102+00	47.24	39.7
3678	1000011	Железнодорожный район	2025-10-17 07:39:14.357102+00	47.26	39.75
3679	1000011	Кировский район	2025-10-17 07:39:14.357102+00	47.21	39.63
3680	1000011	Ленинский район	2025-10-17 07:39:14.357102+00	47.23	39.68
3681	1000011	Октябрьский район	2025-10-17 07:39:14.357102+00	47.27	39.65
3682	1000011	Первомайский район	2025-10-17 07:39:14.357102+00	47.2	39.62
3683	1000011	Пролетарский район	2025-10-17 07:39:14.357102+00	47.21	39.74
3684	1000011	Советский район	2025-10-17 07:39:14.357102+00	47.25	39.72
3685	1000023	Правобережный округ	2025-10-17 07:39:14.357102+00	52.28	104.28
3686	1000023	Свердловский округ	2025-10-17 07:39:14.357102+00	52.29	104.32
3687	1000023	Октябрьский округ	2025-10-17 07:39:14.357102+00	52.27	104.35
3688	1000023	Ленинский округ	2025-10-17 07:39:14.357102+00	52.29	104.24
3689	1000042	Центральный район	2025-10-17 07:39:14.357102+00	43.585	39.72
3690	1000042	Адлерский район	2025-10-17 07:39:14.357102+00	43.43	39.92
3691	1000042	Хостинский район	2025-10-17 07:39:14.357102+00	43.51	39.88
3692	1000042	Лазаревский район	2025-10-17 07:39:14.357102+00	43.9	39.33
3693	1000043	Ленинский район	2025-10-17 07:39:14.357102+00	45.05	41.97
3694	1000043	Октябрьский район	2025-10-17 07:39:14.357102+00	45.04	41.99
3695	1000043	Промышленный район	2025-10-17 07:39:14.357102+00	45.02	42.02
3696	1000061	Ломоносовский округ	2025-10-17 07:39:14.357102+00	64.54	40.54
3697	1000061	Майская горка	2025-10-17 07:39:14.357102+00	64.56	40.59
3698	1000061	Октябрьский округ	2025-10-17 07:39:14.357102+00	64.55	40.52
3699	1000061	Соломбальский округ	2025-10-17 07:39:14.357102+00	64.58	40.5
3700	1000061	Цигломенский округ	2025-10-17 07:39:14.357102+00	64.6	40.48
3701	1000047	Восточный округ	2025-10-17 07:39:14.357102+00	50.6	36.6
3702	1000047	Западный округ	2025-10-17 07:39:14.357102+00	50.59	36.57
3703	1000047	Юго-Западный округ	2025-10-17 07:39:14.357102+00	50.58	36.58
3704	1000046	Бежицкий район	2025-10-17 07:39:14.357102+00	53.22	34.36
3705	1000046	Володарский район	2025-10-17 07:39:14.357102+00	53.27	34.42
3706	1000046	Советский район	2025-10-17 07:39:14.357102+00	53.25	34.37
3707	1000046	Фокинский район	2025-10-17 07:39:14.357102+00	53.28	34.3
3708	1000049	Западный	2025-10-17 07:39:14.357102+00	58.52	31.25
3709	1000049	Центральный	2025-10-17 07:39:14.357102+00	58.54	31.28
3710	1000049	Восточный	2025-10-17 07:39:14.357102+00	58.53	31.31
3711	1000052	Иристонский район	2025-10-17 07:39:14.357102+00	43.02	44.68
3712	1000052	Промышленный район	2025-10-17 07:39:14.357102+00	43.04	44.66
3713	1000052	Затеречный район	2025-10-17 07:39:14.357102+00	43.03	44.69
3714	1000052	Северо-Западный район	2025-10-17 07:39:14.357102+00	43.05	44.65
3715	1000062	Ахматовский район	2025-10-17 07:39:14.357102+00	43.32	45.69
3716	1000062	Ленинский район	2025-10-17 07:39:14.357102+00	43.31	45.7
3717	1000062	Октябрьский район	2025-10-17 07:39:14.357102+00	43.33	45.68
3718	1000062	Старопромысловский район	2025-10-17 07:39:14.357102+00	43.3	45.72
3719	1000050	Ленинский округ	2025-10-17 07:39:14.357102+00	54.53	36.27
3720	1000050	Московский округ	2025-10-17 07:39:14.357102+00	54.55	36.25
3721	1000050	Октябрьский округ	2025-10-17 07:39:14.357102+00	54.52	36.29
3722	1000058	Центральный	2025-10-17 07:39:14.357102+00	55.45	65.34
3723	1000058	Заозерный	2025-10-17 07:39:14.357102+00	55.43	65.32
3724	1000058	Рябково	2025-10-17 07:39:14.357102+00	55.46	65.36
3725	1000041	Центральный округ	2025-10-17 07:39:14.357102+00	51.73	36.19
3726	1000041	Железнодорожный округ	2025-10-17 07:39:14.357102+00	51.74	36.21
3727	1000041	Сеймский округ	2025-10-17 07:39:14.357102+00	51.71	36.17
3728	1000048	Ленинский район	2025-10-17 07:39:14.357102+00	53.41	59.05
3729	1000048	Орджоникидзевский район	2025-10-17 07:39:14.357102+00	53.39	59.08
3730	1000048	Правобережный район	2025-10-17 07:39:14.357102+00	53.42	59.12
3731	1000067	Ленинский район	2025-10-17 07:39:14.357102+00	57.92	59.96
3732	1000067	Дзержинский район	2025-10-17 07:39:14.357102+00	57.9	59.98
3733	1000067	Тагилстроевский район	2025-10-17 07:39:14.357102+00	57.94	60
3734	1000059	Заводской район	2025-10-17 07:39:14.357102+00	52.97	36.07
3735	1000059	Железнодорожный район	2025-10-17 07:39:14.357102+00	52.98	36.09
3736	1000059	Северный район	2025-10-17 07:39:14.357102+00	53	36.08
3737	1000059	Советский район	2025-10-17 07:39:14.357102+00	52.96	36.06
3738	1000069	Центр	2025-10-17 07:39:14.357102+00	57.81	28.33
3739	1000069	Запсковье	2025-10-17 07:39:14.357102+00	57.82	28.32
3740	1000069	Завеличье	2025-10-17 07:39:14.357102+00	57.8	28.31
3741	1000057	Ленинский район	2025-10-17 07:39:14.357102+00	54.19	45.18
3742	1000057	Октябрьский район	2025-10-17 07:39:14.357102+00	54.17	45.2
3743	1000057	Пролетарский район	2025-10-17 07:39:14.357102+00	54.18	45.16
3744	1000045	Балаклавский район	2025-10-17 07:39:14.357102+00	44.5	33.6
3745	1000045	Гагаринский район	2025-10-17 07:39:14.357102+00	44.62	33.52
3746	1000045	Ленинский район	2025-10-17 07:39:14.357102+00	44.6	33.53
3747	1000045	Нахимовский район	2025-10-17 07:39:14.357102+00	44.61	33.55
3748	1000054	Центральный район	2025-10-17 07:39:14.357102+00	44.95	34.1
3749	1000054	Киевский район	2025-10-17 07:39:14.357102+00	44.94	34.08
3750	1000054	Железнодорожный район	2025-10-17 07:39:14.357102+00	44.96	34.12
3751	1000056	Ленинский район	2025-10-17 07:39:14.357102+00	54.79	32.05
3752	1000056	Заднепровский район	2025-10-17 07:39:14.357102+00	54.81	32.07
3753	1000056	Промышленный район	2025-10-17 07:39:14.357102+00	54.77	32.03
3754	1000064	Центральный район	2025-10-17 07:39:14.357102+00	56.86	35.91
3755	1000064	Заволжский район	2025-10-17 07:39:14.357102+00	56.88	35.93
3756	1000064	Московский район	2025-10-17 07:39:14.357102+00	56.84	35.89
3757	1000064	Пролетарский район	2025-10-17 07:39:14.357102+00	56.85	35.95
3758	1000040	Зареченский район	2025-10-17 07:39:14.357102+00	54.19	37.61
3759	1000040	Привокзальный район	2025-10-17 07:39:14.357102+00	54.2	37.62
3760	1000040	Пролетарский район	2025-10-17 07:39:14.357102+00	54.21	37.6
3761	1000040	Советский район	2025-10-17 07:39:14.357102+00	54.18	37.59
3762	1000040	Центральный район	2025-10-17 07:39:14.357102+00	54.2	37.63
3763	1000066	Железнодорожный район	2025-10-17 07:39:14.357102+00	51.83	107.6
3764	1000066	Октябрьский район	2025-10-17 07:39:14.357102+00	51.84	107.62
3765	1000066	Советский район	2025-10-17 07:39:14.357102+00	51.82	107.58
3766	1000053	Центральный район	2025-10-17 07:39:14.357102+00	52.03	113.5
3767	1000053	Ингодинский район	2025-10-17 07:39:14.357102+00	52.01	113.48
3768	1000053	Железнодорожный район	2025-10-17 07:39:14.357102+00	52.04	113.52
3769	1000053	Черновский район	2025-10-17 07:39:14.357102+00	52.02	113.46
3770	1000063	Автодорожный округ	2025-10-17 07:39:14.357102+00	62.03	129.73
3771	1000063	Гагаринский округ	2025-10-17 07:39:14.357102+00	62.04	129.71
3772	1000063	Октябрьский округ	2025-10-17 07:39:14.357102+00	62.02	129.75
3773	1000063	Промышленный округ	2025-10-17 07:39:14.357102+00	62.01	129.69
3774	1000063	Сайсарский округ	2025-10-17 07:39:14.357102+00	62.05	129.77
3775	1000063	Строительный округ	2025-10-17 07:39:14.357102+00	62	129.72
3776	1000044	Центральный	2025-10-17 07:39:14.357102+00	55.8	37.96
3777	1000044	Железнодорожный	2025-10-17 07:39:14.357102+00	55.74	38.02
3778	1000044	Новокосино	2025-10-17 07:39:14.357102+00	55.74	37.86
3779	1000060	Центр	2025-10-17 07:39:14.357102+00	55.42	37.55
3780	1000060	Кузнечики	2025-10-17 07:39:14.357102+00	55.4	37.57
3781	1000060	Шепчинки	2025-10-17 07:39:14.357102+00	55.43	37.53
3782	1000075	Центр	2025-10-17 07:39:14.357102+00	55.89	37.43
3783	1000075	Левобережный	2025-10-17 07:39:14.357102+00	55.88	37.45
3784	1000075	Планерная	2025-10-17 07:39:14.357102+00	55.9	37.41
3785	1000055	Центральный	2025-10-17 07:39:14.357102+00	48.79	44.78
3786	1000055	Южный	2025-10-17 07:39:14.357102+00	48.77	44.76
3787	1000055	Северный	2025-10-17 07:39:14.357102+00	48.81	44.8
3788	1000073	Центральный	2025-10-17 07:39:14.357102+00	56.24	43.46
3789	1000073	Восточный	2025-10-17 07:39:14.357102+00	56.25	43.48
3790	1000073	Западный	2025-10-17 07:39:14.357102+00	56.23	43.44
3791	1000074	Центральный	2025-10-17 07:39:14.357102+00	47.22	38.92
3792	1000074	Западный	2025-10-17 07:39:14.357102+00	47.21	38.9
3793	1000074	Восточный	2025-10-17 07:39:14.357102+00	47.23	38.94
3794	1000072	Центральный	2025-10-17 07:39:14.357102+00	44.72	37.77
3795	1000072	Южный	2025-10-17 07:39:14.357102+00	44.7	37.75
3796	1000072	Восточный	2025-10-17 07:39:14.357102+00	44.73	37.79
3797	1000078	Центральный	2025-10-17 07:39:14.357102+00	47.71	40.22
3798	1000078	Западный	2025-10-17 07:39:14.357102+00	47.7	40.2
3799	1000078	Восточный	2025-10-17 07:39:14.357102+00	47.72	40.24
3800	1000077	Центральный	2025-10-17 07:39:14.357102+00	51.48	46.12
3801	1000077	Южный	2025-10-17 07:39:14.357102+00	51.47	46.1
3802	1000077	Северный	2025-10-17 07:39:14.357102+00	51.49	46.14
3803	1000051	Центральный	2025-10-17 07:39:14.357102+00	61.25	73.39
3804	1000051	Северный	2025-10-17 07:39:14.357102+00	61.27	73.41
3805	1000051	Южный	2025-10-17 07:39:14.357102+00	61.23	73.37
3806	1000068	Центральный	2025-10-17 07:39:14.357102+00	60.93	76.56
3807	1000068	Северный	2025-10-17 07:39:14.357102+00	60.95	76.58
3808	1000068	Южный	2025-10-17 07:39:14.357102+00	60.91	76.54
3809	1000076	Центральный	2025-10-17 07:39:14.357102+00	59.41	56.82
3810	1000076	Усольский	2025-10-17 07:39:14.357102+00	59.39	56.8
3811	1000076	Ленинский	2025-10-17 07:39:14.357102+00	59.42	56.84
3812	1000065	Центральный	2025-10-17 07:39:14.357102+00	51.3	37.84
3813	1000065	Юго-Западный	2025-10-17 07:39:14.357102+00	51.28	37.82
3814	1000065	Северо-Восточный	2025-10-17 07:39:14.357102+00	51.32	37.86
3815	1000070	Центральный	2025-10-17 07:39:14.357102+00	56.63	47.89
3816	1000070	Заречный	2025-10-17 07:39:14.357102+00	56.62	47.91
3817	1000070	Ленинский	2025-10-17 07:39:14.357102+00	56.64	47.87
3818	1000071	Центральный	2025-10-17 07:39:14.357102+00	57.77	40.93
3819	1000071	Фабричный	2025-10-17 07:39:14.357102+00	57.76	40.91
3820	1000071	Заволжский	2025-10-17 07:39:14.357102+00	57.78	40.95
\.


--
-- Data for Name: geocache; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.geocache (query, lat, lon, provider, confidence, created_at) FROM stdin;
\.


--
-- Data for Name: master_districts; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.master_districts (master_id, district_id, created_at) FROM stdin;
3434	3688	2025-10-17 17:55:45.115776+00
3434	3685	2025-10-17 17:55:45.115776+00
3434	3686	2025-10-17 17:55:45.115776+00
3434	3687	2025-10-17 17:55:45.115776+00
\.


--
-- Data for Name: master_invite_codes; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.master_invite_codes (id, code, city_id, issued_by_staff_id, used_by_master_id, expires_at, is_revoked, used_at, comment, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: master_skills; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.master_skills (master_id, skill_id, created_at) FROM stdin;
3434	267	2025-10-17 17:55:45.115776+00
3434	268	2025-10-17 17:55:45.115776+00
3434	269	2025-10-17 17:55:45.115776+00
3434	270	2025-10-17 17:55:45.115776+00
3434	271	2025-10-17 17:55:45.115776+00
3434	272	2025-10-17 17:55:45.115776+00
\.


--
-- Data for Name: masters; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.masters (id, tg_user_id, full_name, phone, city_id, rating, is_active, is_blocked, blocked_at, blocked_reason, referral_code, referred_by_master_id, last_heartbeat_at, created_at, updated_at, version, moderation_status, moderation_note, shift_status, break_until, pdn_accepted_at, payout_method, payout_data, has_vehicle, vehicle_plate, home_latitude, home_longitude, max_active_orders_override, is_on_shift, verified, is_deleted, moderation_reason, verified_at, verified_by, telegram_username, first_name, last_name) FROM stdin;
3434	332786197	Симзиков Владислав Андреевич	+79017927122	1000023	5	t	f	\N	\N	\N	\N	\N	2025-10-17 07:43:46.141178+00	2025-10-17 18:15:22.167085+00	1	APPROVED	\N	SHIFT_ON	\N	2025-10-17 17:55:45.199142+00	SBP	{"sbp_phone": "+79017927122"}	t	\N	\N	\N	\N	t	t	f	\N	2025-10-17 18:13:58.289334+00	5	\N	\N	\N
3378	10000	Load Test Master 1	+79000010000	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3379	10001	Load Test Master 2	+79000010001	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3380	10002	Load Test Master 3	+79000010002	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3381	10003	Load Test Master 4	+79000010003	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3382	10004	Load Test Master 5	+79000010004	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3383	10005	Load Test Master 6	+79000010005	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3384	10006	Load Test Master 7	+79000010006	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3385	10007	Load Test Master 8	+79000010007	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3386	10008	Load Test Master 9	+79000010008	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3387	10009	Load Test Master 10	+79000010009	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3388	10010	Load Test Master 11	+79000010010	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3389	10011	Load Test Master 12	+79000010011	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3390	10012	Load Test Master 13	+79000010012	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3391	10013	Load Test Master 14	+79000010013	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3392	10014	Load Test Master 15	+79000010014	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3393	10015	Load Test Master 16	+79000010015	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3394	10016	Load Test Master 17	+79000010016	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3395	10017	Load Test Master 18	+79000010017	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3396	10018	Load Test Master 19	+79000010018	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
3397	10019	Load Test Master 20	+79000010019	\N	4.5	t	f	\N	\N	\N	\N	\N	2025-10-15 13:18:42.563481+00	2025-10-15 13:18:42.563481+00	1	PENDING	\N	SHIFT_OFF	\N	\N	\N	\N	t	\N	\N	\N	\N	t	t	f	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: notifications_outbox; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.notifications_outbox (id, master_id, event, payload, created_at, processed_at, attempt_count, last_error) FROM stdin;
46	3434	moderation_approved	{"message": " <b> !</b>\\n\\n    .    ."}	2025-10-17 18:13:58.325479+00	2025-10-17 18:14:19.949522+00	1	\N
47	3434	moderation_update	{"message": "✅ Ваша анкета одобрена. Теперь вам доступны заявки."}	2025-10-17 18:13:58.336123+00	2025-10-17 18:14:20.048774+00	1	\N
48	3434	new_offer	{"city": "Иркутск", "message": " <b>  #306</b>\\n\\n Иркутск, Октябрьский округ\\n 05:00-08:00\\n  \\n\\n    .", "category": " ", "district": "Октябрьский округ", "order_id": 306, "timeslot": "05:00-08:00"}	2025-10-17 18:16:02.18722+00	2025-10-17 18:16:26.757095+00	1	\N
\.


--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.offers (id, order_id, master_id, round_number, state, sent_at, responded_at, expires_at, created_at) FROM stdin;
2918	306	3434	1	ACCEPTED	2025-10-17 18:16:02.229758+00	2025-10-17 18:17:16.62674+00	2025-10-17 18:18:02.229758+00	2025-10-17 18:16:02.18722+00
\.


--
-- Data for Name: order_autoclose_queue; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.order_autoclose_queue (order_id, closed_at, autoclose_at, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: order_status_history; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.order_status_history (id, order_id, from_status, to_status, reason, changed_by_staff_id, changed_by_master_id, created_at, actor_type, context) FROM stdin;
267	306	\N	SEARCHING	created_by_staff	5	\N	2025-10-17 18:15:56.800082+00	ADMIN	{"action": "order_creation", "staff_id": 5, "staff_name": "Superuser", "is_guarantee": false, "initial_status": "SEARCHING", "deferred_reason": null, "has_preferred_master": false}
268	306	SEARCHING	ASSIGNED	accepted_by_master	\N	3434	2025-10-17 18:17:16.62674+00	MASTER	{"action": "offer_accepted", "method": "atomic_accept", "offer_id": 2918, "master_id": 3434}
269	306	ASSIGNED	EN_ROUTE	master_en_route	\N	3434	2025-10-17 18:18:08.520026+00	MASTER	{}
270	306	EN_ROUTE	WORKING	master_working	\N	3434	2025-10-17 18:18:10.905945+00	MASTER	{}
271	306	WORKING	PAYMENT	master_uploaded_act	\N	3434	2025-10-17 18:18:27.569755+00	MASTER	{}
272	306	CLOSED	CLOSED	commission_paid	5	\N	2025-10-17 18:22:22.908827+00	ADMIN	{}
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.orders (id, city_id, district_id, street_id, house, apartment, address_comment, client_name, client_phone, status, preferred_master_id, assigned_master_id, created_by_staff_id, created_at, updated_at, version, company_payment, guarantee_source_order_id, order_type, category, description, late_visit, dist_escalated_logist_at, dist_escalated_admin_at, lat, lon, timeslot_start_utc, timeslot_end_utc, total_sum, cancel_reason, no_district, type, geocode_provider, geocode_confidence, escalation_logist_notified_at, escalation_admin_notified_at) FROM stdin;
306	1000023	3687	\N	-	\N	\N		+79037897878	CLOSED	\N	3434	5	2025-10-17 18:15:56.800082+00	2025-10-17 18:22:22.908827+00	4	0.00	\N	NORMAL	ELECTRICS	   : ⚡ Электрика	f	\N	\N	52.270000	104.350000	2025-10-18 02:00:00+00	2025-10-18 05:00:00+00	5000.00	\N	f	NORMAL	district_centroid	60	\N	\N
\.


--
-- Data for Name: referral_rewards; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.referral_rewards (id, referrer_id, referred_master_id, commission_id, level, percent, amount, status, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.referrals (id, master_id, referrer_id, created_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.settings (key, value, value_type, description, created_at, updated_at) FROM stdin;
commission_percent_default	0	INT	Комиссия по умолчанию (не используется для гарантий)	2025-09-17 13:59:33.664919+00	2025-09-17 13:59:33.664919+00
working_hours_end	20:00	TIME	Конец рабочего окна	2025-09-18 06:42:52.661539+00	2025-09-18 06:42:52.661539+00
slot_step_minutes	120	INT	Шаг генерации слотов (мин)	2025-09-18 06:42:52.661539+00	2025-09-18 06:42:52.661539+00
distribution_sla_seconds	120	INT	SLA оффера (сек)	2025-09-18 06:42:52.661539+00	2025-09-18 06:42:52.661539+00
distribution_rounds	2	INT	Круги до эскалации	2025-09-18 06:42:52.661539+00	2025-09-18 06:42:52.661539+00
working_hours_start	10:00	TIME	Начало рабочего окна	2025-09-18 06:42:52.661539+00	2025-09-18 07:01:50.172923+00
owner_pay_methods_enabled	["card", "sbp"]	JSON	Разрешённые методы оплаты комиссии	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
commission_deadline_hours	3	INT	Дедлайн оплаты комиссии (часы)	2025-09-18 06:42:52.661539+00	2025-09-18 07:02:03.551941+00
DISTRIBUTION_ROUNDS	1	STR	\N	2025-09-18 12:59:11.24868+00	2025-09-18 12:59:11.24868+00
owner_pay_card_number	2200123456789000	STR	Номер карты (без пробелов)	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
DISTRIBUTION_SLA_SECONDS	120	STR	\N	2025-09-18 12:57:03.641588+00	2025-09-18 14:59:09.102792+00
distribution_tick_seconds	30	INT	Период тика распределения (сек)	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
distribution_log_topn	10	INT	Сколько кандидатов писать в лог	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
escalate_to_admin_after_min	10	INT	Через сколько минут после логиста эскалировать админу	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
owner_pay_card_holder	Иванов И.И.	STR	Держатель карты	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
owner_pay_card_bank	Т-Банк	STR	Банк	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
owner_pay_sbp_phone	+79998987800	STR	Телефон СБП	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
owner_pay_sbp_bank	Т-Банк	STR	Банк СБП	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
owner_pay_sbp_qr_file_id		STR	QR file_id (Telegram)	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
alerts_channel_id	-1002959114551	INT	Telegram channel for alerts	2025-10-03 17:10:52.822413+00	2025-10-03 17:10:52.822413+00
logs_channel_id	-1003026745283	INT	Telegram channel for logs	2025-10-03 17:10:52.822413+00	2025-10-03 17:10:52.822413+00
reports_channel_id	-1003056834543	INT	Telegram channel for reports	2025-10-03 17:10:52.822413+00	2025-10-03 17:10:52.822413+00
max_active_orders	5	INT	Лимит активных заказов на мастера	2025-09-17 13:59:33.664919+00	2025-10-10 14:52:13.198009+00
owner_pay_other_text		STR	Иной способ (текст)	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
owner_pay_comment_template	Комиссия #<order_id> от <master_fio>	STR	Шаблон комментария к платежу	2025-09-19 08:15:40.241585+00	2025-09-19 08:15:40.241585+00
\.


--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.skills (id, code, name, is_active, created_at) FROM stdin;
267	ELEC	Электрика	t	2025-10-15 13:18:08.882378+00
268	PLUM	Сантехника	t	2025-10-17 07:31:57.343751+00
269	APPL	Бытовая техника	t	2025-10-17 07:31:57.343751+00
270	WIND	Окна	t	2025-10-17 07:31:57.343751+00
271	HAND	Универсал на час	t	2025-10-17 07:31:57.343751+00
272	ROAD	Автопомощь	t	2025-10-17 07:31:57.343751+00
\.


--
-- Data for Name: staff_access_code_cities; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.staff_access_code_cities (access_code_id, city_id, created_at) FROM stdin;
\.


--
-- Data for Name: staff_access_codes; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.staff_access_codes (id, code, role, city_id, created_by_staff_id, used_by_staff_id, expires_at, used_at, created_at, comment, revoked_at) FROM stdin;
\.


--
-- Data for Name: staff_cities; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.staff_cities (staff_user_id, city_id, created_at) FROM stdin;
\.


--
-- Data for Name: staff_users; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.staff_users (id, tg_user_id, username, full_name, phone, role, is_active, created_at, updated_at, commission_requisites) FROM stdin;
4	777000	\N	\N	\N	GLOBAL_ADMIN	f	2025-09-18 14:56:42.316315+00	2025-09-18 14:56:42.316315+00	{"SBP": "+79991234567", "CARD": "4000000000000002"}
6	987654321	admin2	Secondary Admin	+79876543210	ADMIN	t	2025-10-03 18:09:52.812416+00	2025-10-03 18:09:52.812416+00	{}
1	\N	admin_demo	Админ Демо	\N	GLOBAL_ADMIN	t	2025-09-18 07:00:17.292073+00	2025-10-03 18:14:23.081897+00	{}
5	332786197	your_username	Superuser	+your_phone	GLOBAL_ADMIN	t	2025-10-03 18:09:52.812416+00	2025-10-03 18:41:31.911608+00	{}
7	5639433843	shortooo	shortooo		GLOBAL_ADMIN	t	2025-10-04 07:12:00.842626+00	2025-10-04 08:23:33.523779+00	{}
9	8212329751	top_disp	top_disp		CITY_ADMIN	t	2025-10-04 08:36:58.820652+00	2025-10-04 08:37:35.930535+00	{}
8	6022057382	regizdrou	regizdrou		GLOBAL_ADMIN	t	2025-10-04 07:26:29.087208+00	2025-10-09 14:01:18.849974+00	{}
\.


--
-- Data for Name: streets; Type: TABLE DATA; Schema: public; Owner: fs_user
--

COPY public.streets (id, city_id, district_id, name, created_at, centroid_lat, centroid_lon) FROM stdin;
\.


--
-- Name: admin_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.admin_audit_log_id_seq', 11, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.attachments_id_seq', 14, true);


--
-- Name: cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.cities_id_seq', 1000078, true);


--
-- Name: commission_deadline_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.commission_deadline_notifications_id_seq', 11, true);


--
-- Name: commissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.commissions_id_seq', 6, true);


--
-- Name: distribution_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: field_user
--

SELECT pg_catalog.setval('public.distribution_metrics_id_seq', 1, true);


--
-- Name: districts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.districts_id_seq', 3820, true);


--
-- Name: master_invite_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.master_invite_codes_id_seq', 1, false);


--
-- Name: masters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.masters_id_seq', 3434, true);


--
-- Name: notifications_outbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.notifications_outbox_id_seq', 48, true);


--
-- Name: offers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.offers_id_seq', 2918, true);


--
-- Name: order_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.order_status_history_id_seq', 272, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.orders_id_seq', 306, true);


--
-- Name: referral_rewards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.referral_rewards_id_seq', 1, false);


--
-- Name: referrals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.referrals_id_seq', 1, false);


--
-- Name: skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.skills_id_seq', 272, true);


--
-- Name: staff_access_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.staff_access_codes_id_seq', 4, true);


--
-- Name: staff_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.staff_users_id_seq', 9, true);


--
-- Name: streets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fs_user
--

SELECT pg_catalog.setval('public.streets_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: commission_deadline_notifications commission_deadline_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commission_deadline_notifications
    ADD CONSTRAINT commission_deadline_notifications_pkey PRIMARY KEY (id);


--
-- Name: distribution_metrics distribution_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: field_user
--

ALTER TABLE ONLY public.distribution_metrics
    ADD CONSTRAINT distribution_metrics_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_log pk_admin_audit_log; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT pk_admin_audit_log PRIMARY KEY (id);


--
-- Name: attachments pk_attachments; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT pk_attachments PRIMARY KEY (id);


--
-- Name: cities pk_cities; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT pk_cities PRIMARY KEY (id);


--
-- Name: commissions pk_commissions; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT pk_commissions PRIMARY KEY (id);


--
-- Name: districts pk_districts; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT pk_districts PRIMARY KEY (id);


--
-- Name: geocache pk_geocache; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.geocache
    ADD CONSTRAINT pk_geocache PRIMARY KEY (query);


--
-- Name: master_districts pk_master_districts; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_districts
    ADD CONSTRAINT pk_master_districts PRIMARY KEY (master_id, district_id);


--
-- Name: master_invite_codes pk_master_invite_codes; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_invite_codes
    ADD CONSTRAINT pk_master_invite_codes PRIMARY KEY (id);


--
-- Name: master_skills pk_master_skills; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_skills
    ADD CONSTRAINT pk_master_skills PRIMARY KEY (master_id, skill_id);


--
-- Name: masters pk_masters; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.masters
    ADD CONSTRAINT pk_masters PRIMARY KEY (id);


--
-- Name: notifications_outbox pk_notifications_outbox; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.notifications_outbox
    ADD CONSTRAINT pk_notifications_outbox PRIMARY KEY (id);


--
-- Name: offers pk_offers; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT pk_offers PRIMARY KEY (id);


--
-- Name: order_autoclose_queue pk_order_autoclose_queue; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.order_autoclose_queue
    ADD CONSTRAINT pk_order_autoclose_queue PRIMARY KEY (order_id);


--
-- Name: order_status_history pk_order_status_history; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT pk_order_status_history PRIMARY KEY (id);


--
-- Name: orders pk_orders; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT pk_orders PRIMARY KEY (id);


--
-- Name: referral_rewards pk_referral_rewards; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT pk_referral_rewards PRIMARY KEY (id);


--
-- Name: referrals pk_referrals; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT pk_referrals PRIMARY KEY (id);


--
-- Name: settings pk_settings; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT pk_settings PRIMARY KEY (key);


--
-- Name: skills pk_skills; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT pk_skills PRIMARY KEY (id);


--
-- Name: staff_access_code_cities pk_staff_access_code_cities; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_code_cities
    ADD CONSTRAINT pk_staff_access_code_cities PRIMARY KEY (access_code_id, city_id);


--
-- Name: staff_access_codes pk_staff_access_codes; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_codes
    ADD CONSTRAINT pk_staff_access_codes PRIMARY KEY (id);


--
-- Name: staff_cities pk_staff_cities; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_cities
    ADD CONSTRAINT pk_staff_cities PRIMARY KEY (staff_user_id, city_id);


--
-- Name: staff_users pk_staff_users; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_users
    ADD CONSTRAINT pk_staff_users PRIMARY KEY (id);


--
-- Name: streets pk_streets; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.streets
    ADD CONSTRAINT pk_streets PRIMARY KEY (id);


--
-- Name: cities uq_cities__name; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT uq_cities__name UNIQUE (name);


--
-- Name: commission_deadline_notifications uq_commission_deadline_notifications__commission_hours; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commission_deadline_notifications
    ADD CONSTRAINT uq_commission_deadline_notifications__commission_hours UNIQUE (commission_id, hours_before);


--
-- Name: commissions uq_commissions__order_id; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT uq_commissions__order_id UNIQUE (order_id);


--
-- Name: districts uq_districts__city_name; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT uq_districts__city_name UNIQUE (city_id, name);


--
-- Name: masters uq_masters__referral_code; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.masters
    ADD CONSTRAINT uq_masters__referral_code UNIQUE (referral_code);


--
-- Name: masters uq_masters__tg_user_id; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.masters
    ADD CONSTRAINT uq_masters__tg_user_id UNIQUE (tg_user_id);


--
-- Name: referral_rewards uq_referral_rewards__commission_level; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT uq_referral_rewards__commission_level UNIQUE (commission_id, level);


--
-- Name: referrals uq_referrals__master_id; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT uq_referrals__master_id UNIQUE (master_id);


--
-- Name: skills uq_skills__code; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT uq_skills__code UNIQUE (code);


--
-- Name: staff_access_codes uq_staff_access_codes__code; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_codes
    ADD CONSTRAINT uq_staff_access_codes__code UNIQUE (code);


--
-- Name: streets uq_streets__city_district_name; Type: CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.streets
    ADD CONSTRAINT uq_streets__city_district_name UNIQUE (city_id, district_id, name);


--
-- Name: idx_distribution_metrics_city_id; Type: INDEX; Schema: public; Owner: field_user
--

CREATE INDEX idx_distribution_metrics_city_id ON public.distribution_metrics USING btree (city_id);


--
-- Name: idx_distribution_metrics_district_id; Type: INDEX; Schema: public; Owner: field_user
--

CREATE INDEX idx_distribution_metrics_district_id ON public.distribution_metrics USING btree (district_id);


--
-- Name: idx_distribution_metrics_master_id; Type: INDEX; Schema: public; Owner: field_user
--

CREATE INDEX idx_distribution_metrics_master_id ON public.distribution_metrics USING btree (master_id);


--
-- Name: idx_distribution_metrics_order_id; Type: INDEX; Schema: public; Owner: field_user
--

CREATE INDEX idx_distribution_metrics_order_id ON public.distribution_metrics USING btree (order_id);


--
-- Name: ix_admin_audit_log_admin_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_admin_audit_log_admin_id ON public.admin_audit_log USING btree (admin_id);


--
-- Name: ix_admin_audit_log_created_at; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_admin_audit_log_created_at ON public.admin_audit_log USING btree (created_at);


--
-- Name: ix_admin_audit_log_master_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_admin_audit_log_master_id ON public.admin_audit_log USING btree (master_id);


--
-- Name: ix_attachments__etype_eid; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_attachments__etype_eid ON public.attachments USING btree (entity_type, entity_id);


--
-- Name: ix_commission_deadline_notifications__commission; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_commission_deadline_notifications__commission ON public.commission_deadline_notifications USING btree (commission_id);


--
-- Name: ix_commissions__ispaid_deadline; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_commissions__ispaid_deadline ON public.commissions USING btree (is_paid, deadline_at);


--
-- Name: ix_commissions__master_status; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_commissions__master_status ON public.commissions USING btree (master_id, status);


--
-- Name: ix_commissions__status_deadline; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_commissions__status_deadline ON public.commissions USING btree (status, deadline_at);


--
-- Name: ix_distribution_metrics__assigned_at_desc; Type: INDEX; Schema: public; Owner: field_user
--

CREATE INDEX ix_distribution_metrics__assigned_at_desc ON public.distribution_metrics USING btree (assigned_at DESC);


--
-- Name: ix_distribution_metrics__city_assigned; Type: INDEX; Schema: public; Owner: field_user
--

CREATE INDEX ix_distribution_metrics__city_assigned ON public.distribution_metrics USING btree (city_id, assigned_at);


--
-- Name: ix_distribution_metrics__performance; Type: INDEX; Schema: public; Owner: field_user
--

CREATE INDEX ix_distribution_metrics__performance ON public.distribution_metrics USING btree (round_number, time_to_assign_seconds);


--
-- Name: ix_districts__city_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_districts__city_id ON public.districts USING btree (city_id);


--
-- Name: ix_geocache_created_at; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_geocache_created_at ON public.geocache USING btree (created_at);


--
-- Name: ix_master_districts__district; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_master_districts__district ON public.master_districts USING btree (district_id);


--
-- Name: ix_master_invite_codes__available; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE UNIQUE INDEX ix_master_invite_codes__available ON public.master_invite_codes USING btree (code) WHERE ((used_by_master_id IS NULL) AND (is_revoked = false) AND (expires_at IS NULL));


--
-- Name: ix_master_invite_codes__code; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE UNIQUE INDEX ix_master_invite_codes__code ON public.master_invite_codes USING btree (code);


--
-- Name: ix_master_skills__skill; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_master_skills__skill ON public.master_skills USING btree (skill_id);


--
-- Name: ix_masters__city_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__city_id ON public.masters USING btree (city_id);


--
-- Name: ix_masters__heartbeat; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__heartbeat ON public.masters USING btree (last_heartbeat_at);


--
-- Name: ix_masters__mod_shift; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__mod_shift ON public.masters USING btree (moderation_status, shift_status);


--
-- Name: ix_masters__onshift_verified; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__onshift_verified ON public.masters USING btree (is_on_shift, verified);


--
-- Name: ix_masters__phone; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__phone ON public.masters USING btree (phone);


--
-- Name: ix_masters__referred_by; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__referred_by ON public.masters USING btree (referred_by_master_id);


--
-- Name: ix_masters__tg_user_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__tg_user_id ON public.masters USING btree (tg_user_id);


--
-- Name: ix_masters__verified_active_deleted_city; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_masters__verified_active_deleted_city ON public.masters USING btree (verified, is_active, is_deleted, city_id);


--
-- Name: ix_notifications_outbox_created; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_notifications_outbox_created ON public.notifications_outbox USING btree (created_at);


--
-- Name: ix_notifications_outbox_master; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_notifications_outbox_master ON public.notifications_outbox USING btree (master_id);


--
-- Name: ix_offers__expires_at; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_offers__expires_at ON public.offers USING btree (expires_at);


--
-- Name: ix_offers__master_state; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_offers__master_state ON public.offers USING btree (master_id, state);


--
-- Name: ix_offers__order_state; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_offers__order_state ON public.offers USING btree (order_id, state);


--
-- Name: ix_order_autoclose_queue__pending; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_order_autoclose_queue__pending ON public.order_autoclose_queue USING btree (autoclose_at) WHERE (processed_at IS NULL);


--
-- Name: ix_order_status_history__actor_type; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_order_status_history__actor_type ON public.order_status_history USING btree (actor_type);


--
-- Name: ix_order_status_history__order_created_at; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_order_status_history__order_created_at ON public.order_status_history USING btree (order_id, created_at);


--
-- Name: ix_orders__assigned_master; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__assigned_master ON public.orders USING btree (assigned_master_id);


--
-- Name: ix_orders__category; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__category ON public.orders USING btree (category);


--
-- Name: ix_orders__city_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__city_id ON public.orders USING btree (city_id);


--
-- Name: ix_orders__city_status; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__city_status ON public.orders USING btree (city_id, status);


--
-- Name: ix_orders__created_at; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__created_at ON public.orders USING btree (created_at);


--
-- Name: ix_orders__district_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__district_id ON public.orders USING btree (district_id);


--
-- Name: ix_orders__guarantee_source; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__guarantee_source ON public.orders USING btree (guarantee_source_order_id);


--
-- Name: ix_orders__phone; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__phone ON public.orders USING btree (client_phone);


--
-- Name: ix_orders__preferred_master; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__preferred_master ON public.orders USING btree (preferred_master_id);


--
-- Name: ix_orders__status_city; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__status_city ON public.orders USING btree (status, city_id);


--
-- Name: ix_orders__status_city_timeslot_start; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__status_city_timeslot_start ON public.orders USING btree (status, city_id, timeslot_start_utc);


--
-- Name: ix_orders__street_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_orders__street_id ON public.orders USING btree (street_id);


--
-- Name: ix_ref_rewards__referred; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_ref_rewards__referred ON public.referral_rewards USING btree (referred_master_id);


--
-- Name: ix_ref_rewards__referrer_created; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_ref_rewards__referrer_created ON public.referral_rewards USING btree (referrer_id, created_at);


--
-- Name: ix_ref_rewards__referrer_status; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_ref_rewards__referrer_status ON public.referral_rewards USING btree (referrer_id, status);


--
-- Name: ix_referrals__master; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_referrals__master ON public.referrals USING btree (master_id);


--
-- Name: ix_referrals__referrer; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_referrals__referrer ON public.referrals USING btree (referrer_id);


--
-- Name: ix_staff_access_codes__code_available; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE UNIQUE INDEX ix_staff_access_codes__code_available ON public.staff_access_codes USING btree (code) WHERE ((used_by_staff_id IS NULL) AND (revoked_at IS NULL));


--
-- Name: ix_staff_cities__city_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_staff_cities__city_id ON public.staff_cities USING btree (city_id);


--
-- Name: ix_staff_cities__staff_user_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_staff_cities__staff_user_id ON public.staff_cities USING btree (staff_user_id);


--
-- Name: ix_staff_code_cities__city; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_staff_code_cities__city ON public.staff_access_code_cities USING btree (city_id);


--
-- Name: ix_staff_code_cities__code; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_staff_code_cities__code ON public.staff_access_code_cities USING btree (access_code_id);


--
-- Name: ix_staff_users__tg_user_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE UNIQUE INDEX ix_staff_users__tg_user_id ON public.staff_users USING btree (tg_user_id);


--
-- Name: ix_streets__city_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_streets__city_id ON public.streets USING btree (city_id);


--
-- Name: ix_streets__district_id; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE INDEX ix_streets__district_id ON public.streets USING btree (district_id);


--
-- Name: uix_offers__order_accepted_once; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE UNIQUE INDEX uix_offers__order_accepted_once ON public.offers USING btree (order_id) WHERE (state = 'ACCEPTED'::public.offer_state);


--
-- Name: uq_offers__order_master_active; Type: INDEX; Schema: public; Owner: fs_user
--

CREATE UNIQUE INDEX uq_offers__order_master_active ON public.offers USING btree (order_id, master_id) WHERE (state = ANY (ARRAY['SENT'::public.offer_state, 'VIEWED'::public.offer_state, 'ACCEPTED'::public.offer_state]));


--
-- Name: commission_deadline_notifications commission_deadline_notifications_commission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commission_deadline_notifications
    ADD CONSTRAINT commission_deadline_notifications_commission_id_fkey FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON DELETE CASCADE;


--
-- Name: distribution_metrics distribution_metrics_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: field_user
--

ALTER TABLE ONLY public.distribution_metrics
    ADD CONSTRAINT distribution_metrics_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: distribution_metrics distribution_metrics_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: field_user
--

ALTER TABLE ONLY public.distribution_metrics
    ADD CONSTRAINT distribution_metrics_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON DELETE SET NULL;


--
-- Name: distribution_metrics distribution_metrics_master_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: field_user
--

ALTER TABLE ONLY public.distribution_metrics
    ADD CONSTRAINT distribution_metrics_master_id_fkey FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: distribution_metrics distribution_metrics_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: field_user
--

ALTER TABLE ONLY public.distribution_metrics
    ADD CONSTRAINT distribution_metrics_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: admin_audit_log fk_admin_audit_log__admin_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT fk_admin_audit_log__admin_id__staff_users FOREIGN KEY (admin_id) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: admin_audit_log fk_admin_audit_log__master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT fk_admin_audit_log__master_id__masters FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: attachments fk_attachments__uploaded_by_master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT fk_attachments__uploaded_by_master_id__masters FOREIGN KEY (uploaded_by_master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: attachments fk_attachments__uploaded_by_staff_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT fk_attachments__uploaded_by_staff_id__staff_users FOREIGN KEY (uploaded_by_staff_id) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: commissions fk_commissions__master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT fk_commissions__master_id__masters FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: commissions fk_commissions__order_id__orders; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT fk_commissions__order_id__orders FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: districts fk_districts__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT fk_districts__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: master_districts fk_master_districts__district_id__districts; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_districts
    ADD CONSTRAINT fk_master_districts__district_id__districts FOREIGN KEY (district_id) REFERENCES public.districts(id) ON DELETE CASCADE;


--
-- Name: master_districts fk_master_districts__master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_districts
    ADD CONSTRAINT fk_master_districts__master_id__masters FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: master_invite_codes fk_master_invite_codes__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_invite_codes
    ADD CONSTRAINT fk_master_invite_codes__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE SET NULL;


--
-- Name: master_invite_codes fk_master_invite_codes__issued_by_staff_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_invite_codes
    ADD CONSTRAINT fk_master_invite_codes__issued_by_staff_id__staff_users FOREIGN KEY (issued_by_staff_id) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: master_invite_codes fk_master_invite_codes__used_by_master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_invite_codes
    ADD CONSTRAINT fk_master_invite_codes__used_by_master_id__masters FOREIGN KEY (used_by_master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: master_skills fk_master_skills__master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_skills
    ADD CONSTRAINT fk_master_skills__master_id__masters FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: master_skills fk_master_skills__skill_id__skills; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.master_skills
    ADD CONSTRAINT fk_master_skills__skill_id__skills FOREIGN KEY (skill_id) REFERENCES public.skills(id) ON DELETE CASCADE;


--
-- Name: masters fk_masters__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.masters
    ADD CONSTRAINT fk_masters__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE SET NULL;


--
-- Name: masters fk_masters__referred_by_master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.masters
    ADD CONSTRAINT fk_masters__referred_by_master_id__masters FOREIGN KEY (referred_by_master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: masters fk_masters__verified_by__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.masters
    ADD CONSTRAINT fk_masters__verified_by__staff_users FOREIGN KEY (verified_by) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: notifications_outbox fk_notifications_outbox__master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.notifications_outbox
    ADD CONSTRAINT fk_notifications_outbox__master_id__masters FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: offers fk_offers__master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT fk_offers__master_id__masters FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: offers fk_offers__order_id__orders; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT fk_offers__order_id__orders FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_autoclose_queue fk_order_autoclose_queue__order_id__orders; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.order_autoclose_queue
    ADD CONSTRAINT fk_order_autoclose_queue__order_id__orders FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_status_history fk_order_status_history__changed_by_master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT fk_order_status_history__changed_by_master_id__masters FOREIGN KEY (changed_by_master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: order_status_history fk_order_status_history__changed_by_staff_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT fk_order_status_history__changed_by_staff_id__staff_users FOREIGN KEY (changed_by_staff_id) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: order_status_history fk_order_status_history__order_id__orders; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.order_status_history
    ADD CONSTRAINT fk_order_status_history__order_id__orders FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders fk_orders__assigned_master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders__assigned_master_id__masters FOREIGN KEY (assigned_master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE RESTRICT;


--
-- Name: orders fk_orders__created_by_staff_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders__created_by_staff_id__staff_users FOREIGN KEY (created_by_staff_id) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders__district_id__districts; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders__district_id__districts FOREIGN KEY (district_id) REFERENCES public.districts(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders__guarantee_source_order_id__orders; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders__guarantee_source_order_id__orders FOREIGN KEY (guarantee_source_order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders__preferred_master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders__preferred_master_id__masters FOREIGN KEY (preferred_master_id) REFERENCES public.masters(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders__street_id__streets; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_orders__street_id__streets FOREIGN KEY (street_id) REFERENCES public.streets(id) ON DELETE SET NULL;


--
-- Name: referral_rewards fk_referral_rewards__commission_id__commissions; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT fk_referral_rewards__commission_id__commissions FOREIGN KEY (commission_id) REFERENCES public.commissions(id) ON DELETE CASCADE;


--
-- Name: referral_rewards fk_referral_rewards__referred_master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT fk_referral_rewards__referred_master_id__masters FOREIGN KEY (referred_master_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: referral_rewards fk_referral_rewards__referrer_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT fk_referral_rewards__referrer_id__masters FOREIGN KEY (referrer_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: referrals fk_referrals__master_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT fk_referrals__master_id__masters FOREIGN KEY (master_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: referrals fk_referrals__referrer_id__masters; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT fk_referrals__referrer_id__masters FOREIGN KEY (referrer_id) REFERENCES public.masters(id) ON DELETE CASCADE;


--
-- Name: staff_access_code_cities fk_staff_access_code_cities__access_code_id__staff_access_codes; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_code_cities
    ADD CONSTRAINT fk_staff_access_code_cities__access_code_id__staff_access_codes FOREIGN KEY (access_code_id) REFERENCES public.staff_access_codes(id) ON DELETE CASCADE;


--
-- Name: staff_access_code_cities fk_staff_access_code_cities__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_code_cities
    ADD CONSTRAINT fk_staff_access_code_cities__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: staff_access_codes fk_staff_access_codes__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_codes
    ADD CONSTRAINT fk_staff_access_codes__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE SET NULL;


--
-- Name: staff_access_codes fk_staff_access_codes__issued_by_staff_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_codes
    ADD CONSTRAINT fk_staff_access_codes__issued_by_staff_id__staff_users FOREIGN KEY (created_by_staff_id) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: staff_access_codes fk_staff_access_codes__used_by_staff_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_access_codes
    ADD CONSTRAINT fk_staff_access_codes__used_by_staff_id__staff_users FOREIGN KEY (used_by_staff_id) REFERENCES public.staff_users(id) ON DELETE SET NULL;


--
-- Name: staff_cities fk_staff_cities__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_cities
    ADD CONSTRAINT fk_staff_cities__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: staff_cities fk_staff_cities__staff_user_id__staff_users; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.staff_cities
    ADD CONSTRAINT fk_staff_cities__staff_user_id__staff_users FOREIGN KEY (staff_user_id) REFERENCES public.staff_users(id) ON DELETE CASCADE;


--
-- Name: streets fk_streets__city_id__cities; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.streets
    ADD CONSTRAINT fk_streets__city_id__cities FOREIGN KEY (city_id) REFERENCES public.cities(id) ON DELETE CASCADE;


--
-- Name: streets fk_streets__district_id__districts; Type: FK CONSTRAINT; Schema: public; Owner: fs_user
--

ALTER TABLE ONLY public.streets
    ADD CONSTRAINT fk_streets__district_id__districts FOREIGN KEY (district_id) REFERENCES public.districts(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict u2wF30U9mJiBTgGZTdmEyuVCAPxxK2Y9fRhGIwoQmv9SwghrS5dz0dbfrAkN4zK

