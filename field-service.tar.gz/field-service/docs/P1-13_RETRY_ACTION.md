# P1-13: Кнопка "Повторить последнее действие" при ошибках

**Статус:** ✅ Завершено  
**Дата:** 2025-10-09  
**Приоритет:** P1 (Высокий)  
**Задача из:** ux_analysis_report.md

---

## 📋 Описание проблемы

**Проблема:** При ошибке (сетевая проблема, таймаут, временный сбой) нужно делать всё заново  

**Сценарий:**
```
Админ назначил мастера → Ошибка сети → 
Нужно заново искать заказ и мастера
```

**Решение:** Сохранять последнее действие и добавить кнопку:
```
❌ Не удалось выполнить действие
[🔄 Повторить] [❌ Отменить]
```

---

## 🎯 Что реализовано

### 1. **RetryContext** (`field_service/bots/common/retry_context.py`)

Класс для хранения контекста повтора действия:

```python
@dataclass
class RetryContext:
    """Контекст для повтора действия"""
    callback_data: str      # Оригинальный callback для повтора
    timestamp: datetime     # Время ошибки
    attempt: int            # Номер попытки (1, 2, 3)
    user_id: int           # ID пользователя
    chat_id: int           # ID чата
    message_id: int        # ID сообщения
    
    MAX_ATTEMPTS = 3       # Максимум 3 попытки
```

**Функции:**
- `save_retry_context()` - сохранить контекст в FSM state
- `load_retry_context()` - загрузить контекст из FSM state
- `clear_retry_context()` - очистить контекст

### 2. **RetryMiddleware** (`field_service/bots/common/retry_middleware.py`)

Middleware который перехватывает все ошибки в callback handlers:

```python
class RetryMiddleware(BaseMiddleware):
    """
    При ошибке в handler:
    1. Логирует исключение
    2. Сохраняет контекст в FSM
    3. Показывает UI с кнопками "Повторить" и "Отменить"
    """
```

**Работает только с CallbackQuery** - перехватывает ошибки при нажатии кнопок

**UI при ошибке:**
```
❌ Не удалось выполнить действие

Возможные причины:
• Временные проблемы с сетью
• Превышено время ожидания
• Технические работы на сервере

Вы можете:
[🔄 Повторить] [❌ Отменить]
```

### 3. **Retry Handlers** (`field_service/bots/common/retry_handler.py`)

Handlers для обработки кнопок retry:

#### `retry:execute` - Повторить действие
```python
@retry_router.callback_query(F.data == "retry:execute")
async def retry_execute(callback: CallbackQuery, state: FSMContext):
    """
    1. Загружает сохранённый контекст
    2. Проверяет лимит попыток (MAX_ATTEMPTS = 3)
    3. Увеличивает счётчик attempt
    4. Восстанавливает оригинальный callback_data
    5. Повторяет действие через dispatcher
    6. При успехе - очищает контекст
    7. При ошибке - middleware снова перехватит
    """
```

#### `retry:cancel` - Отменить повтор
```python
@retry_router.callback_query(F.data == "retry:cancel")
async def retry_cancel(callback: CallbackQuery, state: FSMContext):
    """
    1. Очищает retry_context из FSM
    2. Показывает "✅ Действие отменено"
    """
```

---

## 🔌 Интеграция

### Master Bot

Изменения в `field_service/bots/master_bot/main.py`:

```python
# Импорты
from field_service.bots.common.retry_handler import retry_router  # P1-13
from field_service.bots.common.retry_middleware import setup_retry_middleware  # P1-13

# Подключение router
dp.include_router(master_router)
dp.include_router(retry_router)  # P1-13

# Подключение middleware
setup_error_middleware(...)
setup_retry_middleware(dp, enabled=True)  # P1-13
```

### Admin Bot

Изменения в `field_service/bots/admin_bot/main.py`:

```python
# Импорты уже были, добавлено использование:

# Подключение router
dp.include_router(create_combined_router())
dp.include_router(retry_router)  # P1-13

# Подключение middleware
setup_error_middleware(...)
setup_retry_middleware(dp, enabled=True)  # P1-13
```

---

## 📊 Архитектура

```
┌─────────────────────────────────────────────────┐
│   User нажимает кнопку                          │
└─────────────┬───────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────────────┐
│   RetryMiddleware перехватывает                 │
│   ошибки в callback handlers                    │
└─────────────┬───────────────────────────────────┘
              │
    ┌─────────┴─────────┐
    │                   │
    ▼                   ▼
  SUCCESS             ERROR
    │                   │
    └───────────►       │
                        ▼
              ┌─────────────────────┐
              │ Save RetryContext   │
              │ в FSM state:        │
              │ - callback_data     │
              │ - attempt = 1       │
              │ - user_id, chat_id  │
              └──────────┬──────────┘
                         │
                         ▼
              ┌─────────────────────┐
              │ Show error UI:      │
              │ [🔄 Повторить]      │
              │ [❌ Отменить]       │
              └─────┬─────────┬─────┘
                    │         │
        ┌───────────┘         └──────────┐
        ▼                                ▼
┌───────────────┐                ┌──────────────┐
│ retry:execute │                │ retry:cancel │
└───────┬───────┘                └──────┬───────┘
        │                               │
        ▼                               ▼
┌───────────────┐                ┌──────────────┐
│ Load context  │                │ Clear context│
│ Check attempts│                │ Show "✅"    │
│ Increment     │                └──────────────┘
│ Restore data  │
│ Repeat action │
└───────┬───────┘
        │
        ▼
  [Обработка повторяется]
```

---

## 🧪 Тестирование

### Создан файл тестов: `tests/test_retry_action.py`

**Покрытие:**

1. **RetryContext:**
   - ✅ Создание и валидация
   - ✅ Проверка лимита попыток (MAX_ATTEMPTS)
   - ✅ Сериализация/десериализация
   - ✅ Сохранение/загрузка в FSM
   - ✅ Очистка контекста

2. **RetryMiddleware:**
   - ✅ Работа при enabled=False (не вмешивается)
   - ✅ Перехват ошибок при enabled=True
   - ✅ Сохранение контекста при ошибке
   - ✅ Показ error UI с кнопками

3. **Retry Handlers:**
   - ✅ retry:execute без контекста
   - ✅ retry:execute при превышении лимита
   - ✅ retry:cancel очищает контекст

4. **Интеграционные:**
   - ✅ Полный цикл: ошибка → retry → успех
   - ✅ Инкремент attempt при каждом retry

### Запуск тестов

```powershell
# Все тесты retry
$env:PYTHONIOENCODING='utf-8'; pytest tests/test_retry_action.py -v -s

# Конкретный тест
pytest tests/test_retry_action.py::test_retry_middleware_catches_error -v -s
```

---

## 📝 Примеры использования

### Пример 1: Сетевая ошибка при назначении мастера

```
1. Админ назначает мастера на заказ
2. Происходит таймаут БД
3. RetryMiddleware перехватывает:
   - Сохраняет callback_data = "adm:o:assign:123:456"
   - Показывает UI с кнопками
4. Админ нажимает "🔄 Повторить"
5. retry_execute:
   - Загружает контекст
   - Увеличивает attempt до 2
   - Восстанавливает callback_data
   - Повторяет действие
6. Успех - контекст очищается
```

### Пример 2: Превышение лимита попыток

```
1. Действие падает 3 раза подряд
2. attempt = 1 → 2 → 3
3. При 4-й попытке:
   retry_execute проверяет can_retry()
   → False (attempt >= MAX_ATTEMPTS)
   → Показывает: "Превышено максимальное количество попыток (3)"
   → Очищает контекст
```

### Пример 3: Отмена повтора

```
1. Ошибка → показывается UI
2. Пользователь нажимает "❌ Отменить"
3. retry_cancel:
   - Очищает retry_context
   - Показывает "✅ Действие отменено"
```

---

## ⚙️ Настройки

### RetryMiddleware

```python
setup_retry_middleware(dp, enabled=True)
```

**Параметры:**
- `enabled: bool = True` - включить/выключить функциональность

### RetryContext

```python
class RetryContext:
    MAX_ATTEMPTS = 3  # Максимум попыток
```

**Можно изменить** если нужно больше/меньше попыток

---

## 🎨 UI компоненты

### Сообщение об ошибке

```python
error_text = (
    "❌ <b>Не удалось выполнить действие</b>\n\n"
    "Возможные причины:\n"
    "• Временные проблемы с сетью\n"
    "• Превышено время ожидания\n"
    "• Технические работы на сервере\n\n"
    "Вы можете:"
)
```

### Кнопки

```python
builder = InlineKeyboardBuilder()
builder.button(text="🔄 Повторить", callback_data="retry:execute")
builder.button(text="❌ Отменить", callback_data="retry:cancel")
builder.adjust(2)  # 2 кнопки в ряд
```

---

## 🔍 Логирование

### При ошибке

```
ERROR Unhandled exception in callback handler: test:action
exc_info=(ValueError, "Test error", <traceback>)
extra={
    "user_id": 123,
    "callback_data": "test:action"
}
```

### При повторе

```
INFO Retrying action: test:action, attempt 2
extra={
    "user_id": 123,
    "callback_data": "test:action",
    "attempt": 2
}
```

### При отмене

```
INFO Retry cancelled by user
extra={"user_id": 123}
```

---

## 🚀 Преимущества

1. **Автоматическая обработка** - не нужно в каждом handler добавлять try/except
2. **Единообразный UX** - одинаковое сообщение об ошибке везде
3. **Защита от спама** - лимит попыток (MAX_ATTEMPTS)
4. **Прозрачность** - логирование всех попыток
5. **Удобство** - пользователь может повторить действие одной кнопкой

---

## 📌 Примечания

### Что перехватывается
- ✅ Ошибки в callback handlers
- ❌ Ошибки в message handlers (не перехватывается)
- ❌ Ошибки в FSM (не перехватывается)

### Когда НЕ работает
- Если `enabled=False` в setup_retry_middleware
- Если ошибка в не-callback handler'е
- Если нет FSM state (не сможет сохранить контекст)

### Совместимость
- ✅ Master Bot
- ✅ Admin Bot
- ✅ Работает с FSM
- ✅ Работает с другими middleware

---

## 🎯 Следующие шаги

### Возможные улучшения (не в P1-13):

1. **Перехват Message handlers** - расширить на обработку не только callback
2. **Настраиваемые тексты** - разные сообщения для разных типов ошибок
3. **Exponential backoff** - увеличивать задержку между попытками
4. **Статистика** - собирать метрики по retry (сколько раз, какие action)
5. **Admin dashboard** - показывать проблемные действия которые часто retry

---

## ✅ Чек-лист завершения

- [x] Реализованы все компоненты (context, middleware, handlers)
- [x] Подключено к master_bot
- [x] Подключено к admin_bot  
- [x] Написаны unit тесты
- [x] Написаны интеграционные тесты
- [x] Создана документация
- [x] Добавлено логирование
- [x] Проверен лимит попыток
- [x] Проверена очистка контекста

---

**Автор:** Claude Sonnet 4.5  
**Дата завершения:** 2025-10-09
