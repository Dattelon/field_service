# P1-21: Commission Deadline Reminders

**Дата**: 2025-10-09  
**Приоритет**: P1 - Высокий  
**Статус**: ✅ РЕАЛИЗОВАНО

---

## 📋 Описание задачи

Мастера не получают уведомления о приближающемся дедлайне оплаты комиссии, что приводит к просрочкам и автоблокировке аккаунтов.

### Проблема
- Мастер узнаёт о просрочке постфактум, когда аккаунт уже заблокирован
- Нет напоминаний о необходимости оплатить комиссию
- Отсутствует градация срочности (сегодня/завтра/через неделю)

### Решение
Автоматические уведомления за **24 часа**, **6 часов** и **1 час** до дедлайна.

---

## 🎯 Реализованный функционал

### 1. База данных

**Новая таблица**: `commission_deadline_notifications`

```sql
CREATE TABLE commission_deadline_notifications (
    id SERIAL PRIMARY KEY,
    commission_id INTEGER NOT NULL REFERENCES commissions(id) ON DELETE CASCADE,
    hours_before SMALLINT NOT NULL CHECK (hours_before IN (1, 6, 24)),
    sent_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
    
    CONSTRAINT uq_commission_deadline_notifications__commission_hours 
        UNIQUE (commission_id, hours_before)
);
```

**Индексы**:
- `ix_commission_deadline_notifications__commission` - быстрый поиск по комиссии

**Назначение**:
- Предотвращение дублирующих уведомлений
- Трекинг отправленных напоминаний
- Аудит системы уведомлений

---

### 2. Watchdog

**Файл**: `field_service/services/watchdogs.py`

**Функция**: `watchdog_commission_deadline_reminders()`

**Алгоритм**:
```python
1. Каждые 30 минут запрашиваем все комиссии со статусом WAIT_PAY
2. Для каждой комиссии вычисляем время до дедлайна
3. Проверяем пороги: 24ч, 6ч, 1ч
4. Если порог достигнут И уведомление ещё не отправлялось:
   - Отправляем уведомление мастеру
   - Записываем в commission_deadline_notifications
   - Логируем событие
```

**Параметры**:
- `interval_seconds=1800` - проверка каждые 30 минут
- `iterations=None` - бесконечный цикл

**Обработка ошибок**:
- Try-catch на каждую итерацию
- Продолжение работы при ошибках
- Логирование всех проблем

---

### 3. Формат уведомлений

#### За 24 часа
```
⏰ Напоминание об оплате комиссии

До дедлайна оплаты комиссии осталось 24 часа

📋 Заказ #123
💰 Сумма: 1500.00₽

Пожалуйста, отметьте оплату или загрузите чек в разделе "Финансы".

⚠️ При просрочке оплаты ваш аккаунт будет заблокирован.
```

#### За 6 часов
```
⚠️ Напоминание об оплате комиссии

До дедлайна оплаты комиссии осталось 6 часов

📋 Заказ #123
💰 Сумма: 1500.00₽

...
```

#### За 1 час
```
🔴 Напоминание об оплате комиссии

До дедлайна оплаты комиссии осталось 1 час

📋 Заказ #123
💰 Сумма: 1500.00₽

...
```

---

## 🔧 Технические детали

### Модель `commission_deadline_notifications`

**Поля**:
- `id` - PRIMARY KEY
- `commission_id` - FK на commissions(id)
- `hours_before` - порог (1, 6 или 24)
- `sent_at` - время отправки

**Ограничения**:
- UNIQUE на (commission_id, hours_before) - одно уведомление на порог
- CHECK на hours_before IN (1, 6, 24)

### Интеграция в admin_bot

**Файл**: `field_service/bots/admin_bot/main.py`

**Изменения**:
1. Импорт `watchdog_commission_deadline_reminders`
2. Создание task `deadline_reminders_task`
3. Добавление в cleanup list

**Запуск**:
```python
deadline_reminders_task = asyncio.create_task(
    watchdog_commission_deadline_reminders(
        bot,
        interval_seconds=1800,  # 30 минут
    ),
    name="commission_deadline_reminders",
)
```

---

## 📊 Логирование

### Live Log
```python
live_log.push(
    "watchdog",
    f"commission_deadline_reminders sent={notifications_sent}",
    level="INFO"
)
```

### Standard Logger
```python
logger.info(
    "commission_deadline_reminder sent: commission=%s master=%s hours=%s",
    commission.id,
    commission.master_id,
    hours_before
)
```

---

## 🧪 Тестирование

### Ручное тестирование

**Подготовка**:
1. Создать комиссию со статусом WAIT_PAY
2. Установить deadline_at на +1 час от текущего времени
3. Запустить watchdog

**Проверка**:
```sql
-- Посмотреть комиссии ожидающие оплату
SELECT id, order_id, master_id, deadline_at, status 
FROM commissions 
WHERE status = 'WAIT_PAY';

-- Посмотреть отправленные уведомления
SELECT * FROM commission_deadline_notifications 
ORDER BY sent_at DESC;
```

### Интеграционные тесты

TODO: Создать тесты в `tests/services/test_watchdogs.py`

---

## 🚀 Деплой

### 1. Применить миграцию
```powershell
Get-Content migrations/2025-10-09_create_commission_deadline_notifications.sql | 
  docker exec -i field-service-postgres-1 psql -U fs_user -d field_service
```

### 2. Перезапустить admin-bot
```powershell
docker-compose restart admin-bot
```

### 3. Проверить логи
```powershell
docker logs -f field-service-admin-bot-1 | grep "commission_deadline"
```

---

## 📈 Метрики

### Отслеживать
- Количество отправленных уведомлений за 24ч/6ч/1ч
- Процент мастеров оплативших после уведомления
- Снижение количества просроченных комиссий
- Снижение количества автоблокировок

### SQL запросы
```sql
-- Статистика уведомлений за последние 7 дней
SELECT 
    hours_before,
    COUNT(*) as total_sent,
    DATE(sent_at) as date
FROM commission_deadline_notifications
WHERE sent_at > NOW() - INTERVAL '7 days'
GROUP BY hours_before, DATE(sent_at)
ORDER BY date DESC, hours_before DESC;

-- Эффективность уведомлений
SELECT 
    cdn.hours_before,
    COUNT(*) as total_sent,
    COUNT(CASE WHEN c.status IN ('REPORTED', 'APPROVED') THEN 1 END) as paid_count,
    ROUND(
        COUNT(CASE WHEN c.status IN ('REPORTED', 'APPROVED') THEN 1 END)::numeric / 
        COUNT(*)::numeric * 100, 
        2
    ) as payment_rate_pct
FROM commission_deadline_notifications cdn
JOIN commissions c ON c.id = cdn.commission_id
WHERE cdn.sent_at > NOW() - INTERVAL '30 days'
GROUP BY cdn.hours_before
ORDER BY cdn.hours_before DESC;
```

---

## ✅ Чеклист завершения

- [x] Создана модель `commission_deadline_notifications`
- [x] Применена миграция БД
- [x] Реализован watchdog `watchdog_commission_deadline_reminders`
- [x] Интегрирован в admin_bot/main.py
- [x] Добавлено логирование
- [x] Написана документация
- [ ] Созданы unit-тесты
- [ ] Созданы интеграционные тесты
- [ ] Проведено ручное тестирование
- [ ] Обновлена документация проекта

---

## 🎯 Следующие шаги

1. **Создать тесты** для watchdog'а
2. **Добавить кнопки** в уведомления (прямой переход в финансы)
3. **Мониторинг** эффективности уведомлений
4. **A/B тест** разных формулировок
5. **Персонализация** текста уведомлений

---

## 🔍 Возможные улучшения

### Кнопки в уведомлении
```python
keyboard = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(
            text="💰 Отметить оплату",
            callback_data=f"m:fin:mark:{commission.id}"
        )
    ],
    [
        InlineKeyboardButton(
            text="📸 Загрузить чек",
            callback_data=f"m:fin:check:{commission.id}"
        )
    ],
])
```

### Настройки уведомлений
Добавить возможность мастеру отключить определённые уведомления:
```sql
CREATE TABLE master_notification_preferences (
    master_id INTEGER PRIMARY KEY,
    deadline_24h BOOLEAN DEFAULT TRUE,
    deadline_6h BOOLEAN DEFAULT TRUE,
    deadline_1h BOOLEAN DEFAULT TRUE
);
```

### Telegram Bot API Features
- Использовать **inline buttons** для быстрых действий
- Добавить **deep linking** для перехода в конкретный раздел бота
- **Silent notifications** для 24ч, обычные для 6ч и 1ч

---

**Автор**: Claude Sonnet 4.5  
**Дата создания**: 2025-10-09  
**Статус**: Готово к тестированию
