# 🚀 Быстрый старт: Новый UI управления персоналом

## Что нужно сделать

### 1️⃣ Применить патч (1 минута)

**Открыть файл:** `field_service/bots/admin_bot/services_db.py`

**Найти метод** `register_staff_user_from_code` (примерно строка 2750-2850)

**После его последнего `return StaffUser(...)` вставить:**

```python
async def add_staff_direct(
    self,
    *,
    tg_id: Optional[int],
    username: Optional[str],
    role: StaffRole,
    city_ids: Iterable[int],
    created_by_staff_id: int,
) -> StaffUser:
    """Напрямую добавить сотрудника без access code."""
    if not tg_id and not username:
        raise ValueError("Необходимо указать tg_id или username")
    
    now = datetime.now(UTC)
    unique_cities = _sorted_city_tuple(city_ids)
    
    async with self._session_factory() as session:
        async with session.begin():
            # Проверка существования
            if tg_id:
                existing = await session.execute(
                    select(m.staff_users).where(m.staff_users.tg_user_id == tg_id)
                )
                if existing.scalar_one_or_none():
                    raise AccessCodeError("already_staff")
            
            # Создание записи
            staff_row = m.staff_users(
                tg_user_id=tg_id,
                username=username,
                full_name=username or f"User{tg_id}" if tg_id else "Unknown",
                phone="",
                role=_map_staff_role_to_db(role),
                is_active=True,
            )
            session.add(staff_row)
            await session.flush()
            
            # Привязка городов
            if unique_cities:
                session.add_all(
                    m.staff_cities(staff_user_id=staff_row.id, city_id=cid)
                    for cid in unique_cities
                )
            
            cities_label = ", ".join(str(cid) for cid in unique_cities) or "all"
            live_log.push(
                "staff",
                f"staff added direct: id={staff_row.id} tg_id={tg_id} "
                f"username={username} role={role.value} cities={cities_label} "
                f"by={created_by_staff_id}"
            )
    
    return StaffUser(
        id=staff_row.id,
        tg_id=tg_id or 0,
        role=role,
        is_active=True,
        city_ids=frozenset(unique_cities),
        full_name=staff_row.full_name or "",
        phone=staff_row.phone or "",
    )
```

### 2️⃣ Перезапустить бота

```bash
# Ctrl+C (остановить)
python -m field_service.bots.admin_bot
```

### 3️⃣ Готово! 🎉

---

## Как использовать

### Добавить нового сотрудника

1. Откройте админ-бот
2. Нажмите **"👤 Персонал и доступ"** (только для Global Admin)
3. Нажмите **"➕ Добавить персонал"**
4. Выберите роль:
   - 👑 Global Admin (весь доступ)
   - 🏛 City Admin (выбор городов)
   - 📦 Logist (выбор городов)
5. Введите **Telegram ID** или **@username** сотрудника
6. Если не Global Admin → выберите **города**
7. Подтвердите → **Готово!** ✅

### Как узнать Telegram ID?

**Попросите сотрудника:**
1. Написать боту `@userinfobot`
2. Или `@getmyid_bot`
3. Отправить вам ID (например, `123456789`)

### Заблокировать сотрудника

1. Откройте **"👤 Персонал и доступ"**
2. Выберите нужную роль (Global/City/Logist)
3. Нажмите на сотрудника
4. Нажмите **"❌ Заблокировать"**
5. Готово! Сотрудник не сможет войти

### Активировать обратно

1. Откройте карточку заблокированного
2. Нажмите **"✅ Активировать"**
3. Готово!

---

## Примеры

### Пример 1: Добавить Global Admin

```
1. Персонал и доступ
2. Добавить персонал
3. Выбрать: 👑 Global Admin
4. Ввести: 123456789
5. Подтвердить
→ ✅ Добавлен с доступом ко всем городам
```

### Пример 2: Добавить City Admin для 2 городов

```
1. Персонал и доступ
2. Добавить персонал
3. Выбрать: 🏛 City Admin
4. Ввести: @ivan_admin
5. Выбрать города: ✅ Москва, ✅ СПб
6. Готово
7. Подтвердить
→ ✅ Добавлен с доступом к Москве и СПб
```

### Пример 3: Заблокировать логиста

```
1. Персонал и доступ
2. Logists
3. Выбрать: @bad_logist
4. Заблокировать
→ ❌ Статус: Заблокирован
```

---

## Часто задаваемые вопросы

### ❓ Что делать, если сотрудник не знает свой ID?

Попросите его написать боту `@userinfobot` - бот покажет ID.

### ❓ Можно ли добавить по @username?

Да! Просто введите `@username` вместо ID.

### ❓ Что если username неправильный?

Сотрудник просто не сможет войти. Заблокируйте его и создайте заново.

### ❓ Можно ли заблокировать самого себя?

Нет! Система защищена от этого.

### ❓ Старые коды доступа ещё работают?

Да, для совместимости они работают. Но лучше использовать новый UI.

### ❓ Можно ли изменить роль/города?

Пока нет, эта функция в разработке. Сейчас можно только блокировать/активировать.

---

## Проблемы?

### Ошибка при запуске

```bash
# Проверить синтаксис патча
python -c "from field_service.bots.admin_bot.services_db import DBStaffService; print('OK')"
```

### Кнопки не появляются

- Убедитесь, что вы вошли как **Global Admin**
- Перезапустите бота

### Не могу добавить сотрудника

- Проверьте, что указали либо ID, либо @username
- Убедитесь, что ID правильный (только цифры)
- Проверьте, что сотрудник ещё не добавлен

---

## 📞 Нужна помощь?

**Полная документация:** `CR-2025-10-04-STAFF-UI-DOCS.md`

**Содержит:**
- Подробное описание всех функций
- Технические детали
- Примеры кода
- Архитектуру системы

---

**Версия:** 1.0  
**Дата:** 04.10.2025  
**Статус:** ✅ Готово к использованию
