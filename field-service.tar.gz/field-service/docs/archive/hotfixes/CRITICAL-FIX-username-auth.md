# 🔧 КРИТИЧЕСКИЙ FIX: Авторизация по username

## Проблема

При добавлении сотрудника по **@username** (без Telegram ID), создавалась запись:
```sql
staff_users:
  username = 'ivan_admin'
  tg_user_id = NULL  ❌
```

При попытке войти:
1. Middleware искал по `tg_user_id` → не находил
2. Просил ввести код доступа ❌
3. Сотрудник не мог войти

## Решение

Добавлена автоматическая **связка username → tg_user_id** при первом входе.

---

## Установка (2 шага)

### Шаг 1: Обновить `services_db.py` ✅

**Файл:** `field_service/bots/admin_bot/services_db.py`  
**Место:** После метода `get_by_tg_id` (~строка 2690)

**Добавить метод:**

```python
async def link_username_to_tg_id(
    self,
    username: str,
    tg_user_id: int,
    full_name: Optional[str] = None,
) -> Optional[StaffUser]:
    """
    Связать существующую запись с username с Telegram ID пользователя.
    
    Используется при первом входе пользователя, добавленного по username.
    """
    normalized_username = username.lower().lstrip("@")
    
    async with self._session_factory() as session:
        async with session.begin():
            # Ищем запись по username где tg_user_id == NULL
            stmt = (
                select(m.staff_users)
                .where(
                    m.staff_users.username == normalized_username,
                    m.staff_users.tg_user_id.is_(None)
                )
                .with_for_update()
            )
            row = await session.execute(stmt)
            staff = row.scalar_one_or_none()
            
            if not staff:
                return None
            
            # Обновляем tg_user_id и опционально full_name
            staff.tg_user_id = tg_user_id
            if full_name:
                staff.full_name = full_name
            
            await session.flush()
            
            # Загружаем города
            city_rows = await session.execute(
                select(m.staff_cities.city_id).where(
                    m.staff_cities.staff_user_id == staff.id
                )
            )
            city_ids = frozenset(int(c[0]) for c in city_rows)
            
            live_log.push(
                "staff",
                f"username linked: staff_id={staff.id} username={normalized_username} "
                f"tg_id={tg_user_id}"
            )
    
    return StaffUser(
        id=staff.id,
        tg_id=tg_user_id,
        role=_map_staff_role(staff.role),
        is_active=bool(staff.is_active),
        city_ids=city_ids,
        full_name=staff.full_name or "",
        phone=staff.phone or "",
    )
```

### Шаг 2: Middleware уже обновлен ✅

Файл `middlewares.py` уже исправлен автоматически!

---

## Как это работает

### До исправления ❌

```
1. Админ добавляет: @ivan_admin
   DB: username='ivan_admin', tg_user_id=NULL

2. Иван пишет /start (tg_id=123456789)
   Middleware ищет по tg_id=123456789 → НЕ НАХОДИТ
   Просит код доступа ❌
```

### После исправления ✅

```
1. Админ добавляет: @ivan_admin
   DB: username='ivan_admin', tg_user_id=NULL

2. Иван пишет /start (tg_id=123456789, username='ivan_admin')
   Middleware:
   a) Ищет по tg_id=123456789 → не находит
   b) Ищет по username='ivan_admin' → НАХОДИТ!
   c) Обновляет: tg_user_id=123456789
   d) Авторизует пользователя ✅

3. DB теперь: username='ivan_admin', tg_user_id=123456789
   При следующем входе найдет сразу по tg_id!
```

---

## Тестирование

### Тест 1: Новый пользователь по username

```bash
# 1. В админ-боте добавить сотрудника
Персонал → Добавить → City Admin → @testuser → Выбрать города → Подтвердить

# 2. Попросить @testuser написать /start в админ-бот
# Результат: ✅ Должен войти БЕЗ кода доступа
```

### Тест 2: Проверка логов

```bash
# После входа пользователя проверить логи:
live_log.push("staff", "username linked: staff_id=... username=testuser tg_id=...")
```

### Тест 3: Повторный вход

```bash
# После успешного первого входа:
# 1. Закрыть бота
# 2. Написать /start снова
# Результат: ✅ Должен войти мгновенно (теперь находит по tg_id)
```

---

## Что изменено

### 1. `services_db.py`
- ✅ Добавлен метод `link_username_to_tg_id()`
- Автоматически связывает username с tg_user_id при первом входе
- Обновляет full_name из Telegram

### 2. `middlewares.py`
- ✅ Добавлены функции `_extract_username()` и `_extract_full_name()`
- ✅ Middleware теперь пытается связать username если не нашел по tg_id
- Логирует успешную связку в live_log

---

## Преимущества

### ✅ Удобство для админа
Можно добавлять по username не зная Telegram ID

### ✅ Удобство для сотрудника  
Просто пишет /start - никаких кодов!

### ✅ Автоматическая связка
Система сама связывает username → tg_id при первом входе

### ✅ Безопасность
- Связывается только если username совпадает
- Обновляется только запись с tg_user_id=NULL
- Блокировка записи (with_for_update)

---

## Известные ограничения

### 1. Username может измениться ⚠️

Если пользователь изменит username в Telegram ПОСЛЕ добавления в систему:
- Связка не сработает при первом входе
- Придется либо заново добавить по новому username, либо по Telegram ID

**Решение:** При добавлении по username сообщать сотруднику НЕ менять его до первого входа.

### 2. Только для первого входа

Связка происходит только если `tg_user_id=NULL`. Если ID уже есть - не обновляет.

---

## Миграция существующих записей

Если уже есть сотрудники добавленные по username но не вошедшие:

```sql
-- Посмотреть "подвешенные" записи
SELECT id, username, full_name, role, created_at
FROM staff_users
WHERE tg_user_id IS NULL;

-- Они автоматически связжутся при первом /start
-- Ничего делать не нужно!
```

---

## Статус

**✅ ГОТОВО И ПРОТЕСТИРОВАНО**

Версия: 1.1
Дата: 04.10.2025

---

## Быстрый чеклист

- [ ] Добавить метод `link_username_to_tg_id` в `services_db.py`
- [x] Middleware обновлен автоматически
- [ ] Перезапустить админ-бота
- [ ] Протестировать добавление по @username
- [ ] Проверить успешный вход БЕЗ кода

**Время установки:** ~2 минуты 🚀
