# 🚀 ПРИМЕНЕНИЕ HOTFIX v1.2.1

## Быстрая инструкция

### ✅ У вас уже есть запись GLOBAL_ADMIN (id=5)

**Статус:** Запись найдена, но нужно обновить роль с 'ADMIN' на 'GLOBAL_ADMIN'

### 1. Обновить существующую запись
```powershell
# Из корня проекта field-service
Get-Content scripts/update_global_admin.sql | docker exec -i field-service-postgres-1 psql -U fs_user -d field_service
```

**Или через psql напрямую:**
```bash
psql -h 127.0.0.1 -p 5439 -U fs_user -d field_service -f scripts/update_global_admin.sql
```

### 2. Проверить обновление
Должно вернуть:
```
 staff_id | tg_user_id  | full_name  |     role     
----------+-------------+------------+---------------
    5     | 332786197   | Superuser  | GLOBAL_ADMIN
```

### 3. Перезапустить админ-бот
```powershell
# Остановить бот (Ctrl+C)
# Запустить заново
python -m field_service.bots.admin_bot.main
```

### 4. Тест
1. Открыть бот → 💰 Финансы → Ожидают оплаты
2. Выбрать комиссию → ✅ Подтвердить
3. Убедиться, что **НЕТ ошибки FK-constraint**

---

## Что было исправлено?

### Проблема #1: Валидация staff.id
❌ **Было:** `if staff.id <= 0` отклоняло GLOBAL_ADMIN  
✅ **Стало:** `if staff.id < 0` — разрешает любые положительные id

### Проблема #2: FK-constraint
❌ **Было:** middleware создавал виртуальный объект с id=0  
✅ **Стало:** загружается реальная запись из БД (id=5)

### Проблема #3: Роль 'ADMIN' вместо 'GLOBAL_ADMIN'
❌ **Было:** role = 'ADMIN' (legacy значение)  
✅ **Стало:** role = 'GLOBAL_ADMIN' (актуальное значение)

---

## Файлы изменений
- `handlers_finance.py` — валидация (3 обработчика)
- `middlewares.py` — загрузка superuser из БД
- `scripts/update_global_admin.sql` — обновление роли (НОВЫЙ)
- `CHANGELOG.md` — обновлён

---

## Статус: ✅ ГОТОВО К ПРИМЕНЕНИЮ
Дата: 03.10.2025, 22:30

**Главное:** Выполните SQL-скрипт `update_global_admin.sql` и перезапустите бот!
