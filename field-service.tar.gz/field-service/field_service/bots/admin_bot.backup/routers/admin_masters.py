﻿from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Optional

from aiogram import F, Router
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from pathlib import Path
from tempfile import TemporaryDirectory
from aiogram import Bot
from aiogram.types import FSInputFile
from field_service.config import settings as env_settings
from field_service.services.push_notifications import (
    notify_master as push_notify_master,
    NotificationEvent,
)

from field_service.bots.common import FSMTimeoutConfig, FSMTimeoutMiddleware

from ..dto import MasterDetail, MasterListItem, StaffRole, StaffUser
from ..filters import StaffRoleFilter
from ..keyboards import back_to_menu
from ..utils import get_service

PAGE_SIZE = 10
VIEW_ROLES = {
    StaffRole.GLOBAL_ADMIN,
    StaffRole.CITY_ADMIN,
    StaffRole.LOGIST,
}
MANAGE_ROLES = {
    StaffRole.GLOBAL_ADMIN,
    StaffRole.CITY_ADMIN,
}
SHIFT_LABELS = {
    "SHIFT_ON": "На смене",
    "SHIFT_OFF": "Не на смене",
    "BREAK": "Перерыв",
}
GROUP_LABELS = {
    "ok": "Одобренные",
    "mod": "На модерации",
    "blk": "Неактивные",
}

MASTER_GROUP_ORDER = ("ok", "mod", "blk")

logger = logging.getLogger(__name__)
UTC = timezone.utc


@dataclass(slots=True)
class MasterAction:
    prefix: str
    action: str
    master_id: int
    group: str | None = None
    category: str | None = None
    page: int | None = None

    @property
    def mode(self) -> str:
        return "moderation" if self.prefix == "adm:mod" else "masters"


def parse_master_action(data: str) -> MasterAction:
    parts = data.split(":")
    if len(parts) < 3:
        raise ValueError("Invalid callback data")
    prefix = ":".join(parts[:2])
    action = parts[2]
    tail = parts[3:]
    if not tail:
        raise ValueError("Missing master identifier")
    try:
        master_id = int(tail[-1])
    except ValueError as exc:
        raise ValueError("Invalid master identifier") from exc
    group = category = None
    page: int | None = None
    if len(tail) >= 4:
        group = tail[-4]
        category = tail[-3]
        page_str = tail[-2]
        try:
            page = int(page_str)
        except ValueError:
            page = None
    return MasterAction(prefix, action, master_id, group, category, page)


class RejectReasonState(StatesGroup):
    waiting = State()


class ChangeLimitState(StatesGroup):
    waiting = State()


router = Router(name="admin_masters")
_timeout_middleware = FSMTimeoutMiddleware(
    FSMTimeoutConfig(timeout=timedelta(minutes=5))
)
router.callback_query.middleware(_timeout_middleware)
router.message.middleware(_timeout_middleware)


def _masters_service(bot):
    return get_service(bot, "masters_service")


def _can_manage(staff: StaffUser) -> bool:
    return staff.role in MANAGE_ROLES


def _city_scope(staff: StaffUser) -> Optional[Iterable[int]]:
    if staff.role is StaffRole.GLOBAL_ADMIN:
        return None
    return list(staff.city_ids)


def _group_label(group: str) -> str:
    return GROUP_LABELS.get(group.lower(), group)


def _shift_label(status: str, on_break: bool) -> str:
    status_key = (status or "").upper()
    base = SHIFT_LABELS.get(status_key, status_key or "UNKNOWN")
    if on_break:
        return f"{base} (перерыв)"
    return base


def _category_label(category: str, skills: list[dict[str, object]]) -> str:
    if not category or category == "all":
        return "Все"
    lookup: dict[str, str] = {}
    for item in skills:
        code = str(item.get("code") or "").lower()
        name = str(item.get("name") or item.get("id"))
        lookup[str(item.get("id"))] = name
        if code:
            lookup[code] = name
    return lookup.get(category.lower(), category)


def _format_master_line(item: MasterListItem) -> str:
    skills = ", ".join(item.skills) if item.skills else "—"
    transport = "🚗" if item.has_vehicle else "🚶"
    on_break = item.on_break or item.shift_status.upper() == "BREAK"
    shift = _shift_label(item.shift_status, on_break)
    status_flags: list[str] = []
    if item.is_deleted:
        status_flags.append("удален")
    if not item.verified:
        status_flags.append("не проверен")
    if not item.is_active:
        status_flags.append("не активен")
    flags = f" ({', '.join(status_flags)})" if status_flags else ""
    limit_value: str
    if item.max_active_orders:
        limit_value = f"{item.active_orders}/{item.max_active_orders}"
    else:
        limit_value = str(item.active_orders)
    avg_check = f"{item.avg_check:.0f} ₽" if item.avg_check is not None else "—"
    city = item.city_name or "—"
    return (
        f"#{item.id} {item.full_name} • {city} • {skills} • {item.rating:.1f} ★ • "
        f"{transport} • {shift}{flags}\n"
        f"Активные заказы: {limit_value} • Средний чек: {avg_check}"
    )


def build_list_kb(
    group: str,
    category: str,
    page: int,
    items: list[MasterListItem],
    has_next: bool,
    skills: list[dict[str, object]],
    *,
    prefix: str = "adm:m",
) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()

    if prefix == "adm:m":
        active_group = (group or "ok").lower()
        buttons: list[InlineKeyboardButton] = []
        for key in MASTER_GROUP_ORDER:
            label = _group_label(key)
            text_label = label if key != active_group else f"[{label}]"
            buttons.append(
                InlineKeyboardButton(
                    text=text_label,
                    callback_data=f"adm:m:grp:{key}",
                )
            )
        if buttons:
            kb.row(*buttons)

    list_builder = InlineKeyboardBuilder()
    for item in items:
        list_builder.button(
            text=f"Открыть #{item.id}",
            callback_data=f"{prefix}:card:{group}:{category}:{page}:{item.id}",
        )
    if items:
        list_builder.adjust(1)
        kb.attach(list_builder)

    nav = InlineKeyboardBuilder()
    if page > 1:
        nav.button(
            text="◀️ Назад",
            callback_data=f"{prefix}:list:{group}:{category}:{page - 1}",
        )
    if has_next:
        nav.button(
            text="▶️ Вперёд",
            callback_data=f"{prefix}:list:{group}:{category}:{page + 1}",
        )
    nav_count = 0
    if page > 1:
        nav_count += 1
    if has_next:
        nav_count += 1
    if nav_count:
        nav.adjust(nav_count)
        kb.attach(nav)

    categories = InlineKeyboardBuilder()
    categories.button(text="Все", callback_data=f"{prefix}:list:{group}:all:1")
    for skill in skills[:6]:
        skill_id = str(skill.get("id"))
        label = str(skill.get("name") or skill_id)
        if len(label) > 24:
            label = label[:21] + "…"
        categories.button(
            text=label,
            callback_data=f"{prefix}:list:{group}:{skill_id}:1",
        )
    categories_count = 1 + min(len(skills), 6)
    if categories_count:
        categories.adjust(min(categories_count, 3))
        kb.attach(categories)

    footer = InlineKeyboardBuilder()
    footer.button(text="⬅️ Назад", callback_data="adm:menu")
    footer.button(text="🏠 Меню", callback_data="adm:menu")
    footer.adjust(2)
    kb.attach(footer)

    return kb.as_markup()


def build_card_kb(
    detail: MasterDetail,
    staff: StaffUser,
    *,
    mode: str = "masters",
    prefix: str = "adm:m",
    group: str | None = None,
    category: str | None = None,
    page: int | None = None,
) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    manage = _can_manage(staff) and not detail.is_deleted
    group_value = group or ("mod" if mode == "moderation" else "ok")
    category_value = category or "all"
    page_value = page or 1

    def _action_callback(action: str) -> str:
        return f"{prefix}:{action}:{group_value}:{category_value}:{page_value}:{detail.id}"

    if mode == "moderation":
        if manage and not detail.verified:
            kb.button(text="✅ Одобрить", callback_data=_action_callback("ok"))
        if manage:
            kb.button(text="❌ Отклонить", callback_data=_action_callback("rej"))
        kb.button(text="📄 Документы", callback_data=_action_callback("docs"))
        kb.adjust(1)
        kb.row(
            InlineKeyboardButton(
                text="⬅️ Назад",
                callback_data=f"{prefix}:list:{group_value}:{category_value}:{page_value}",
            ),
            InlineKeyboardButton(text="🏠 Меню", callback_data="adm:menu"),
        )
        return kb.as_markup()

    if manage and not detail.verified:
        kb.button(text="✅ Одобрить", callback_data=_action_callback("ok"))
    if manage:
        kb.button(text="❌ Отклонить", callback_data=_action_callback("rej"))
    if manage:
        if detail.is_active and not detail.is_deleted:
            kb.button(text="🚫 Заблокировать", callback_data=_action_callback("blk"))
        else:
            kb.button(text="✅ Разблокировать", callback_data=_action_callback("unb"))
        kb.button(text="🎯 Изм. лимит", callback_data=_action_callback("lim"))
    kb.button(text="📄 Документы", callback_data=_action_callback("docs"))
    if manage:
        delete_text = (
            "🗑 Удалить"
            if not (detail.has_orders or detail.has_commissions)
            else "🧹 Мягкое удаление"
        )
        kb.button(text=delete_text, callback_data=_action_callback("del"))

    kb.adjust(2, 2, 2)
    kb.row(
        InlineKeyboardButton(
            text="⬅️ Назад",
            callback_data=f"{prefix}:list:{group_value}:{category_value}:{page_value}",
        ),
        InlineKeyboardButton(text="🏠 Меню", callback_data="adm:menu"),
    )
    return kb.as_markup()


async def render_master_list(
    bot,
    group: str,
    category: str,
    page: int,
    *,
    staff: StaffUser,
    mode: str = "masters",
    prefix: str = "adm:m",
) -> tuple[str, InlineKeyboardMarkup, list[MasterListItem], list[dict[str, object]], bool]:
    service = _masters_service(bot)
    skills = await service.list_active_skills()
    items, has_next = await service.list_masters(
        group,
        city_ids=_city_scope(staff),
        category=category,
        page=page,
        page_size=PAGE_SIZE,
    )
    title = "👷 <b>Мастера</b>"
    if mode == "moderation":
        title = "🛠 <b>Модерация мастеров</b>"
    group_label = _group_label(group)
    category_label = _category_label(category, skills)
    lines = [
        title,
        f"Группа: {group_label}",
        f"Категория: {category_label}",
        f"Страница: {page}",
    ]
    if not items:
        lines.append("Список пуст.")
    else:
        for item in items:
            lines.append(_format_master_line(item))
    markup = build_list_kb(
        group,
        category,
        page,
        items,
        has_next,
        skills,
        prefix=prefix,
    )
    return "\n\n".join(lines), markup, items, skills, has_next


async def render_master_card(
    bot,
    master_id: int,
    *,
    staff: StaffUser,
    mode: str = "masters",
    prefix: str = "adm:m",
    group: str | None = None,
    category: str | None = None,
    page: int | None = None,
) -> tuple[str, InlineKeyboardMarkup]:
    service = _masters_service(bot)
    detail = await service.get_master_detail(master_id)
    if not detail:
        return "Мастер не найден или удалён.", back_to_menu()

    status_parts: list[str] = []
    if detail.is_deleted:
        status_parts.append("удалён")
    if not detail.verified:
        status_parts.append("не проверен")
    if not detail.is_active:
        status_parts.append("не активен")
    if detail.is_blocked:
        status_parts.append("заблокирован")
    status_line = ", ".join(status_parts) if status_parts else "активен"

    avg_check = f"{detail.avg_check:.0f} ₽" if detail.avg_check is not None else "—"
    limit_value = detail.current_limit if detail.current_limit else "—"
    verified_at = detail.verified_at_local or "—"
    status_value = (detail.shift_status or "").upper()
    shift = _shift_label(status_value, status_value == "BREAK")

    lines = [
        f"👷 <b>{detail.full_name}</b> #{detail.id}",
        f"📍 Город: {detail.city_name or '—'}",
        f"📞 Телефон: {detail.phone or '—'}",
        f"⭐️ Рейтинг: {detail.rating:.1f}",
        f"🚗 Транспорт: {'Авто' if detail.has_vehicle else 'Пеший'}",
        f"🕒 Смена: {shift}",
        f"📊 Активные заказы: {detail.active_orders}",
        f"🎯 Лимит: {limit_value}",
        f"💰 Средний чек: {avg_check}",
        f"📎 Статус: {status_line}",
        f"✅ Проверен: {detail.verified}",
        f"📅 Дата проверки: {verified_at}",
    ]
    if detail.referral_code:
        lines.append(f"?? ???. ???: {detail.referral_code}")
        try:
            ref_stats = await service.get_master_referral_stats(master_id)
            if ref_stats and ref_stats.get("invited_total", 0) > 0:
                lines.append(
                    f"?? ?????????: {ref_stats['invited_total']} "
                    f"(????????: {ref_stats['invited_pending']})"
                )
                lines.append(
                    f"?? ??????????: {ref_stats['rewards_amount']:.2f} ? "
                    f"({ref_stats['rewards_count']} ??.)"
                )
        except Exception:
            logger.debug("Failed to load referral stats", exc_info=True)

    if detail.moderation_reason:
        lines.append(f"📝 Причина: {detail.moderation_reason}")
    if detail.blocked_reason:
        lines.append(f"🚫 Блокировка: {detail.blocked_reason}")
    lines.append(
        "🏙 Районы: " + (", ".join(detail.district_names) or "—")
    )
    lines.append(
        "🛠 Навыки: " + (", ".join(detail.skill_names) or "—")
    )
    if detail.documents:
        doc_types = ", ".join(filter(None, (doc.document_type for doc in detail.documents)))
        lines.append("📄 Документы: " + (doc_types or "доступны"))
    lines.append(f"📅 Создан: {detail.created_at_local}")
    lines.append(f"🆙 Обновлён: {detail.updated_at_local}")

    markup = build_card_kb(
        detail,
        staff,
        mode=mode,
        prefix=prefix,
        group=group,
        category=category,
        page=page,
    )
    return "\n".join(lines), markup


async def _refresh_card_message(
    bot,
    chat_id: int,
    message_id: int,
    master_id: int,
    staff: StaffUser,
    *,
    mode: str = "masters",
    prefix: str = "adm:m",
    group: str | None = None,
    category: str | None = None,
    page: int | None = None,
) -> None:
    try:
        text, markup = await render_master_card(
            bot,
            master_id,
            staff=staff,
            mode=mode,
            prefix=prefix,
            group=group,
            category=category,
            page=page,
        )
        await bot.edit_message_text(
            text,
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=markup,
        )
    except Exception:
        logger.debug("Failed to refresh master card", exc_info=True)


async def refresh_card(
    cq: CallbackQuery,
    master_id: int,
    staff: StaffUser,
    *,
    mode: str | None = None,
    prefix: str = "adm:m",
    group: str | None = None,
    category: str | None = None,
    page: int | None = None,
) -> None:
    if not cq.message:
        return
    text, markup = await render_master_card(
        cq.bot,
        master_id,
        staff=staff,
        mode=mode or ("moderation" if prefix == "adm:mod" else "masters"),
        prefix=prefix,
        group=group,
        category=category,
        page=page,
    )
    await cq.message.edit_text(text, reply_markup=markup)


async def _send_master_event(
    service,
    master_id: int,
    event: NotificationEvent,
    **payload: Any,
) -> None:
    session_factory = getattr(service, "_session_factory", None)
    if session_factory is None:
        return
    try:
        async with session_factory() as session:
            await push_notify_master(
                session,
                master_id=master_id,
                event=event,
                **payload,
            )
            await session.commit()
    except Exception:
        logger.warning(
            "Failed to enqueue push notification %s for master %s",
            event,
            master_id,
            exc_info=True,
        )


async def notify_master_event(
    bot,
    master_id: int,
    event: NotificationEvent,
    **kwargs: Any,
) -> None:
    service = _masters_service(bot)
    await _send_master_event(service, master_id, event, **kwargs)


async def notify_master(bot, master_id: int, message: str) -> None:
    try:
        service = _masters_service(bot)
        await service.enqueue_master_notification(master_id, message)
    except Exception:
        logger.warning("Failed to enqueue master notification", exc_info=True)


@router.callback_query(
    F.data.startswith("adm:m:grp:"),
    StaffRoleFilter(VIEW_ROLES),
)
async def open_group(cq: CallbackQuery, staff: StaffUser) -> None:
    group = cq.data.split(":")[-1]
    text, markup, *_ = await render_master_list(
        cq.bot,
        group,
        "all",
        1,
        staff=staff,
    )
    if cq.message:
        await cq.message.edit_text(text, reply_markup=markup)
    await cq.answer()


@router.callback_query(
    F.data.startswith("adm:m:list:"),
    StaffRoleFilter(VIEW_ROLES),
)
async def list_page(cq: CallbackQuery, staff: StaffUser) -> None:
    parts = cq.data.split(":")
    try:
        _, _, _, group, category, page = parts
        page_num = max(1, int(page))
    except (ValueError, IndexError):
        await cq.answer("Некорректный запрос", show_alert=True)
        return
    text, markup, *_ = await render_master_list(
        cq.bot,
        group,
        category,
        page_num,
        staff=staff,
    )
    if cq.message:
        await cq.message.edit_text(text, reply_markup=markup)
    await cq.answer()


@router.callback_query(
    F.data.startswith("adm:m:card:"),
    StaffRoleFilter(VIEW_ROLES),
)
async def master_card(cq: CallbackQuery, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    text, markup = await render_master_card(
        cq.bot,
        action.master_id,
        staff=staff,
        mode=action.mode,
        prefix=action.prefix,
        group=action.group,
        category=action.category,
        page=action.page,
    )
    if cq.message:
        await cq.message.edit_text(text, reply_markup=markup)
    await cq.answer()


@router.callback_query(
    F.data.startswith("adm:m:ok"),
    StaffRoleFilter(MANAGE_ROLES),
)
async def approve_master(cq: CallbackQuery, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    master_id = action.master_id
    service = _masters_service(cq.bot)
    if not await service.approve_master(master_id, staff.id):
        await cq.answer("Не удалось обновить статус", show_alert=True)
        return
    await _send_master_event(
        service,
        master_id,
        NotificationEvent.MODERATION_APPROVED,
    )
    await notify_master(
        cq.bot,
        master_id,
        "Анкета одобрена. Вам доступна смена.",
    )
    await refresh_card(
        cq,
        master_id,
        staff,
        mode=action.mode,
        prefix=action.prefix,
        group=action.group,
        category=action.category,
        page=action.page,
    )
    await cq.answer("Мастер одобрен")


@router.callback_query(
    F.data.startswith("adm:m:rej"),
    StaffRoleFilter(MANAGE_ROLES),
)
async def ask_reject_reason(cq: CallbackQuery, state: FSMContext, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    await state.set_state(RejectReasonState.waiting)
    await state.update_data(
        master_id=action.master_id,
        action="reject",
        origin_chat_id=cq.message.chat.id if cq.message else None,
        origin_message_id=cq.message.message_id if cq.message else None,
        prefix=action.prefix,
        group=action.group,
        category=action.category,
        page=action.page,
        mode=action.mode,
    )
    if cq.message:
        await cq.message.answer("Укажите причину отклонения (1–200 символов).")
    await cq.answer()


@router.callback_query(
    F.data.startswith("adm:m:blk"),
    StaffRoleFilter(MANAGE_ROLES),
)
async def ask_block_reason(cq: CallbackQuery, state: FSMContext, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    await state.set_state(RejectReasonState.waiting)
    await state.update_data(
        master_id=action.master_id,
        action="block",
        origin_chat_id=cq.message.chat.id if cq.message else None,
        origin_message_id=cq.message.message_id if cq.message else None,
        prefix=action.prefix,
        group=action.group,
        category=action.category,
        page=action.page,
        mode=action.mode,
    )
    if cq.message:
        await cq.message.answer("Укажите причину блокировки (1–200 символов).")
    await cq.answer()


@router.message(
    StateFilter(RejectReasonState.waiting),
    StaffRoleFilter(MANAGE_ROLES),
)
async def process_reason(message: Message, state: FSMContext, staff: StaffUser) -> None:
    data = await state.get_data()
    master_id = int(data.get("master_id", 0))
    action = data.get("action")
    origin_chat_id = data.get("origin_chat_id")
    origin_message_id = data.get("origin_message_id")
    reason = (message.text or "").strip()
    if not 1 <= len(reason) <= 200:
        await message.answer("Причина должна быть от 1 до 200 символов.")
        return
    service = _masters_service(message.bot)
    if action == "reject":
        ok = await service.reject_master(master_id, reason=reason, by_staff_id=staff.id)
        if not ok:
            await message.answer("Не удалось отклонить мастера.")
            await state.clear()
            return
        await _send_master_event(
            service,
            master_id,
            NotificationEvent.MODERATION_REJECTED,
            reason=reason,
        )
        await notify_master(
            message.bot,
            master_id,
            f"Анкета отклонена. Причина: {reason}",
        )
        await message.answer("Анкета отклонена.")
    else:
        ok = await service.block_master(master_id, reason=reason, by_staff_id=staff.id)
        if not ok:
            await message.answer("Не удалось заблокировать мастера.")
            await state.clear()
            return
        await _send_master_event(
            service,
            master_id,
            NotificationEvent.ACCOUNT_BLOCKED,
            reason=reason,
        )
        await notify_master(
            message.bot,
            master_id,
            f"Ваш аккаунт заблокирован. Причина: {reason}",
        )
        await message.answer("Мастер заблокирован.")
    if origin_chat_id and origin_message_id:
        await _refresh_card_message(
            message.bot,
            origin_chat_id,
            origin_message_id,
            master_id,
            staff,
            mode=data.get("mode", "masters"),
            prefix=str(data.get("prefix") or "adm:m"),
            group=data.get("group"),
            category=data.get("category"),
            page=data.get("page"),
        )
    await state.clear()


@router.callback_query(
    F.data.startswith("adm:m:unb"),
    StaffRoleFilter(MANAGE_ROLES),
)
async def unblock_master(cq: CallbackQuery, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    master_id = action.master_id
    service = _masters_service(cq.bot)
    if not await service.unblock_master(master_id, by_staff_id=staff.id):
        await cq.answer("Не удалось разблокировать", show_alert=True)
        return
    await _send_master_event(
        service,
        master_id,
        NotificationEvent.ACCOUNT_UNBLOCKED,
    )
    await notify_master(cq.bot, master_id, "Ваш аккаунт разблокирован.")
    await refresh_card(
        cq,
        master_id,
        staff,
        mode=action.mode,
        prefix=action.prefix,
        group=action.group,
        category=action.category,
        page=action.page,
    )
    await cq.answer("Разблокирован")


@router.callback_query(
    F.data.startswith("adm:m:lim"),
    StaffRoleFilter(MANAGE_ROLES),
)
async def ask_limit(cq: CallbackQuery, state: FSMContext, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    await state.set_state(ChangeLimitState.waiting)
    await state.update_data(
        master_id=action.master_id,
        origin_chat_id=cq.message.chat.id if cq.message else None,
        origin_message_id=cq.message.message_id if cq.message else None,
        prefix=action.prefix,
        group=action.group,
        category=action.category,
        page=action.page,
        mode=action.mode,
    )
    if cq.message:
        await cq.message.answer("Введите лимит активных заказов (1–20):")
    await cq.answer()


@router.message(
    StateFilter(ChangeLimitState.waiting),
    StaffRoleFilter(MANAGE_ROLES),
)
async def change_limit(message: Message, state: FSMContext, staff: StaffUser) -> None:
    data = await state.get_data()
    master_id = int(data.get("master_id", 0))
    origin_chat_id = data.get("origin_chat_id")
    origin_message_id = data.get("origin_message_id")
    raw_value = (message.text or "").strip()
    if not raw_value.isdigit():
        await message.answer("Введите число от 1 до 20.")
        return
    limit = max(1, min(int(raw_value), 20))
    service = _masters_service(message.bot)
    if not await service.set_master_limit(master_id, limit=limit, by_staff_id=staff.id):
        await message.answer("Не удалось обновить лимит.")
        await state.clear()
        return
    await _send_master_event(
        service,
        master_id,
        NotificationEvent.LIMIT_CHANGED,
        limit=limit,
    )
    await notify_master(
        message.bot,
        master_id,
        f"Ваш лимит активных заказов обновлён: {limit}",
    )
    await message.answer(f"Лимит обновлён: {limit}")
    if origin_chat_id and origin_message_id:
        await _refresh_card_message(
            message.bot,
            origin_chat_id,
            origin_message_id,
            master_id,
            staff,
            mode=data.get("mode", "masters"),
            prefix=str(data.get("prefix") or "adm:m"),
            group=data.get("group"),
            category=data.get("category"),
            page=data.get("page"),
        )
    await state.clear()


@router.callback_query(
    F.data.startswith("adm:m:docs"),
    StaffRoleFilter(VIEW_ROLES),
)
async def _relay_document(current_bot, *, chat_id: int, file_id: str, file_type: str, caption: str = "", filename: str | None = None) -> bool:
    token = getattr(env_settings, 'master_bot_token', None)
    if not token:
        return False
    try:
        async with Bot(token) as source_bot:
            with TemporaryDirectory() as tmpdir:
                # Resolve filename from Telegram file info or fallback by type
                try:
                    info = await source_bot.get_file(file_id)
                    suggested = Path(getattr(info, "file_path", "") or "").name or None
                except Exception:
                    suggested = None
                if not filename and suggested:
                    filename_use = suggested
                elif filename:
                    filename_use = filename
                else:
                    ext = ".jpg" if file_type.upper() == "PHOTO" else (".pdf" if file_type.upper() == "DOCUMENT" else ".bin")
                    filename_use = f"doc{ext}"
                tmp = Path(tmpdir) / filename_use
                await source_bot.download(file_id, destination=tmp)
                if file_type.upper() == "PHOTO":
                    await current_bot.send_photo(chat_id, FSInputFile(tmp, filename=filename_use), caption=caption)
                else:
                    await current_bot.send_document(chat_id, FSInputFile(tmp, filename=filename_use), caption=caption)
        return True
    except Exception:
        logger.warning('Relay via master bot failed', exc_info=True)
        return False

async def show_documents(cq: CallbackQuery, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    master_id = action.master_id
    try:
        await cq.answer()
    except Exception:
        pass
    service = _masters_service(cq.bot)
    detail = await service.get_master_detail(master_id)
    if not detail or not detail.documents:
        if cq.message:
            await cq.message.answer("Документы отсутствуют")
        return
    chat_id = cq.message.chat.id if cq.message else None
    for document in detail.documents:
        caption = document.caption or document.document_type or ''
        file_type = (document.file_type or '').upper()
        try:
            if file_type == 'PHOTO':
                await cq.message.answer_photo(document.file_id, caption=caption)
            elif file_type == 'DOCUMENT':
                await cq.message.answer_document(document.file_id, caption=caption)
            else:
                await cq.message.answer(f"Неизвестный тип файла: {document.file_type}")
        except Exception:
            if chat_id is not None:
                ok = await _relay_document(cq.bot, chat_id=chat_id, file_id=document.file_id, file_type=file_type, caption=caption, filename=(document.file_name or None))
                if not ok:
                    logger.warning('Failed to send document', exc_info=True)
            else:
                logger.warning('Failed to send document', exc_info=True)
@router.callback_query(
    F.data.startswith("adm:m:del"),
    StaffRoleFilter(MANAGE_ROLES),
)
async def delete_master(cq: CallbackQuery, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    master_id = action.master_id
    group_value = action.group or ("mod" if action.mode == "moderation" else "ok")
    category_value = action.category or "all"
    page_value = action.page or 1
    prefix = action.prefix
    kb = InlineKeyboardBuilder()
    kb.button(
        text="✅ Подтвердить",
        callback_data=f"{prefix}:delconfirm:{group_value}:{category_value}:{page_value}:{master_id}",
    )
    kb.button(
        text="⬅️ Назад",
        callback_data=f"{prefix}:card:{group_value}:{category_value}:{page_value}:{master_id}",
    )
    if cq.message:
        await cq.message.edit_text(
            "Точно удалить мастера?", reply_markup=kb.as_markup()
        )
    await cq.answer()


@router.callback_query(
    F.data.startswith("adm:m:delconfirm"),
    StaffRoleFilter(MANAGE_ROLES),
)
async def perform_delete(cq: CallbackQuery, staff: StaffUser) -> None:
    try:
        action = parse_master_action(cq.data)
    except ValueError:
        await cq.answer("Некорректный идентификатор", show_alert=True)
        return
    master_id = action.master_id
    service = _masters_service(cq.bot)
    success, soft = await service.delete_master(master_id, by_staff_id=staff.id)
    if not success:
        await cq.answer("Не удалось удалить", show_alert=True)
        return
    if soft:
        await cq.answer("Профиль помечен как удалён", show_alert=True)
        await refresh_card(
            cq,
            master_id,
            staff,
            mode=action.mode,
            prefix=action.prefix,
            group=action.group,
            category=action.category,
            page=action.page,
        )
    else:
        if cq.message:
            await cq.message.edit_text("Профиль удалён окончательно.", reply_markup=back_to_menu())
        await cq.answer("Профиль удалён", show_alert=True)


__all__ = [
    "router",
    "render_master_list",
    "render_master_card",
    "build_card_kb",
    "refresh_card",
    "notify_master",
    "notify_master_event",
    "parse_master_action",
    "RejectReasonState",
]




