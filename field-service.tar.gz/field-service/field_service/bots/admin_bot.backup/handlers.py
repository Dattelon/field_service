from __future__ import annotations

import html
import json
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Optional, Sequence
from zoneinfo import ZoneInfo

from aiogram import F, Router, Bot
from field_service.bots.common import (
    FSMTimeoutConfig,
    FSMTimeoutMiddleware,
    safe_send_message,
)
from aiogram.exceptions import TelegramBadRequest
from .utils import get_service
from aiogram.filters import Command, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, FSInputFile, InlineKeyboardMarkup, Message

# Local router instance for handlers in this module
router = Router()

async def _fsm_timeout_notice(state: FSMContext) -> None:
    chat_id = state.key.chat_id
    if chat_id is None:
        return
    try:
        await safe_send_message(state.bot, chat_id, FSM_TIMEOUT_MESSAGE)
    except Exception:
        pass


_TIMEOUT_MIDDLEWARE = FSMTimeoutMiddleware(
    FSMTimeoutConfig(timeout=timedelta(minutes=10), callback=_fsm_timeout_notice)
)

router.message.middleware(_TIMEOUT_MIDDLEWARE)
router.callback_query.middleware(_TIMEOUT_MIDDLEWARE)


from field_service.config import settings as env_settings


from field_service.services import export_service, live_log, time_service
WORKDAY_START_DEFAULT = time_service.parse_time_string(env_settings.workday_start, default=time(10, 0))
WORKDAY_END_DEFAULT = time_service.parse_time_string(env_settings.workday_end, default=time(20, 0))
LATE_ASAP_THRESHOLD = time_service.parse_time_string(env_settings.asap_late_threshold, default=time(19, 30))
SLOT_BUCKETS: tuple[tuple[str, time, time], ...] = tuple(
    (bucket, span[0], span[1]) for bucket, span in time_service._SLOT_BUCKETS.items()
)

from field_service.services import settings_service
from field_service.db.models import OrderType, StaffRole, OrderStatus
from field_service.services.onboarding_service import normalize_phone
from .access import visible_city_ids_for
from .dto import NewOrderAttachment, NewOrderData, StaffUser
from .normalizers import normalize_category, normalize_status
from .filters import StaffRoleFilter
from .keyboards import (
    main_menu,
    order_card_keyboard,
    finance_menu,
    logs_menu_keyboard,
    settings_menu_keyboard,
    reports_menu_keyboard,
    reports_periods_keyboard,
    new_order_city_keyboard,
    new_order_district_keyboard,
    new_order_street_mode_keyboard,
    new_order_street_keyboard,
    new_order_street_manual_keyboard,
    new_order_attachments_keyboard,
    new_order_slot_keyboard,
    assign_menu_keyboard,
    new_order_confirm_keyboard,
    new_order_asap_late_keyboard,
)
from .queue import CATEGORY_CHOICES, CATEGORY_LABELS, CATEGORY_LABELS_BY_VALUE

from .states import (
    NewOrderFSM,
    ReportsExportFSM,
    SettingsEditFSM,
    StaffAccessFSM,
)
from field_service.bots.admin_bot.services_db import AccessCodeError
from .texts import FSM_TIMEOUT_MESSAGE, new_order_summary, order_card

def _maybe_fix_mojibake(s: Any) -> Any:
    return s

# ---------- Читаемые русские константы (override) ----------
# Эти присваивания гарантируют, что пользователь увидит нормальные строки,
# даже если где-то в файле остались кракозябры из старых литералов.

STAFF_CODE_PROMPT = "Введите код доступа, который выдал администратор."
STAFF_CODE_ERROR = "Код не найден / истёк / уже использован / вам недоступен."
STAFF_PDN_TEXT = (
    "Согласие на обработку персональных данных.",
    "Согласие включает обработку ФИО, телефона и данных о заказах для допуска к работе и обеспечения безопасности сервиса. ",
    "Отправьте \"Согласен\" для продолжения или \"Не согласен\" для отмены."
)
REPORT_DEFINITIONS: dict[str, tuple[str, Any, str]] = {
    "orders": ("Заказы", export_service.export_orders, "Orders"),
    "commissions": ("Комиссии", export_service.export_commissions, "Commissions"),
    "ref_rewards": ("Реферальные начисления", export_service.export_referral_rewards, "Referral rewards"),
}

DATE_INPUT_FORMATS = ("%Y-%m-%d", "%d.%m.%Y")

# Timezone for local time conversions
LOCAL_TZ = ZoneInfo(env_settings.timezone or "UTC")

# Staff role labels
STAFF_ROLE_LABELS = {
    StaffRole.GLOBAL_ADMIN: "Глобальный администратор",
    StaffRole.CITY_ADMIN: "Администратор города",
    StaffRole.LOGIST: "Логист",
}

# Access code error messages
ACCESS_CODE_ERROR_MESSAGES = {
    "expired": "Код истёк. Запросите новый у администратора.",
    "used": "Код уже использован.",
    "not_found": "Код не найден.",
    "role_mismatch": "Код вам недоступен (несоответствие ролей).",
}

# Aliases for text formatting functions
format_order_card = order_card


def _parse_period_input(text: str) -> tuple[date, date] | None:
    """
    Парсит ввод пользователя в формате 'YYYY-MM-DD YYYY-MM-DD'
    или 'DD.MM.YYYY DD.MM.YYYY' и возвращает кортеж из двух дат.
    
    Returns:
        tuple[date, date] | None: Кортеж (start_date, end_date) или None при ошибке
    """
    text = text.strip()
    if not text:
        return None
    
    parts = text.split()
    if len(parts) != 2:
        return None
    
    start_str, end_str = parts
    
    # Пробуем разные форматы
    for fmt in DATE_INPUT_FORMATS:
        try:
            start_dt = datetime.strptime(start_str, fmt).date()
            end_dt = datetime.strptime(end_str, fmt).date()
            if start_dt <= end_dt:
                return start_dt, end_dt
        except ValueError:
            continue
    
    return None


def _format_period_label(start_dt: date, end_dt: date) -> str:
    """
    Форматирует две даты в читаемую строку для отображения в отчете.
    
    Args:
        start_dt: Начальная дата
        end_dt: Конечная дата
    
    Returns:
        str: Отформатированная строка типа "01.01.2024 - 31.01.2024"
    """
    if start_dt == end_dt:
        return start_dt.strftime("%d.%m.%Y")
    return f"{start_dt.strftime('%d.%m.%Y')} - {end_dt.strftime('%d.%m.%Y')}"


async def show_admin_main_menu(
    message: Message,
    staff: StaffUser,
    *,
    edit: bool = False,
    notice: str | None = None,
) -> None:
    """Показывает главное меню админ-бота"""
    text = notice or "Выберите раздел:"
    markup = main_menu(staff)
    
    if edit:
        try:
            await message.edit_text(text, reply_markup=markup)
        except Exception:
            await message.answer(text, reply_markup=markup)
    else:
        await message.answer(text, reply_markup=markup)


@dataclass(frozen=True)
class SettingFieldDef:
    key: str
    label: str
    schema: str
    value_type: str = "STR"
    choices: tuple[tuple[str, str], ...] | None = None
    help_text: str = ""
    default: object | None = None


@dataclass(frozen=True)
class SettingGroupDef:
    key: str
    title: str
    fields: tuple[SettingFieldDef, ...]
    description: str = ""


"""
SETTING_GROUPS: dict[str, SettingGroupDef] = {
    "workday": SettingGroupDef(
        key="workday",
        title="Рабочий день",\n        description="Рабочий интервал сервиса. В это время назначаются визиты мастеров.",
        fields=(
            SettingFieldDef(
                key="working_hours_start",
                label="Начало рабочего дня",
                schema="time",
                value_type="TIME",
                default=env_settings.working_hours_start,
                help_text="Формат ЧЧ:ММ, по умолчанию 10:00.",
            ),
            SettingFieldDef(
                key="working_hours_end",
                label="Конец рабочего дня",
                schema="time",
                value_type="TIME",
                default=env_settings.working_hours_end,
                help_text="Формат ЧЧ:ММ, по умолчанию 20:00.",
            ),
        ),
    ),
    "distribution": SettingGroupDef(
        key="distribution",
        title="Рабочий день",\n        description="Рабочий интервал сервиса. В это время назначаются визиты мастеров.",
        fields=(
            SettingFieldDef(
                key="distribution_tick_seconds",
                label="   ()",
                schema="int",
                value_type="INT",
                default=30,
            ),
            SettingFieldDef(
                key="distribution_sla_seconds",
                label="SLA  ()",
                schema="int",
                value_type="INT",
                default=env_settings.distribution_sla_seconds,
            ),
            SettingFieldDef(
                key="distribution_rounds",
                label=" ",
                schema="int",
                value_type="INT",
                default=env_settings.distribution_rounds,
            ),
            SettingFieldDef(
                key="escalate_to_admin_after_min",
                label="  ()",
                schema="int_non_negative",
                value_type="INT",
                default=10,
            ),
            SettingFieldDef(
                key="distribution_log_topn",
                label=" topN   ",
                schema="int",
                value_type="INT",
                default=10,
            ),
        ),
    ),
    "limits": SettingGroupDef(
        key="limits",
        title="",
        fields=(
            SettingFieldDef(
                key="max_active_orders",
                label=".    ",
                schema="int",
                value_type="INT",
                default=1,
            ),
        ),
    ),
    "support": SettingGroupDef(
        key="support",
        title="Рабочий день",\n        description="Рабочий интервал сервиса. В это время назначаются визиты мастеров.",
        fields=(
            SettingFieldDef(
                key="support_contact",
                label=" ",
                schema="string",
                value_type="STR",
                help_text=" @username,    .",
            ),
            SettingFieldDef(
                key="support_faq_url",
                label="  FAQ",
                schema="string_optional",
                value_type="STR",
                help_text=" URL  '-'  .",
            ),
        ),
    ),
    "geo": SettingGroupDef(
        key="geo",
        title="",
        fields=(
            SettingFieldDef(
                key="geo_mode",
                label="",
                schema="choice",
                value_type="STR",
                choices=(
                    ("local_centroids", " "),
                    ("yandex", ""),
                ),
                default="local_centroids",
                help_text="1  , 2   API.",
            ),
            SettingFieldDef(
                key="yandex_geocoder_key",
                label="API  ",
                schema="string_optional",
                value_type="STR",
                help_text="   '-'  .",
            ),
            SettingFieldDef(
                key="yandex_throttle_rps",
                label="RPS ",
                schema="int_non_negative",
                value_type="INT",
                default=1,
            ),
            SettingFieldDef(
                key="yandex_daily_limit",
                label="  ",
                schema="int_non_negative",
                value_type="INT",
                default=1000,
            ),
        ),
    ),
    "channels": SettingGroupDef(
        key="channels",
        title="Рабочий день",\n        description="Рабочий интервал сервиса. В это время назначаются визиты мастеров.",
        fields=(
            SettingFieldDef(
                key="alerts_channel_id",
                label="Alerts / ",
                schema="int_optional",
                value_type="STR",
                help_text="ID   '-'  .",
            ),
            SettingFieldDef(
                key="logs_channel_id",
                label=" ",
                schema="int_optional",
                value_type="STR",
                help_text="ID   '-'  .",
            ),
            SettingFieldDef(
                key="reports_channel_id",
                label=" ",
                schema="int_optional",
                value_type="STR",
                help_text="ID   '-'  .",
            ),
        ),
    ),
}
SETTINGS_GROUPS = SETTING_GROUPS
"""

# Cleaned settings groups (mojibake-free)
SETTING_GROUPS: dict[str, SettingGroupDef] = {
    "workday": SettingGroupDef(
        key="workday",
        title="Рабочий день",
        description="Рабочий интервал сервиса. В это время назначаются визиты мастеров.",
        fields=(
            SettingFieldDef(
                key="working_hours_start",
                label="Начало рабочего дня",
                schema="time",
                value_type="TIME",
                default=env_settings.working_hours_start,
                help_text="Формат ЧЧ:ММ, по умолчанию 10:00.",
            ),
            SettingFieldDef(
                key="working_hours_end",
                label="Конец рабочего дня",
                schema="time",
                value_type="TIME",
                default=env_settings.working_hours_end,
                help_text="Формат ЧЧ:ММ, по умолчанию 20:00.",
            ),
        ),
    ),
    "distribution": SettingGroupDef(
        key="distribution",
        title="Распределение",
        description="Настройки автораспределения заявок (частота, SLA, раунды).",
        fields=(
            SettingFieldDef(
                key="distribution_tick_seconds",
                label="Шаг цикла (сек.)",
                schema="int",
                value_type="INT",
                default=30,
            ),
            SettingFieldDef(
                key="distribution_sla_seconds",
                label="SLA ответа мастера (сек.)",
                schema="int",
                value_type="INT",
                default=env_settings.distribution_sla_seconds,
            ),
            SettingFieldDef(
                key="distribution_rounds",
                label="Количество раундов",
                schema="int",
                value_type="INT",
                default=env_settings.distribution_rounds,
            ),
            SettingFieldDef(
                key="escalate_to_admin_after_min",
                label="Эскалация к админу через (мин.)",
                schema="int_non_negative",
                value_type="INT",
                default=10,
            ),
            SettingFieldDef(
                key="distribution_log_topn",
                label="Логировать topN кандидатов",
                schema="int",
                value_type="INT",
                default=10,
            ),
        ),
    ),
    "limits": SettingGroupDef(
        key="limits",
        title="Лимиты",
        description="Ограничения сервиса для мастеров и процессов.",
        fields=(
            SettingFieldDef(
                key="max_active_orders",
                label="Макс. активных заказов на мастера",
                schema="int",
                value_type="INT",
                default=1,
            ),
        ),
    ),
    "support": SettingGroupDef(
        key="support",
        title="Поддержка",
        description="Контакты поддержки и материалы.",
        fields=(
            SettingFieldDef(
                key="support_contact",
                label="Контакт поддержки",
                schema="string",
                value_type="STR",
                help_text="Например, @username, если доступно.",
            ),
            SettingFieldDef(
                key="support_faq_url",
                label="Ссылка на FAQ",
                schema="string_optional",
                value_type="STR",
                help_text="Укажите URL или '-' чтобы очистить.",
            ),
        ),
    ),
    "geo": SettingGroupDef(
        key="geo",
        title="Гео",
        description="Режим и лимиты геокодера.",
        fields=(
            SettingFieldDef(
                key="geo_mode",
                label="Режим геокодера",
                schema="choice",
                value_type="STR",
                choices=(
                    ("local_centroids", "Локальные центроиды"),
                    ("yandex", "Яндекс"),
                ),
                default="local_centroids",
                help_text="1 — локально, 2 — через API.",
            ),
            SettingFieldDef(
                key="yandex_geocoder_key",
                label="API‑ключ Яндекс",
                schema="string_optional",
                value_type="STR",
                help_text="Оставьте '-' чтобы очистить.",
            ),
            SettingFieldDef(
                key="yandex_throttle_rps",
                label="RPS ограничение",
                schema="int_non_negative",
                value_type="INT",
                default=1,
            ),
            SettingFieldDef(
                key="yandex_daily_limit",
                label="Суточный лимит запросов",
                schema="int_non_negative",
                value_type="INT",
                default=1000,
            ),
        ),
    ),
    "channels": SettingGroupDef(
        key="channels",
        title="Каналы",
        description="ID каналов Telegram для уведомлений и отчётов.",
        fields=(
            SettingFieldDef(
                key="alerts_channel_id",
                label="Канал алертов (ID)",
                schema="int_optional",
                value_type="STR",
                help_text="ID или '-' чтобы очистить.",
            ),
            SettingFieldDef(
                key="logs_channel_id",
                label="Канал логов (ID)",
                schema="int_optional",
                value_type="STR",
                help_text="ID или '-' чтобы очистить.",
            ),
            SettingFieldDef(
                key="reports_channel_id",
                label="Канал отчётов (ID)",
                schema="int_optional",
                value_type="STR",
                help_text="ID или '-' чтобы очистить.",
            ),
        ),
    ),
}
SETTINGS_GROUPS = SETTING_GROUPS



SETTING_FIELD_BY_KEY: dict[str, SettingFieldDef] = {
    field.key: field
    for group in SETTINGS_GROUPS.values()
    for field in group.fields
}

SETTING_FIELD_GROUP: dict[str, str] = {
    field.key: group.key
    for group in SETTINGS_GROUPS.values()
    for field in group.fields
}


EMPTY_PLACEHOLDER = ""
SCHEMA_DEFAULT_HELP = {
    "time": " :,  10:00.",
    "int": "    0.",
    "int_non_negative": "     0.",
    "string": " .",
    "string_optional": "   '-'  .",
    "int_optional": " ID  '-'  .",
    "choice": "   .",
}
LOG_ENTRIES_LIMIT = 20


def _get_setting_group(group_key: str) -> SettingGroupDef:
    group = SETTING_GROUPS.get(group_key)
    if group is None:
        raise KeyError(f"Unknown settings group: {group_key}")
    return group


def _get_setting_field(field_key: str) -> SettingFieldDef:
    field = SETTING_FIELD_BY_KEY.get(field_key)
    if field is None:
        raise KeyError(f"Unknown setting field: {field_key}")
    return field


def _format_setting_value(field: SettingFieldDef, raw_value: Optional[str]) -> tuple[str, bool]:
    value = raw_value
    from_default = False
    if value in (None, ""):
        value = field.default
        from_default = raw_value in (None, "") and value not in (None, "")
    if value in (None, ""):
        return EMPTY_PLACEHOLDER, False
    if field.schema == "choice" and field.choices:
        text_value = str(value)
        for idx, (code, label) in enumerate(field.choices, 1):
            if text_value == code:
                return f"{label} ({code})", from_default
    return str(value), from_default


def _choice_help(field: SettingFieldDef) -> str:
    if not field.choices:
        return ""
    lines = []
    for idx, (code, label) in enumerate(field.choices, 1):
        lines.append(f"{idx}. {label} ({code})")
    return "".join(lines)


def _build_setting_prompt(field: SettingFieldDef, current_display: str) -> str:
    lines = [f"<b>{field.label}</b>"]
    if current_display and current_display != EMPTY_PLACEHOLDER:
        lines.append(f" : <code>{html.escape(current_display, quote=False)}</code>")
    base_help = SCHEMA_DEFAULT_HELP.get(field.schema, " .")
    if field.schema == "choice":
        options = _choice_help(field)
        if options:
            lines.append(base_help)
            lines.append(options)
        else:
            lines.append(base_help)
    else:
        lines.append(field.help_text or base_help)
    lines.append(" /cancel  .")
    return "".join(lines)


def _parse_setting_input(field: SettingFieldDef, user_input: str) -> tuple[str, str]:
    text = (user_input or "").strip()
    if field.schema in {"string_optional", "int_optional"} and text in {"", "-"}:
        return "", field.value_type
    if field.schema == "time":
        if not re.fullmatch(r"^\d{1,2}:\d{2}$", text):
            raise ValueError("  .  :.")
        hh, mm = map(int, text.split(":"))
        if not (0 <= hh < 24 and 0 <= mm < 60):
            raise ValueError(" 023   059.")
        return text, field.value_type
    if field.schema == "int":
        try:
            value = int(text)
        except ValueError:
            raise ValueError("  .")
        if value <= 0:
            raise ValueError("    0.")
        return str(value), field.value_type
    if field.schema == "int_non_negative":
        try:
            value = int(text)
        except ValueError:
            raise ValueError("  .")
        if value < 0:
            raise ValueError("     0.")
        return str(value), field.value_type
    if field.schema == "int_optional":
        try:
            value = int(text)
        except ValueError:
            raise ValueError("    '-'  .")
        return str(value), field.value_type
    if field.schema == "choice":
        normalized = text.lower()
        if field.choices:
            for idx, (code, label) in enumerate(field.choices, 1):
                if normalized in {code.lower(), label.lower(), str(idx)}:
                    return code, field.value_type
        raise ValueError("   .")
    if field.schema == "string_optional":
        return text, field.value_type
    if field.schema == "string":
        if not text:
            raise ValueError("    .")
        return text, field.value_type
    raise ValueError("  .")


"""
async def _build_settings_view(bot, group_key: str) -> tuple[str, InlineKeyboardMarkup]:
    group = _get_setting_group(group_key)
    service = _settings_service(bot)
    raw_map = await service.get_values([field.key for field in group.fields])
    title = _RU_GROUP_TITLES.get(group.key, getattr(group, "title", group.key))
    desc = _RU_GROUP_DESCRIPTIONS.get(group.key, getattr(group, "description", ""))
    lines: list[str] = [f"<b>{title}</b>"]
    if desc:\n        lines.append(desc)
    for field in group.fields:
        raw_value = raw_map.get(field.key, (None, None))[0]
        display, from_default = _format_setting_value(field, raw_value)\n        label = _RU_FIELD_LABELS.get(field.key, _RU_FIELD_LABELS.get(field.key, field.label))
        if display == EMPTY_PLACEHOLDER:\n            value_line = f"{label}: {EMPTY_PLACEHOLDER}"
        else:
            value_line = f"{label}: <code>{html.escape(display, quote=False)}</code>"
        if from_default and field.default not in (None, ""):
            value_line += " <i>( )</i>"
        lines.append(value_line)\n    lines.append("Выберите поле ниже, чтобы отредактировать значение.")
    keyboard = settings_group_keyboard(
        group_key,
        [(field.key, _RU_FIELD_LABELS.get(field.key, field.label)) for field in group.fields],
    )
    return "".join(lines), keyboard
"""

async def _build_settings_view(bot, group_key: str) -> tuple[str, InlineKeyboardMarkup]:
    group = _get_setting_group(group_key)
    service = _settings_service(bot)
    raw_map = await service.get_values([field.key for field in group.fields])
    title = _RU_GROUP_TITLES.get(group.key, getattr(group, "title", group.key))
    desc = _RU_GROUP_DESCRIPTIONS.get(group.key, getattr(group, "description", ""))
    lines: list[str] = [f"<b>{title}</b>"]
    if desc:
        lines.append(desc)
    for field in group.fields:
        raw_value = raw_map.get(field.key, (None, None))[0]
        display, from_default = _format_setting_value(field, raw_value)
        label = _RU_FIELD_LABELS.get(field.key, _RU_FIELD_LABELS.get(field.key, field.label))
        if display == EMPTY_PLACEHOLDER:
            value_line = f"{label}: {EMPTY_PLACEHOLDER}"
        else:
            value_line = f"{label}: <code>{html.escape(display, quote=False)}</code>"
        if from_default and field.default not in (None, ""):
            value_line += " <i>(по умолчанию)</i>"
        lines.append(value_line)
    lines.append("Выберите поле ниже, чтобы отредактировать значение.")
    keyboard = settings_group_keyboard(
        group_key,
        [(field.key, _RU_FIELD_LABELS.get(field.key, field.label)) for field in group.fields],
    )
    return "".join(lines), keyboard

def _format_log_entries(entries: Sequence[live_log.LiveLogEntry]) -> str:
    if not entries:
        return '<b> </b>'

    lines = ['<b> </b>']
    for entry in entries:
        local_time = entry.timestamp.astimezone(LOCAL_TZ)
        body = html.escape(entry.message, quote=False).replace('\n', '<br>')
        lines.append(f'[{local_time:%H:%M:%S}] <i>{entry.source}</i>  {body}')
    return '\n'.join(lines)

def _staff_service(bot):
    return get_service(bot, "staff_service")


def _orders_service(bot):
    return get_service(bot, "orders_service")


async def _resolve_city_names(bot, city_ids: Sequence[int]) -> list[str]:
    if not city_ids:
        return []
    orders = _orders_service(bot)
    names: list[str] = []
    for city_id in city_ids:
        city = await orders.get_city(city_id)
        names.append(city.name if city else str(city_id))
    return names


def _masters_service(bot):
    return get_service(bot, "masters_service")


def _distribution_service(bot):
    return get_service(bot, "distribution_service")


def _finance_service(bot):
    return get_service(bot, "finance_service")


def _settings_service(bot):
    return get_service(bot, "settings_service")




PHONE_RE = re.compile(r"^\+7\d{10}$")
NAME_RE = re.compile(r"^[A-Za-zА-Яа-яЁё][A-Za-zА-Яа-яЁё\- ]{1,99}$")
ATTACHMENTS_LIMIT = 10

def _normalize_phone(value: str) -> str:
    digits = re.sub(r"[^0-9]", "", value)
    if digits.startswith("8") and len(digits) == 11:
        digits = "7" + digits[1:]
    if digits.startswith("7") and len(digits) == 11:
        return "+" + digits
    if digits.startswith("+7") and len(digits) == 12:
        return digits
    return value.strip()


def _validate_phone(value: str) -> bool:
    return bool(PHONE_RE.fullmatch(value))


def _validate_name(value: str) -> bool:
    return bool(NAME_RE.fullmatch(value))


def _attachments_from_state(data: dict) -> list[dict[str, Any]]:
    attachments = data.get("attachments")
    if attachments is None:
        attachments = []
        data["attachments"] = attachments
    return attachments


def _build_new_order_data(data: dict, staff: StaffUser) -> NewOrderData:
    attachments = [
        NewOrderAttachment(
            file_id=item["file_id"],
            file_unique_id=item.get("file_unique_id"),
            file_type=item["file_type"],
            file_name=item.get("file_name"),
            mime_type=item.get("mime_type"),
            caption=item.get("caption"),
        )
        for item in data.get("attachments", [])
    ]
    address_comment = data.get("address_comment") or None
    manual_street = data.get("street_manual")
    if manual_street:
        extra = f"( : {manual_street})"
        address_comment = f"{address_comment} {extra}".strip() if address_comment else extra
    initial_status_value = data.get("initial_status")
    initial_status = normalize_status(initial_status_value)
    total_sum_value = data.get("total_sum")
    if total_sum_value is None:
        total_sum_value = 0
    lat_value = data.get("lat")
    if lat_value is not None:
        try:
            lat_value = float(lat_value)
        except (TypeError, ValueError):
            lat_value = None
    lon_value = data.get("lon")
    if lon_value is not None:
        try:
            lon_value = float(lon_value)
        except (TypeError, ValueError):
            lon_value = None
    category_value = data.get("category")
    category_enum = normalize_category(category_value)
    if category_enum is None:
        raise ValueError("Category is required")

    return NewOrderData(
        city_id=int(data["city_id"]),
        district_id=data.get("district_id"),
        street_id=data.get("street_id"),
        house=str(data.get("house", "")) or None,
        apartment=data.get("apartment"),
        address_comment=address_comment,
        client_name=str(data.get("client_name")),
        client_phone=str(data.get("client_phone")),
        category=category_enum,
        description=str(data.get("description", "")),
        order_type=OrderType(data.get("order_type", OrderType.NORMAL.value)),
        timeslot_start_utc=data.get("timeslot_start_utc"),
        timeslot_end_utc=data.get("timeslot_end_utc"),
        timeslot_display=data.get("timeslot_display"),
        lat=lat_value,
        lon=lon_value,
        no_district=data.get("district_id") is None,
        company_payment=Decimal(data.get("company_payment", 0)),
        total_sum=Decimal(total_sum_value or 0),
        created_by_staff_id=staff.id,
        initial_status=initial_status,
        attachments=attachments,
    )



def _slot_options(
    now_local: datetime,
    *,
    workday_start: time,
    workday_end: time,
) -> list[tuple[str, str]]:
    current = now_local.timetz()
    if current.tzinfo is not None:
        current = current.replace(tzinfo=None)
    options: list[tuple[str, str]] = []
    if current < workday_end:
        options.append(("ASAP", "ASAP"))
        for bucket_key, start, end in SLOT_BUCKETS:
            if current < start:
                options.append((f"TODAY:{bucket_key}", f" {start:%H:%M}-{end:%H:%M}"))
    for bucket_key, start, end in SLOT_BUCKETS:
        options.append((f"TOM:{bucket_key}", f" {start:%H:%M}-{end:%H:%M}"))
    return options


def _format_slot_display(
    choice: str,
    computation: time_service.SlotComputation,
    *,
    tz: ZoneInfo,
) -> str:
    if choice == "ASAP":
        return "ASAP"
    formatted = time_service.format_timeslot_local(
        computation.start_utc,
        computation.end_utc,
        tz=tz,
    )
    return formatted or ""



def _zone_storage_value(tz: ZoneInfo) -> str:
    return getattr(tz, 'key', str(tz))


async def _resolve_city_timezone(bot: Bot, city_id: Optional[int]) -> ZoneInfo:
    if not city_id:
        return time_service.resolve_timezone()
    orders = _orders_service(bot)
    try:
        tz_value = await orders.get_city_timezone(int(city_id))
    except Exception:
        tz_value = None
    return time_service.resolve_timezone(tz_value)


async def _resolve_workday_window() -> tuple[time, time]:
    try:
        return await settings_service.get_working_window()
    except Exception:
        return WORKDAY_START_DEFAULT, WORKDAY_END_DEFAULT



async def _finalize_slot_selection(
    message: Message,
    state: FSMContext,
    *,
    slot_choice: str,
    tz: ZoneInfo,
    workday_start: time,
    workday_end: time,
    initial_status_override: Optional[OrderStatus] = None,
) -> None:
    computation = time_service.compute_slot(
        city_tz=tz,
        choice=slot_choice,
        workday_start=workday_start,
        workday_end=workday_end,
    )
    slot_display = _format_slot_display(slot_choice, computation, tz=tz)

    await state.update_data(
        timeslot_display=slot_display,
        timeslot_start_utc=computation.start_utc,
        timeslot_end_utc=computation.end_utc,
        initial_status=initial_status_override,
        pending_asap=False,
    )
    summary = new_order_summary(await state.get_data())
    await state.set_state(NewOrderFSM.confirm)
    await message.edit_text(
        summary,
        reply_markup=new_order_confirm_keyboard(),
        disable_web_page_preview=True,
    )


async def _send_export_documents(
    bot: Bot,
    bundle: export_service.ExportBundle,
    caption: str,
    *,
    chat_id: int,
) -> None:
    documents = [
        (bundle.csv_bytes, bundle.csv_filename, f"{caption} - CSV"),
        (bundle.xlsx_bytes, bundle.xlsx_filename, f"{caption} - XLSX"),
    ]
    with TemporaryDirectory() as tmpdir:
        base_path = Path(tmpdir)
        for payload, filename, note in documents:
            file_path = base_path / filename
            file_path.write_bytes(payload)
            await bot.send_document(
                chat_id=chat_id,
                document=FSInputFile(file_path),
                caption=note,
            )


async def _render_created_order_card(message: Message, order_id: int, staff: StaffUser) -> None:
    orders_service = _orders_service(message.bot)
    detail = await orders_service.get_card(order_id, city_ids=visible_city_ids_for(staff))
    if not detail:
        await message.answer(f" #{order_id} .")
        return
    text = format_order_card(detail)
    markup = order_card_keyboard(
        detail.id,
        attachments=detail.attachments,
        allow_return=(detail.status.upper() not in {"CANCELED", "CLOSED"}),
        allow_cancel=(detail.status.upper() not in {"CANCELED", "CLOSED"}),
        show_guarantee=False,
    )
    try:
        await message.edit_text(text, reply_markup=markup)
    except Exception:
        await message.answer(text, reply_markup=markup)

@router.message(CommandStart(), StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN, StaffRole.LOGIST}))
async def admin_start(message: Message, staff: StaffUser) -> None:
    #  ,    
    await message.answer("Добро пожаловать в Field Service. Выберите раздел:", reply_markup=main_menu(staff))
    return


@router.message(CommandStart())
async def not_allowed_start(message: Message, state: FSMContext) -> None:
    staff_service = _staff_service(message.bot)
    user_id = message.from_user.id if message.from_user else None
    staff = await staff_service.get_by_tg_id(user_id) if user_id else None
    if staff:
        await state.clear()
        await message.answer("  .", reply_markup=main_menu(staff))
        return
    await state.clear()
    await state.set_state(StaffAccessFSM.code)
    await message.answer(STAFF_CODE_PROMPT)


@router.message(StateFilter(StaffAccessFSM.code))
async def staff_access_enter_code(message: Message, state: FSMContext) -> None:
    code_value = (message.text or "").strip()
    if not code_value:
        await message.answer("  .")
        return
    staff_service = _staff_service(message.bot)
    record = await staff_service.validate_access_code_value(code_value)
    if not record:
        await message.answer(STAFF_CODE_ERROR)
        return
    role_label = STAFF_ROLE_LABELS.get(record.role, record.role.value)
    city_names = await _resolve_city_names(message.bot, record.city_ids)
    await state.update_data(
        access_code=record.code,
        access_code_id=record.id,
        access_role=record.role.value,
        access_city_ids=list(record.city_ids),
    )
    summary_lines = [
        f": {role_label}",
        f": {', '.join(city_names) if city_names else '-'}",
    ]
    await message.answer("\n".join(summary_lines))
    await state.set_state(StaffAccessFSM.pdn)
    await message.answer(STAFF_PDN_TEXT)


@router.message(StateFilter(StaffAccessFSM.pdn))
async def staff_access_pdn(message: Message, state: FSMContext) -> None:
    text_value = (message.text or "").strip().lower()
    if text_value in {" ", "", "no"}:
        await state.clear()
        await message.answer("   .  /start,  .")
        return
    if text_value not in {"", "", "ok", ""}:
        await message.answer(' ""  " ".')
        return
    await state.set_state(StaffAccessFSM.full_name)
    await message.answer("   (,   ).")


@router.message(StateFilter(StaffAccessFSM.full_name))
async def staff_access_full_name(message: Message, state: FSMContext) -> None:
    full_name = (message.text or "").strip()
    if len(full_name) < 5:
        await message.answer("  .")
        return
    await state.update_data(full_name=full_name)
    await state.set_state(StaffAccessFSM.phone)
    await message.answer("    +7XXXXXXXXXX  8XXXXXXXXXX.")


@router.message(StateFilter(StaffAccessFSM.phone))
async def staff_access_phone(message: Message, state: FSMContext) -> None:
    raw_phone = (message.text or "").strip()
    try:
        normalized = normalize_phone(raw_phone)
    except ValueError:
        await message.answer("  . : +7XXXXXXXXXX  8XXXXXXXXXX")
        return
    data = await state.get_data()
    code_value = data.get("access_code")
    full_name = data.get("full_name")
    role_token = data.get("access_role")
    if not code_value or not full_name or not role_token:
        await state.clear()
        await message.answer(" .  /start   .")
        return
    user = message.from_user
    if not user:
        await message.answer("    .")
        return
    staff_service = _staff_service(message.bot)
    try:
        staff_user = await staff_service.register_staff_user_from_code(
            code_value=code_value,
            tg_user_id=user.id,
            username=user.username,
            full_name=full_name,
            phone=normalized,
        )
    except AccessCodeError as exc:
        error_text = ACCESS_CODE_ERROR_MESSAGES.get(
            exc.reason,
            "   .    .",
        )
        await message.answer(error_text)
        await state.set_state(StaffAccessFSM.code)
        await message.answer(STAFF_CODE_PROMPT)
        return
    await state.clear()
    role_label = STAFF_ROLE_LABELS.get(staff_user.role, staff_user.role.value)
    city_names = await _resolve_city_names(message.bot, staff_user.city_ids)
    lines = [
        f"   {role_label}.",
        f": {', '.join(city_names) if city_names else '-'}",
    ]
    await message.answer("\n".join(lines))
    await message.answer(".  :", reply_markup=main_menu(staff_user))


@router.callback_query(
    F.data == "adm:menu",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN, StaffRole.LOGIST}),
)
async def cb_menu(cq: CallbackQuery, staff: StaffUser) -> None:
    await cq.message.edit_text(" :", reply_markup=main_menu(staff))
    await cq.answer()

@router.callback_query(
    F.data == "adm:staff:menu",
    StaffRoleFilter({StaffRole.CITY_ADMIN, StaffRole.LOGIST}),
)
async def cb_staff_menu_denied(cq: CallbackQuery, staff: StaffUser) -> None:
    if cq.message is not None:
        await cq.message.edit_text(
            " .  :",
            reply_markup=main_menu(staff),
        )
    await cq.answer(" ", show_alert=True)


# ==============================================================================
# ФИНАНСЫ
# ==============================================================================
# ВАЖНО: Все обработчики финансов (кроме входной точки cb_finance_root)
# находятся в handlers_finance.py для избежания дублирования и коллизий.
# См. CR-2025-10-03-012
@router.callback_query(
    F.data == "adm:f",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN}),
)
async def cb_finance_root(cq: CallbackQuery, staff: StaffUser, state: FSMContext) -> None:
    await state.clear()
    await cq.message.edit_text(" :", reply_markup=finance_menu(staff))
    await cq.answer()


@router.callback_query(
    F.data == "adm:r",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN}),
)
async def cb_reports(cq: CallbackQuery, staff: StaffUser, state: FSMContext) -> None:
    await state.clear()
    await cq.message.edit_text(":", reply_markup=reports_menu_keyboard())
    await cq.answer()


async def _prompt_report_period(cq: CallbackQuery, state: FSMContext, report_kind: str) -> None:
    await state.clear()
    label, _, _ = REPORT_DEFINITIONS[report_kind]
    await state.set_state(ReportsExportFSM.awaiting_period)
    await state.update_data(report_kind=report_kind)
    await cq.message.answer(
        f"Выберите период для отчёта ({label}) или укажите вручную:",
        reply_markup=reports_periods_keyboard(),
    )
    await cq.answer()


@router.callback_query(
    F.data == "adm:r:o",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN}),
)
async def cb_reports_orders(cq: CallbackQuery, state: FSMContext) -> None:
    await _prompt_report_period(cq, state, "orders")


@router.callback_query(
    F.data == "adm:r:c",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN}),
)
async def cb_reports_commissions(cq: CallbackQuery, state: FSMContext) -> None:
    await _prompt_report_period(cq, state, "commissions")


@router.callback_query(
    F.data == "adm:r:rr",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN}),
)
async def cb_reports_referrals(cq: CallbackQuery, state: FSMContext) -> None:
    await _prompt_report_period(cq, state, "ref_rewards")


@router.message(StateFilter(ReportsExportFSM.awaiting_period), F.text == "/cancel")
async def reports_cancel(msg: Message, state: FSMContext) -> None:
    await state.clear()
    await msg.answer("Редактирование отменено.")


@router.message(StateFilter(ReportsExportFSM.awaiting_period))
async def reports_period_submit(
    msg: Message,
    staff: StaffUser | None,  # may be None if access middleware did not resolve
    state: FSMContext,
) -> None:
    period = _parse_period_input(msg.text or "")
    if not period:
        await msg.answer(
            "Неверный формат. Введите даты как 'YYYY-MM-DD YYYY-MM-DD' или воспользуйтесь кнопками.",
            reply_markup=reports_periods_keyboard(),
        )
        return

    start_dt, end_dt = period
    data = await state.get_data()
    report_kind = data.get("report_kind")
    definition = REPORT_DEFINITIONS.get(report_kind or "")
    if not definition:
        await state.clear()
        await msg.answer(
            "   .    :",
            reply_markup=reports_menu_keyboard(),
        )
        return

    label, exporter, caption_prefix = definition
    # Staff may be None if middleware could not resolve; in that case do not filter by city
    city_ids = visible_city_ids_for(staff) if isinstance(staff, StaffUser) else None

    try:
        bundle = await exporter(date_from=start_dt, date_to=end_dt, city_ids=city_ids)
    except Exception:
        await state.clear()
        await msg.answer(
            "   .  .",
            reply_markup=reports_menu_keyboard(),
        )
        return

    period_label = _format_period_label(start_dt, end_dt)
    operator_chat_id = None
    if msg.chat:
        operator_chat_id = msg.chat.id
    elif msg.from_user:
        operator_chat_id = msg.from_user.id
    configured_chat_id: Optional[int] = None
    try:
        raw_channel_id = await settings_service.get_value("reports_channel_id")
    except Exception:
        raw_channel_id = None
    if raw_channel_id:
        candidate = raw_channel_id.strip()
        if candidate and candidate != "-":
            try:
                configured_chat_id = int(candidate)
            except ValueError:
                configured_chat_id = None
    target_chat_id = configured_chat_id or env_settings.reports_channel_id or operator_chat_id
    if target_chat_id is None:
        await state.clear()
        await msg.answer(
            "Report channel is not configured.",
            reply_markup=reports_menu_keyboard(),
        )
        return

    try:
        await _send_export_documents(
            msg.bot,
            bundle,
            f"{caption_prefix} {period_label}",
            chat_id=target_chat_id,
        )
    except TelegramBadRequest:
        if operator_chat_id is not None and target_chat_id != operator_chat_id:
            await _send_export_documents(
                msg.bot,
                bundle,
                f"{caption_prefix} {period_label}",
                chat_id=operator_chat_id,
            )
            await msg.answer("Report sent to your chat because the reports channel is unavailable.")
        else:
            await state.clear()
            await msg.answer("Failed to deliver report.")
            return
    else:
        await msg.answer("Report sent.")
    await state.clear()


def _compute_quick_period(key: str, *, tz: str) -> tuple[date, date] | None:
    now = time_service.now_in_city(tz)
    today = now.date()
    if key == "today":
        return today, today
    if key == "yesterday":
        y = today - timedelta(days=1)
        return y, y
    if key == "last7":
        return today - timedelta(days=6), today
    if key == "this_month":
        start = today.replace(day=1)
        return start, today
    if key == "prev_month":
        first_this = today.replace(day=1)
        prev_last = first_this - timedelta(days=1)
        start = prev_last.replace(day=1)
        end = prev_last
        return start, end
    return None


@router.callback_query(F.data.regexp(r"^adm:r:pd:(today|yesterday|last7|this_month|prev_month|custom)$"))
async def reports_quick_period_choice(
    cq: CallbackQuery,
    state: FSMContext,
    staff: StaffUser | None = None,
) -> None:
    key = (cq.data or "").rsplit(":", 1)[-1]
    data = await state.get_data()
    report_kind = data.get("report_kind")
    definition = REPORT_DEFINITIONS.get(report_kind or "")
    if not definition:
        await state.clear()
        if cq.message:
            await cq.message.edit_text("Выберите отчёт:", reply_markup=reports_menu_keyboard())
        await cq.answer()
        return
    if key == "custom":
        if cq.message:
            await cq.message.answer(
                "Введите период в формате: YYYY-MM-DD YYYY-MM-DD\nИли нажмите /cancel для отмены."
            )
        await cq.answer()
        return
    period = _compute_quick_period(key, tz=env_settings.timezone)
    if not period:
        await cq.answer("Неверный период", show_alert=True)
        return
    start_dt, end_dt = period
    label, exporter, caption_prefix = definition
    city_ids = visible_city_ids_for(staff) if isinstance(staff, StaffUser) else None
    try:
        bundle = await exporter(date_from=start_dt, date_to=end_dt, city_ids=city_ids)
    except Exception:
        if cq.message:
            await cq.message.answer("Не удалось сформировать отчёт.", reply_markup=reports_menu_keyboard())
        await cq.answer()
        return
    period_label = _format_period_label(start_dt, end_dt)
    target_chat_id = env_settings.reports_channel_id or (cq.message.chat.id if cq.message else None)
    if target_chat_id is None and cq.from_user:
        target_chat_id = cq.from_user.id
    if target_chat_id is None:
        if cq.message:
            await cq.message.answer("Канал для отчётов не настроен.", reply_markup=reports_menu_keyboard())
        await cq.answer()
        return
    try:
        await _send_export_documents(cq.bot, bundle, f"{caption_prefix} {period_label}", chat_id=target_chat_id)
    except TelegramBadRequest:
        if cq.from_user:
            await _send_export_documents(cq.bot, bundle, f"{caption_prefix} {period_label}", chat_id=cq.from_user.id)
            if cq.message:
                await cq.message.answer("Отчёт отправлен вам в чат (канал недоступен).")
        else:
            if cq.message:
                await cq.message.answer("Не удалось доставить отчёт.")
            await cq.answer()
            return
    else:
        if cq.message:
            await cq.message.answer("Отчёт отправлен.")
    await state.clear()
    await cq.answer()

async def _start_new_order(cq: CallbackQuery, staff: StaffUser, state: FSMContext) -> None:
    await state.clear()
    await state.update_data(staff_id=staff.id, attachments=[], order_type=OrderType.NORMAL.value)
    await state.set_state(NewOrderFSM.city)
    await _render_city_step(cq.message, state, page=1)
    await cq.answer()


async def _render_city_step(message: Message, state: FSMContext, page: int, query: Optional[str] = None) -> None:
    orders_service = _orders_service(message.bot)
    limit = 80
    if query:
        cities = await orders_service.list_cities(query=query, limit=limit)
    else:
        cities = await orders_service.list_cities(limit=limit)
    if not cities:
        try:
            await message.edit_text("Города не найдены. Нажмите /cancel, чтобы отменить.")
        except TelegramBadRequest:
            await message.answer("Города не найдены. Нажмите /cancel, чтобы отменить.")
        return
    per_page = 10
    total_pages = max(1, (len(cities) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    chunk = cities[start : start + per_page]
    keyboard = new_order_city_keyboard([(c.id, c.name) for c in chunk], page=page, total_pages=total_pages)
    prompt = "Выберите город:"
    try:
        await message.edit_text(prompt, reply_markup=keyboard)
    except TelegramBadRequest:
        await message.answer(prompt, reply_markup=keyboard)
    except Exception:
        await message.answer(prompt, reply_markup=keyboard)
    await state.update_data(city_query=query, city_page=page)


@router.callback_query(
    F.data == "adm:new",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN, StaffRole.LOGIST}),
)
async def cb_new_order_start(cq: CallbackQuery, staff: StaffUser, state: FSMContext) -> None:
    await _start_new_order(cq, staff, state)


@router.message(
    Command("cancel"),
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN, StaffRole.LOGIST}),
)
async def admin_cancel_command(message: Message, staff: StaffUser, state: FSMContext) -> None:
    await state.clear()
    await show_admin_main_menu(
        message,
        staff,
        notice="Создание заявки отменено.",
    )


@router.callback_query(F.data == "adm:new:cancel")
async def cb_new_order_cancel(cq: CallbackQuery, staff: StaffUser, state: FSMContext) -> None:
    await state.clear()
    if cq.message:
        await show_admin_main_menu(
            cq.message,
            staff,
            edit=True,
            notice="Создание заявки отменено",
        )
    await cq.answer("Отмена")


@router.callback_query(F.data.startswith("adm:new:city_page:"), StateFilter(NewOrderFSM.city))
async def cb_new_order_city_page(cq: CallbackQuery, state: FSMContext) -> None:
    page = int(cq.data.split(":")[3])
    data = await state.get_data()
    query = data.get("city_query")
    await state.set_state(NewOrderFSM.city)
    await _render_city_step(cq.message, state, page=page, query=query)
    await cq.answer()


@router.callback_query(F.data == "adm:new:city_search", StateFilter(NewOrderFSM.city))
async def cb_new_order_city_search(cq: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(NewOrderFSM.city)
    prompt = "Введите название города (минимум 2 символа). Команда /cancel вернёт в меню."
    try:
        await cq.message.edit_text(prompt)
    except TelegramBadRequest:
        await cq.message.answer(prompt)
    except Exception:
        await cq.message.answer(prompt)
    await cq.answer()


@router.message(StateFilter(NewOrderFSM.city))
async def new_order_city_input(msg: Message, state: FSMContext) -> None:
    query = (msg.text or "").strip()
    if len(query) < 2:
        await msg.answer("Минимум 2 символа. Попробуйте снова.")
        return
    await _render_city_step(msg, state, page=1, query=query)


@router.callback_query(F.data.startswith("adm:new:city:"), StateFilter(NewOrderFSM.city))
async def cb_new_order_city_pick(cq: CallbackQuery, state: FSMContext) -> None:
    city_id = int(cq.data.split(":")[3])
    orders_service = _orders_service(cq.message.bot)
    city = await orders_service.get_city(city_id)
    if not city:
        await cq.answer("Город не найден", show_alert=True)
        return
    await state.update_data(city_id=city.id, city_name=city.name)
    await state.set_state(NewOrderFSM.district)
    await _render_district_step(cq.message, state, page=1)
    await cq.answer()


async def _render_district_step(message: Message, state: FSMContext, page: int) -> None:
    data = await state.get_data()
    city_id = data.get("city_id")
    orders_service = _orders_service(message.bot)
    districts, has_next = await orders_service.list_districts(city_id, page=page, page_size=5)
    buttons = [(d.id, d.name) for d in districts]
    keyboard = new_order_district_keyboard(buttons, page=page, has_next=has_next)
    prompt = "Выберите район:"
    try:
        await message.edit_text(prompt, reply_markup=keyboard)
    except TelegramBadRequest:
        await message.answer(prompt, reply_markup=keyboard)
    except Exception:
        await message.answer(prompt, reply_markup=keyboard)
    await state.update_data(district_page=page)


@router.callback_query(F.data.startswith("adm:new:district_page:"), StateFilter(NewOrderFSM.district))
async def cb_new_order_district_page(cq: CallbackQuery, state: FSMContext) -> None:
    page = int(cq.data.split(":")[3])
    await state.set_state(NewOrderFSM.district)
    await _render_district_step(cq.message, state, page=page)
    await cq.answer()


@router.callback_query(F.data == "adm:new:city_back", StateFilter(NewOrderFSM.district))
async def cb_new_order_city_back(cq: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    await state.set_state(NewOrderFSM.city)
    await _render_city_step(
        cq.message,
        state,
        page=data.get("city_page", 1),
        query=data.get("city_query"),
    )
    await cq.answer()


@router.callback_query(F.data == "adm:new:district:none", StateFilter(NewOrderFSM.district))
async def cb_new_order_district_none(cq: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(district_id=None, district_name="")
    await state.set_state(NewOrderFSM.street_mode)
    await cq.message.edit_text(
        "Выберите способ указать улицу:",
        reply_markup=new_order_street_mode_keyboard(),
    )
    await cq.answer()


@router.callback_query(F.data.startswith("adm:new:district:"), StateFilter(NewOrderFSM.district))
async def cb_new_order_district_pick(cq: CallbackQuery, state: FSMContext) -> None:
    district_id = int(cq.data.split(":")[3])
    orders_service = _orders_service(cq.message.bot)
    district = await orders_service.get_district(district_id)
    if not district:
        await cq.answer("Район не найден", show_alert=True)
        return
    await state.update_data(district_id=district.id, district_name=district.name)
    await state.set_state(NewOrderFSM.street_mode)
    await cq.message.edit_text(
        "Выберите способ указать улицу:",
        reply_markup=new_order_street_mode_keyboard(),
    )
    await cq.answer()


@router.callback_query(F.data == "adm:new:street:search", StateFilter(NewOrderFSM.street_mode))
async def cb_new_order_street_search(cq: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(NewOrderFSM.street_search)
    await cq.message.edit_text("Введите минимум 2 символа названия улицы для поиска.")
    await cq.answer()


@router.callback_query(F.data == "adm:new:street:manual", StateFilter(NewOrderFSM.street_mode))
async def cb_new_order_street_manual(cq: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(NewOrderFSM.street_manual)
    await cq.message.edit_text(
        "Введите название улицы (до 250 символов).",
        reply_markup=new_order_street_manual_keyboard(),
    )
    await cq.answer()


@router.callback_query(F.data == "adm:new:street:none", StateFilter(NewOrderFSM.street_mode))
async def cb_new_order_street_none(cq: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(street_id=None, street_name="", street_manual=None)
    await state.set_state(NewOrderFSM.house)
    await cq.message.edit_text("Укажите номер дома (до 10 символов, '-' если нет).")
    await cq.answer()


@router.callback_query(F.data == "adm:new:district_back", StateFilter(NewOrderFSM.street_mode))
async def cb_new_order_street_back(cq: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(NewOrderFSM.district)
    page = (await state.get_data()).get("district_page", 1)
    await _render_district_step(cq.message, state, page=page)
    await cq.answer()


@router.message(StateFilter(NewOrderFSM.street_manual))
async def new_order_street_manual_input(msg: Message, state: FSMContext) -> None:
    value = (msg.text or "").strip()
    if not (2 <= len(value) <= 250):
        await msg.answer("Название улицы должно быть от 2 до 250 символов.")
        return
    await state.update_data(street_id=None, street_name=value, street_manual=value)
    await state.set_state(NewOrderFSM.house)
    await msg.answer("Укажите номер дома (до 10 символов, '-' если нет).")


@router.message(StateFilter(NewOrderFSM.street_search))
async def new_order_street_search_input(msg: Message, state: FSMContext) -> None:
    query = (msg.text or "").strip()
    if len(query) < 2:
        await msg.answer("Введите минимум 2 символа для поиска улицы.")
        return
    data = await state.get_data()
    city_id = data.get("city_id")
    orders_service = _orders_service(msg.bot)
    streets = await orders_service.search_streets(city_id, query)
    if not streets:
        await msg.answer("Не удалось найти улицу. Попробуйте другой запрос или введите её вручную.")
        await state.set_state(NewOrderFSM.street_mode)
        await msg.answer(
            "Выберите способ указать улицу:",
            reply_markup=new_order_street_mode_keyboard(),
        )
        return
    buttons = [
        (s.id, s.name if s.score is None else f"{s.name} ({int(s.score)}%)")
        for s in streets
    ]
    await msg.answer(
        "Выберите улицу:",
        reply_markup=new_order_street_keyboard(buttons),
    )
    await state.set_state(NewOrderFSM.street_mode)
    await state.update_data(street_search_results=buttons)


@router.callback_query(F.data.startswith("adm:new:street:"), StateFilter(NewOrderFSM.street_mode))
async def cb_new_order_street_pick(cq: CallbackQuery, state: FSMContext) -> None:
    tail = cq.data.split(":")[3]
    if tail == "search_again":
        await state.set_state(NewOrderFSM.street_search)
        await cq.message.edit_text("Введите минимум 2 символа названия улицы для поиска.")
        await cq.answer()
        return
    if tail == "manual_back":
        await state.set_state(NewOrderFSM.street_mode)
        await cq.message.edit_text(
            "Выберите способ указать улицу:",
            reply_markup=new_order_street_mode_keyboard(),
        )
        await cq.answer()
        return
    if tail == "back":
        await state.set_state(NewOrderFSM.street_mode)
        await cq.message.edit_text(
            "Выберите способ указать улицу:",
            reply_markup=new_order_street_mode_keyboard(),
        )
        await cq.answer()
        return
    street_id = int(tail)
    orders_service = _orders_service(cq.message.bot)
    street = await orders_service.get_street(street_id)
    if not street:
        await cq.answer("Улица не найдена", show_alert=True)
        return
    await state.update_data(street_id=street.id, street_name=street.name, street_manual=None)
    await state.set_state(NewOrderFSM.house)
    await cq.message.edit_text("Укажите номер дома (до 10 символов, '-' если нет).")
    await cq.answer()


@router.message(StateFilter(NewOrderFSM.house))
async def new_order_house(msg: Message, state: FSMContext) -> None:
    value = (msg.text or "").strip()
    if not (1 <= len(value) <= 10):
        await msg.answer("Номер дома должен быть от 1 до 10 символов.")
        return
    await state.update_data(house=value)
    await state.set_state(NewOrderFSM.apartment)
    await msg.answer("Введите квартиру/офис (до 10 символов, '-' если нет).")


@router.message(StateFilter(NewOrderFSM.apartment))
async def new_order_apartment(msg: Message, state: FSMContext) -> None:
    value = (msg.text or "").strip()
    if value == "-":
        value = ""
    if len(value) > 10:
        await msg.answer("Максимальная длина квартиры/офиса 10 символов.")
        return
    await state.update_data(apartment=value or None)
    await state.set_state(NewOrderFSM.address_comment)
    await msg.answer("Добавьте комментарий к адресу (до 250 символов, '-' если пропустить).")


@router.message(StateFilter(NewOrderFSM.address_comment))
async def new_order_address_comment(msg: Message, state: FSMContext) -> None:
    value = (msg.text or "").strip()
    if value == "-":
        value = ""
    await state.update_data(address_comment=value or None)
    await state.set_state(NewOrderFSM.client_name)
    await msg.answer("Введите имя клиента (ФИО).")


@router.message(StateFilter(NewOrderFSM.client_name))
async def new_order_client_name(msg: Message, state: FSMContext) -> None:
    value = (msg.text or "").strip()
    if not _validate_name(value):
        await msg.answer("Имя должно содержать только буквы и пробелы.")
        return
    await state.update_data(client_name=value)
    await state.set_state(NewOrderFSM.client_phone)
    await msg.answer("Укажите телефон клиента в формате +7XXXXXXXXXX.")


@router.message(StateFilter(NewOrderFSM.client_phone))
async def new_order_client_phone(msg: Message, state: FSMContext) -> None:
    raw = _normalize_phone(msg.text)
    if not _validate_phone(raw):
        await msg.answer("Телефон должен быть в формате +7XXXXXXXXXX.")
        return
    await state.update_data(client_phone=raw)
    await state.set_state(NewOrderFSM.category)
    from aiogram.utils.keyboard import InlineKeyboardBuilder

    kb = InlineKeyboardBuilder()
    for category, label in CATEGORY_CHOICES:
        kb.button(text=label, callback_data=f"adm:new:cat:{category.value}")
    kb.adjust(2)
    await msg.answer("Выберите категорию заявки:", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("adm:new:cat:"), StateFilter(NewOrderFSM.category))
async def cb_new_order_category(cq: CallbackQuery, state: FSMContext) -> None:
    raw = cq.data.split(":")[3]
    category = normalize_category(raw)
    if category is None:
        await cq.answer("Неизвестная категория.", show_alert=True)
        return
    await state.update_data(
        category=category,
        category_label=CATEGORY_LABELS.get(category, CATEGORY_LABELS_BY_VALUE.get(raw, raw)),
    )
    await state.set_state(NewOrderFSM.description)
    await cq.message.edit_text("Опишите проблему (10-500 символов).")
    await cq.answer()


@router.message(StateFilter(NewOrderFSM.description))
async def new_order_description(msg: Message, state: FSMContext) -> None:
    text_value = (msg.text or "").strip()
    if not (10 <= len(text_value) <= 500):
        await msg.answer("Описание должно содержать от 10 до 500 символов.")
        return
    await state.update_data(description=text_value)
    await state.set_state(NewOrderFSM.attachments)
    await msg.answer(
        'Пришлите файлы или нажмите "Готово", чтобы продолжить.',
        reply_markup=new_order_attachments_keyboard(False),
    )


@router.callback_query(F.data == "adm:new:att:add", StateFilter(NewOrderFSM.attachments))
async def cb_new_order_att_add(cq: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(NewOrderFSM.attachments)
    await cq.answer("Пришлите фото или документ одним сообщением.")


@router.callback_query(F.data == "adm:new:att:clear", StateFilter(NewOrderFSM.attachments))
async def cb_new_order_att_clear(cq: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    data["attachments"] = []
    await state.update_data(**data)
    await state.set_state(NewOrderFSM.attachments)
    await cq.message.edit_text(
        'Вложения удалены. Пришлите новые или нажмите "Готово".',
        reply_markup=new_order_attachments_keyboard(False),
    )
    await cq.answer()


@router.message(StateFilter(NewOrderFSM.attachments), F.photo)
async def new_order_attach_photo(msg: Message, state: FSMContext) -> None:
    attachments = _attachments_from_state(await state.get_data())
    if len(attachments) >= ATTACHMENTS_LIMIT:
        await msg.answer("Достигнут лимит вложений.")
        return
    photo = msg.photo[-1]
    attachments.append(
        {
            "file_id": photo.file_id,
            "file_unique_id": photo.file_unique_id,
            "file_type": "photo",
            "file_name": None,
            "mime_type": None,
            "caption": msg.caption,
        }
    )
    await state.update_data(attachments=attachments)
    await msg.answer(
        f'Вложений добавлено: {len(attachments)}. Пришлите ещё или нажмите "Готово".',
        reply_markup=new_order_attachments_keyboard(True),
    )


@router.message(StateFilter(NewOrderFSM.attachments), F.document)
async def new_order_attach_doc(msg: Message, state: FSMContext) -> None:
    attachments = _attachments_from_state(await state.get_data())
    if len(attachments) >= ATTACHMENTS_LIMIT:
        await msg.answer("Достигнут лимит вложений.")
        return
    doc = msg.document
    attachments.append(
        {
            "file_id": doc.file_id,
            "file_unique_id": doc.file_unique_id,
            "file_type": "document",
            "file_name": doc.file_name,
            "mime_type": doc.mime_type,
            "caption": msg.caption,
        }
    )
    await state.update_data(attachments=attachments)
    await msg.answer(
        f'Вложений добавлено: {len(attachments)}. Пришлите ещё или нажмите "Готово".',
        reply_markup=new_order_attachments_keyboard(True),
    )
@router.callback_query(F.data == "adm:new:att:done", StateFilter(NewOrderFSM.attachments))
async def cb_new_order_att_done(cq: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(NewOrderFSM.order_type)
    from aiogram.utils.keyboard import InlineKeyboardBuilder

    kb = InlineKeyboardBuilder()
    kb.button(text="Стандартная", callback_data="adm:new:type:NORMAL")
    kb.button(text="Гарантия", callback_data="adm:new:type:GUARANTEE")
    kb.adjust(2)
    await cq.message.edit_text("Выберите тип заявки:", reply_markup=kb.as_markup())
    await cq.answer()


@router.callback_query(F.data.startswith("adm:new:type:"), StateFilter(NewOrderFSM.order_type))
async def cb_new_order_type(cq: CallbackQuery, state: FSMContext) -> None:
    code = cq.data.split(":")[3]
    await state.update_data(
        order_type=code,
        company_payment=2500 if code == "GUARANTEE" else 0,
        initial_status=None,
    )
    await state.set_state(NewOrderFSM.slot)
    data = await state.get_data()
    city_id = data.get("city_id")
    if not city_id:
        await cq.answer("Не удалось определить город.", show_alert=True)
        return
    tz = await _resolve_city_timezone(cq.message.bot, city_id)
    workday_start, workday_end = await _resolve_workday_window()
    now_local = time_service.now_in_city(tz)
    options = _slot_options(now_local, workday_start=workday_start, workday_end=workday_end)
    options = [(k, _maybe_fix_mojibake(lbl)) for (k, lbl) in options]
    await state.update_data(
        slot_options=options,
        city_timezone=_zone_storage_value(tz),
        pending_asap=False,
    )
    keyboard = new_order_slot_keyboard(options)
    await cq.message.edit_text("Выберите доступное время:", reply_markup=keyboard)
    await cq.answer()


@router.callback_query(F.data.startswith("adm:new:slot:"), StateFilter(NewOrderFSM.slot))
async def cb_new_order_slot(cq: CallbackQuery, state: FSMContext) -> None:
    key = ":".join(cq.data.split(":")[3:])
    data = await state.get_data()
    city_id = data.get("city_id")
    if not city_id:
        await cq.answer("Не удалось определить город.", show_alert=True)
        return
    await state.set_state(NewOrderFSM.slot)
    options = data.get("slot_options") or []
    valid_keys = {item[0] for item in options}
    if key not in valid_keys:
        await cq.answer("Слот недоступен.", show_alert=True)
        return
    tz_value = data.get("city_timezone")
    if tz_value:
        tz = time_service.resolve_timezone(tz_value)
    else:
        tz = await _resolve_city_timezone(cq.message.bot, city_id)
        await state.update_data(city_timezone=_zone_storage_value(tz))
    workday_start, workday_end = await _resolve_workday_window()
    now_local = time_service.now_in_city(tz)
    if key == "ASAP":
        normalized = time_service.normalize_asap_choice(
            now_local=now_local,
            workday_start=workday_start,
            workday_end=workday_end,
            late_threshold=LATE_ASAP_THRESHOLD,
        )
        if normalized == "DEFERRED_TOM_10_13":
            await state.update_data(pending_asap=True)
            await state.set_state(NewOrderFSM.slot)
            await cq.message.edit_text(
                "Мастер может выехать только завтра с 10:00 до 13:00. Подтвердить перенос?",
                reply_markup=new_order_asap_late_keyboard(),
            )
            await cq.answer()
            return
        slot_choice = "ASAP"
        initial_status = None
    else:
        slot_choice = key
        initial_status = None
    try:
        await _finalize_slot_selection(
            message=cq.message,
            state=state,
            slot_choice=slot_choice,
            tz=tz,
            workday_start=workday_start,
            workday_end=workday_end,
            initial_status_override=initial_status,
        )
    except ValueError:
        refreshed_options = _slot_options(
            time_service.now_in_city(tz),
            workday_start=workday_start,
            workday_end=workday_end,
        )
        refreshed_options = [(k, _maybe_fix_mojibake(lbl)) for (k, lbl) in refreshed_options]
        await state.update_data(slot_options=refreshed_options, pending_asap=False, initial_status=None)
        await state.set_state(NewOrderFSM.slot)
        await cq.message.edit_text(
            "Слот недоступен. Выберите другое время:",
            reply_markup=new_order_slot_keyboard(refreshed_options),
        )
        await cq.answer("Расписание обновлено, попробуйте снова.", show_alert=True)
        return
    await cq.answer()


@router.callback_query(F.data == "adm:new:slot:lateok", StateFilter(NewOrderFSM.slot))
async def cb_new_order_slot_lateok(cq: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    city_id = data.get("city_id")
    if not city_id:
        await cq.answer("Не удалось определить город.", show_alert=True)
        return
    tz_value = data.get("city_timezone")
    if tz_value:
        tz = time_service.resolve_timezone(tz_value)
    else:
        tz = await _resolve_city_timezone(cq.message.bot, city_id)
        await state.update_data(city_timezone=_zone_storage_value(tz))
    workday_start, workday_end = await _resolve_workday_window()
    await _finalize_slot_selection(
        message=cq.message,
        state=state,
        slot_choice="TOM:10-13",
        tz=tz,
        workday_start=workday_start,
        workday_end=workday_end,
        initial_status_override=OrderStatus.DEFERRED,
    )
    await cq.answer()


@router.callback_query(F.data == "adm:new:slot:reslot", StateFilter(NewOrderFSM.slot))
async def cb_new_order_slot_reslot(cq: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    city_id = data.get("city_id")
    if not city_id:
        await cq.answer("Не удалось определить город.", show_alert=True)
        return
    await state.set_state(NewOrderFSM.slot)
    tz_value = data.get("city_timezone")
    if tz_value:
        tz = time_service.resolve_timezone(tz_value)
    else:
        tz = await _resolve_city_timezone(cq.message.bot, city_id)
        await state.update_data(city_timezone=_zone_storage_value(tz))
    workday_start, workday_end = await _resolve_workday_window()
    options = _slot_options(
        time_service.now_in_city(tz),
        workday_start=workday_start,
        workday_end=workday_end,
    )
    options = [(k, _maybe_fix_mojibake(lbl)) for (k, lbl) in options]
    await state.update_data(slot_options=options, pending_asap=False, initial_status=None)
    await cq.message.edit_text("Выберите доступное время:", reply_markup=new_order_slot_keyboard(options))
    await cq.answer()
@router.callback_query(F.data == "adm:new:confirm", StateFilter(NewOrderFSM.confirm))
async def cb_new_order_confirm(cq: CallbackQuery, state: FSMContext, staff: StaffUser | None = None) -> None:
    # Be robust if middleware didn't inject staff for some reason
    if staff is None:
        staff_service = _staff_service(cq.message.bot)
        staff = await staff_service.get_by_tg_id(cq.from_user.id if cq.from_user else 0)
        if staff is None:
            await cq.answer(" ", show_alert=True)
            return
    data = await state.get_data()
    summary_text = new_order_summary(data)
    try:
        new_order = _build_new_order_data(data, staff)
    except KeyError:
        await state.clear()
        await cq.answer("Не удалось собрать данные заявки. Попробуйте заново.", show_alert=True)
        return
    orders_service = _orders_service(cq.message.bot)
    order_id = await orders_service.create_order(new_order)
    detail = await orders_service.get_card(order_id, city_ids=visible_city_ids_for(staff))
    await state.clear()
    await cq.answer("Заявка создана")
    if detail:
        allow_auto = detail.district_id is not None
        prompt_parts = [f"Заявка #{detail.id} создана.", summary_text]
        if not allow_auto:
            prompt_parts.append("Автораспределение недоступно: не выбран район.")
        prompt_parts.append("Выберите способ распределения:")
        prompt = "\n\n".join(prompt_parts)
        markup = assign_menu_keyboard(detail.id, allow_auto=allow_auto)
        try:
            await cq.message.edit_text(prompt, reply_markup=markup, disable_web_page_preview=True)
        except Exception:
            await cq.message.answer(prompt, reply_markup=markup, disable_web_page_preview=True)
        return
    await _render_created_order_card(cq.message, order_id, staff)





@router.callback_query(
    F.data == "adm:s",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN}),
)
async def cb_settings_menu(cq: CallbackQuery, staff: StaffUser) -> None:
    await cq.message.edit_text(
        "<b></b>\n    .",
        reply_markup=settings_menu_keyboard(),
    )
    await cq.answer()


@router.callback_query(
    F.data.startswith("adm:s:group:"),
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN}),
)
async def cb_settings_group(cq: CallbackQuery, staff: StaffUser) -> None:
    group_key = cq.data.split(":")[3]
    try:
        view_text, keyboard = await _build_settings_view(cq.message.bot, group_key)
    except KeyError:
        await cq.answer("  ", show_alert=True)
        return
    await cq.message.edit_text(
        view_text,
        reply_markup=keyboard,
        disable_web_page_preview=True,
    )
    await cq.answer()


@router.callback_query(
    F.data.startswith("adm:s:edit:"),
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN}),
)
async def cb_settings_edit_start(
    cq: CallbackQuery, staff: StaffUser, state: FSMContext
) -> None:
    parts = cq.data.split(":")
    if len(parts) != 5:
        await cq.answer(" ", show_alert=True)
        return
    _, _, _, group_key, field_key = parts
    try:
        field = _get_setting_field(field_key)
    except KeyError:
        await cq.answer("  ", show_alert=True)
        return

    service = _settings_service(cq.message.bot)
    raw_map = await service.get_values([field.key])
    current_raw = raw_map.get(field.key, (None, None))[0]
    display, _ = _format_setting_value(field, current_raw)
    prompt = _build_setting_prompt(field, display)

    await state.set_state(SettingsEditFSM.awaiting_value)
    await state.update_data(
        edit_key=field.key,
        group_key=group_key,
        source_chat_id=cq.message.chat.id,
        source_message_id=cq.message.message_id,
    )
    await cq.message.answer(prompt, disable_web_page_preview=True)
    await cq.answer()


@router.message(
    StateFilter(SettingsEditFSM.awaiting_value),
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN}),
    F.text == "/cancel",
)

@router.message(
    StateFilter(SettingsEditFSM.awaiting_value),
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN}),
)
async def settings_edit_cancel(msg: Message, state: FSMContext) -> None:
    await state.clear()
    await msg.answer("Редактирование отменено.")

async def settings_edit_value(
    msg: Message, staff: StaffUser, state: FSMContext
) -> None:
    data = await state.get_data()
    field_key = data.get("edit_key")
    group_key = data.get("group_key")
    source_chat_id = data.get("source_chat_id")
    source_message_id = data.get("source_message_id")

    if not field_key or not group_key or source_chat_id is None or source_message_id is None:
        await state.clear()
        await msg.answer("Редактирование отменено.")
        return

    try:
        field = _get_setting_field(field_key)
    except KeyError:
        await state.clear()
        await msg.answer("Редактирование отменено.")
        return

    if not msg.text:
        await msg.answer("Редактирование отменено.")
        return

    try:
        value, value_type = _parse_setting_input(field, msg.text)
    except ValueError as exc:
        await msg.answer(str(exc))
        return

    service = _settings_service(msg.bot)
    await service.set_value(field.key, value, value_type=value_type)
    await state.clear()
    await msg.answer("Редактирование отменено.")

    try:
        view_text, keyboard = await _build_settings_view(msg.bot, group_key)
        await msg.bot.edit_message_text(
            view_text,
            chat_id=source_chat_id,
            message_id=source_message_id,
            reply_markup=keyboard,
            disable_web_page_preview=True,
        )
    except Exception:
        pass


@router.callback_query(
    F.data == "adm:l",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN, StaffRole.LOGIST}),
)
async def cb_logs_menu(cq: CallbackQuery, staff: StaffUser) -> None:
    entries = live_log.snapshot(LOG_ENTRIES_LIMIT)
    text = _format_log_entries(entries)
    keyboard = logs_menu_keyboard(can_clear=staff.role is StaffRole.GLOBAL_ADMIN)
    await cq.message.edit_text(
        text,
        reply_markup=keyboard,
        disable_web_page_preview=True,
    )
    await cq.answer()


@router.callback_query(
    F.data == "adm:l:refresh",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN, StaffRole.CITY_ADMIN, StaffRole.LOGIST}),
)
async def cb_logs_refresh(cq: CallbackQuery, staff: StaffUser) -> None:
    entries = live_log.snapshot(LOG_ENTRIES_LIMIT)
    text = _format_log_entries(entries)
    keyboard = logs_menu_keyboard(can_clear=staff.role is StaffRole.GLOBAL_ADMIN)
    await cq.message.edit_text(
        text,
        reply_markup=keyboard,
        disable_web_page_preview=True,
    )
    await cq.answer()


@router.callback_query(
    F.data == "adm:l:clear",
    StaffRoleFilter({StaffRole.GLOBAL_ADMIN}),
)
async def cb_logs_clear(cq: CallbackQuery, staff: StaffUser) -> None:
    live_log.clear()
    entries = live_log.snapshot(LOG_ENTRIES_LIMIT)
    text = _format_log_entries(entries)
    keyboard = logs_menu_keyboard(can_clear=True)
    await cq.message.edit_text(
        text,
        reply_markup=keyboard,
        disable_web_page_preview=True,
    )
    await cq.answer("")

# -------- Final overrides to fix mojibake in constants --------
# These assignments ensure readable Russian texts regardless of earlier literals.
STAFF_CODE_PROMPT = "Введите код доступа, который выдал администратор."
STAFF_CODE_ERROR = "Код не найден / истёк / уже использован / вам недоступен."
STAFF_PDN_TEXT = (
    "Согласие на обработку персональных данных.\n"
    "Согласие включает обработку ФИО, телефона и данных о заказах для допуска к работе и обеспечения безопасности сервиса. "
    "Отправьте \"Согласен\" для продолжения или \"Не согласен\" для отмены."
)

REPORT_DEFINITIONS: dict[str, tuple[str, Any, str]] = {
    "orders": ("Заказы", export_service.export_orders, "Orders"),
    "commissions": ("Комиссии", export_service.export_commissions, "Commissions"),
    "ref_rewards": ("Реферальные начисления", export_service.export_referral_rewards, "Referral rewards"),
}

_RU_GROUP_TITLES = {
    "workday": "Рабочий день",
    "distribution": "Распределение",
    "limits": "Лимиты",
    "support": "Поддержка",
    "geo": "Гео",
    "channels": "Каналы",
}
_RU_GROUP_DESCRIPTIONS = {
    "workday": "Рабочий интервал сервиса. В это время назначаются визиты мастеров.",
    "distribution": "Настройки автораспределения заявок (частота, SLA, раунды).",
    "limits": "Ограничения сервиса для мастеров и процессов.",
    "support": "Контакты поддержки и материалы.",
    "geo": "Режим и лимиты геокодера.",
    "channels": "ID каналов Telegram для уведомлений и отчётов.",
}
_RU_FIELD_LABELS = {
    "working_hours_start": "Начало рабочего дня",
    "working_hours_end": "Конец рабочего дня",
    "distribution_tick_seconds": "Шаг цикла (сек.)",
    "distribution_sla_seconds": "SLA ответа мастера (сек.)",
    "distribution_rounds": "Количество раундов",
    "escalate_to_admin_after_min": "Эскалация к админу через (мин.)",
    "distribution_log_topn": "Логировать topN кандидатов",
    "max_active_orders": "Макс. активных заказов на мастера",
    "support_contact": "Контакт поддержки",
    "support_faq_url": "Ссылка на FAQ",
    "geo_mode": "Режим геокодера",
    "yandex_geocoder_key": "API‑ключ Яндекс",
    "yandex_throttle_rps": "RPS ограничение",
    "yandex_daily_limit": "Суточный лимит запросов",
    "alerts_channel_id": "Канал алертов (ID)",
    "logs_channel_id": "Канал логов (ID)",
    "reports_channel_id": "Канал отчётов (ID)",
}

SCHEMA_DEFAULT_HELP = {
    "time": "Формат ЧЧ:ММ, по умолчанию 10:00.",
    "int": "Введите положительное целое число.",
    "int_non_negative": "Введите целое число 0 или больше.",
    "string": "Введите текстовое значение.",
    "string_optional": "Введите текст или '-' чтобы очистить значение.",
    "int_optional": "Введите число или '-' чтобы очистить значение.",
    "choice": "Выберите один из предложенных вариантов.",
}
