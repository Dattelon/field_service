# 🚀 QUICKSTART: DEFERRED Distribution Bugfix

## 📋 Что исправлено

1. **Кнопка "Телефон мастера"** - теперь показывается только когда мастер назначен
2. **Распределение DEFERRED** - автоматический перевод в SEARCHING при принудительном запуске
3. **Битые строки** - исправлен текст меню "Заявки"

## 🔧 Измененные файлы

- `field_service/bots/admin_bot/ui/keyboards/orders.py`
- `field_service/bots/admin_bot/handlers/orders/queue.py`
- `field_service/bots/admin_bot/services/distribution.py`

## ⚡ Быстрый тест

### 1. Перезапуск
```bash
docker-compose restart admin-bot
```

### 2. Тест кнопки "Телефон мастера"
1. Открыть заказ #2 (БЕЗ мастера)
   - Должно быть 2 кнопки: "Телефон клиента", "Адрес"

### 3. Тест распределения DEFERRED
1. Заказ #2 в статусе DEFERRED
2. Меню → Заявки → Очередь → #2
3. Нажать "Назначить" → "Автораспределение"
   - Появится предупреждение ⚠️
4. Нажать "Да, запустить"
   - Заказ перейдет в SEARCHING
   - Оффер отправится мастеру

### 4. Проверка в БД
```sql
-- Проверить статус
SELECT id, status FROM orders WHERE id = 2;

-- Проверить историю
SELECT 
    from_status, 
    to_status, 
    reason, 
    changed_at 
FROM order_status_history 
WHERE order_id = 2 
ORDER BY changed_at DESC 
LIMIT 3;
```

## ✅ Ожидаемый результат

- Статус заказа: `SEARCHING`
- История: `DEFERRED → SEARCHING` с причиной "Принудительный запуск..."
- Оффер отправлен мастеру
- Мастер получил уведомление

## 📊 Логи

```bash
docker-compose logs -f admin-bot | grep "order=2"
```

Ищите:
```
[dist] order=2 DEFERRED→SEARCHING (forced by staff #...)
[dist] order=2 ... offer sent to master #...
```

---

**Всё готово!** Патч применён, можно тестировать 🎉
